from __future__ import annotations

"""Canonical grouped/summary reduction adapter front doors.

This module is the public routing layer for generic partner reduction
contracts. The implementation still delegates to the legacy
``partner_adapters`` internals while the monolith is split incrementally, but
new package exports and internal generic stream adapters should import from
this module rather than directly from ``partner_adapters``.
"""

from ..partner_adapters import partner_group_any_by_key
from ..partner_adapters import partner_group_count_by_key
from ..partner_adapters import partner_group_count_unique_pairs_by_key
from ..partner_adapters import partner_group_max_by_key
from ..partner_adapters import partner_group_min_by_key
from ..partner_adapters import partner_group_sum_by_key
from ..partner_adapters import partner_group_vector_sum_2d_by_key
from ..partner_adapters import global_argmax_u32_f64_partner_columns
from ..partner_adapters import grouped_argmax_f64_partner_columns
from ..partner_adapters import grouped_argmin_f64_partner_columns
from ..partner_adapters import grouped_topk_f64_partner_columns
from ..partner_adapters import grouped_vector_sum_2d_partner_columns
from ..partner_adapters import prepare_grouped_vector_sum_2d_partner_columns_session
from ..partner_adapters import run_grouped_vector_sum_2d_partner_columns_session
from ..partner_adapters import measured_grouped_vector_sum_2d_partner_selection
from ..partner_adapters import group_argmin_then_global_argmax_partner_columns
from ..partner_adapters import partner_metric_table_reduce_batch
from ..partner_adapters import partner_metric_table_reduce_by_key
from ..partner_adapters import partner_metric_table_reduce_repeated_pattern
from ..partner_adapters import partner_unique_pair_keys


__all__ = [
    "partner_group_any_by_key",
    "partner_group_count_by_key",
    "partner_group_count_unique_pairs_by_key",
    "partner_group_max_by_key",
    "partner_group_min_by_key",
    "partner_group_sum_by_key",
    "partner_group_vector_sum_2d_by_key",
    "global_argmax_u32_f64_partner_columns",
    "grouped_argmax_f64_partner_columns",
    "grouped_argmin_f64_partner_columns",
    "grouped_topk_f64_partner_columns",
    "grouped_vector_sum_2d_partner_columns",
    "prepare_grouped_vector_sum_2d_partner_columns_session",
    "run_grouped_vector_sum_2d_partner_columns_session",
    "measured_grouped_vector_sum_2d_partner_selection",
    "group_argmin_then_global_argmax_partner_columns",
    "partner_metric_table_reduce_batch",
    "partner_metric_table_reduce_by_key",
    "partner_metric_table_reduce_repeated_pattern",
    "partner_unique_pair_keys",
]
