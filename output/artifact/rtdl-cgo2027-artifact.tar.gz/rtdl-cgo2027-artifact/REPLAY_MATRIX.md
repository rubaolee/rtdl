# Replay matrix

| Layer | Included | Offline verifier action |
| --- | --- | --- |
| Formal performance | 160 cells, 20,480 steady samples | Recompute every worker median and all block ratios |
| Lifecycle | A/C/E worker import, gap, post-import, entry, and partitions | Reconcile each worker and compute descriptive medians |
| Instrumentation | 1,024 Arm-A endpoints | Recompute paired block estimator and overhead |
| AOT | 20 fresh-process cache-hit durations plus four cold denominators | Recompute medians and hit/cold ratios |
| Competence | 8 nonformal B/C workers, 1,024 steady samples | Recompute worker medians and C/B ratios |
| GPU execution | Not included | No GPU access |
| Historical full authority | Not portable in this package | Not claimed |
