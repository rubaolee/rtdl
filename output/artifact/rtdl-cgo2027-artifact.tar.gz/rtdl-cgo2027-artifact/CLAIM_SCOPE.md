# Claim scope

The package preserves a narrow observation of the exact prepared public path
on two frozen tasks and two GPU generations. Ratios are computed only within a
machine. They are not intrinsic language speedups or universal parity claims.

Native and compact-status failures are rejected synchronously and the formal
experiment checks every returned output against its oracle. Detailed operation
receipts are deferred, and each formal A worker retains one separate diagnostic
receipt rather than a complete physical receipt for every timed call. The
original per-execution receipt requirement was therefore not fulfilled.

The implementation-entry endpoint was revised after an adverse observation.
Both first-result endpoints are lifecycle and import confounded. Post-import is
adverse on all four rows, with a maximum diagnostic block of 2.377129x. The
successor also regressed first-result medians relative to its predecessor while
improving prepared steady execution. Instrumentation qualification covers only
Arm A. No external human authoring or prevalence evidence is included.

Offline recount is not a new GPU execution, a product installation test, a
full historical-authority relocation, external review, or claim authorization.
