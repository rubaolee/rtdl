# Expected offline reconstruction

| Generation | Task | A/D prepared median | A/D observed max | A/C entry median | A/C post-import median |
| --- | --- | ---: | ---: | ---: | ---: |
| G0_ADA | CUSTOM_AABB_CLOSED_RELATION_COUNT_V1 | 1.076852x | 1.092253x | 0.653826x | 1.749327x |
| G0_ADA | BUILTIN_TRIANGLE_WEIGHTED_ALL_HIT_V1 | 1.175066x | 1.211025x | 0.642180x | 1.559788x |
| G1_AMPERE | CUSTOM_AABB_CLOSED_RELATION_COUNT_V1 | 1.094795x | 1.118811x | 0.681393x | 1.837415x |
| G1_AMPERE | BUILTIN_TRIANGLE_WEIGHTED_ALL_HIT_V1 | 1.133636x | 1.142675x | 0.618362x | 1.637468x |

The A/D maximum is descriptive; no A/D worst-block gate exists.

| Generation | Task | A/E prepared median | A/E post-import | A/E entry |
| --- | --- | ---: | ---: | ---: |
| G0_ADA | CUSTOM_AABB_CLOSED_RELATION_COUNT_V1 | 0.584438x | 1.305383x | 1.192358x |
| G0_ADA | BUILTIN_TRIANGLE_WEIGHTED_ALL_HIT_V1 | 0.903016x | 1.169262x | 1.079554x |
| G1_AMPERE | CUSTOM_AABB_CLOSED_RELATION_COUNT_V1 | 0.608228x | 1.261676x | 1.216714x |
| G1_AMPERE | BUILTIN_TRIANGLE_WEIGHTED_ALL_HIT_V1 | 0.922388x | 1.162775x | 1.137637x |

A/E post-import and entry are post hoc, non-gating diagnostics. The largest A/C post-import diagnostic block is 2.377129x.
