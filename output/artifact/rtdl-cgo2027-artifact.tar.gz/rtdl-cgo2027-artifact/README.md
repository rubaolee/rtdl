# Anonymous RTDL evidence projection

This package supports a standard-library-only offline recount of a frozen
two-generation performance projection. It does not run a GPU or install RTDL.

Quick start from the extracted package root:

```sh
python3 verify.py --artifact-root .
```

The verifier checks the exact member set and hashes, reconstructs 160 formal
worker medians from 20,480 retained nanosecond samples, recomputes all reported
ratios, and rejects changes to the frozen projection.
