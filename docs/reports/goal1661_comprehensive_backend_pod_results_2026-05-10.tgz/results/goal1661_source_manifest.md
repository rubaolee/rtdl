# Goal1660 v1.6.11 vs v1.0 Performance Matrix

## Verdict

`v1_6_11_vs_v1_0_perf_matrix_prepared_not_run`

This prepares a cross-version performance comparison for every public app, with one Embree row and one OptiX/NVIDIA RT row where applicable. It does not run the pod and does not authorize release or public speedup claims.

## Summary

- Current version under test: `v1.6.11`
- Baseline version: `v1.0`
- Public apps: `18`
- Matrix rows: `36`
- Planned comparable rows: `28`
- Blocked/excluded rows: `8`
- Pod required: `True`
- Non-decorative engine rule: rows without a real engine selector are excluded unless the script is explicitly OptiX-specific and the row is the OptiX row.
- Shared primitive rule: DBSCAN's Goal757 OptiX row is tracked for app coverage but excluded from independent timing because it shares the fixed-radius primitive row with outlier detection.

## Matrix

| App | Engine | Status | Scope |
| --- | --- | --- | --- |
| `database_analytics` | `embree` | `planned` | compact-summary DB prepared session only |
| `database_analytics` | `optix` | `planned` | compact-summary DB prepared session only |
| `graph_analytics` | `embree` | `excluded` | source command has no --backend/--mode selector; this row would be a decorative engine label rather than a real engine comparison |
| `graph_analytics` | `optix` | `planned` | visibility-edge and native graph-ray candidate-generation subpaths |
| `apple_rt_demo` | `embree` | `excluded` | app has no v1.6.11 Embree/OptiX pod command in Goal1659 matrix |
| `apple_rt_demo` | `optix` | `excluded` | app has no v1.6.11 Embree/OptiX pod command in Goal1659 matrix |
| `service_coverage_gaps` | `embree` | `planned` | prepared fixed-radius gap-summary decision |
| `service_coverage_gaps` | `optix` | `planned` | prepared fixed-radius gap-summary decision |
| `event_hotspot_screening` | `embree` | `planned` | prepared fixed-radius hotspot count-summary |
| `event_hotspot_screening` | `optix` | `planned` | prepared fixed-radius hotspot count-summary |
| `facility_knn_assignment` | `embree` | `planned` | coverage-threshold prepared decision only |
| `facility_knn_assignment` | `optix` | `planned` | coverage-threshold prepared decision only |
| `road_hazard_screening` | `embree` | `planned` | prepared segment/polygon compact road-hazard summary |
| `road_hazard_screening` | `optix` | `planned` | prepared segment/polygon compact road-hazard summary |
| `segment_polygon_hitcount` | `embree` | `planned` | prepared segment/polygon hit-count summary |
| `segment_polygon_hitcount` | `optix` | `planned` | prepared segment/polygon hit-count summary |
| `segment_polygon_anyhit_rows` | `embree` | `planned` | bounded pair-row output with overflow metadata |
| `segment_polygon_anyhit_rows` | `optix` | `planned` | bounded pair-row output with overflow metadata |
| `polygon_pair_overlap_area_rows` | `embree` | `planned` | native-assisted LSI/PIP candidate discovery plus exact-area continuation |
| `polygon_pair_overlap_area_rows` | `optix` | `planned` | native-assisted LSI/PIP candidate discovery plus exact-area continuation |
| `polygon_set_jaccard` | `embree` | `planned` | bounded candidate discovery plus exact Jaccard summary |
| `polygon_set_jaccard` | `optix` | `planned` | bounded candidate discovery plus exact Jaccard summary |
| `hausdorff_distance` | `embree` | `planned` | directed threshold decision only |
| `hausdorff_distance` | `optix` | `planned` | directed threshold decision only |
| `ann_candidate_search` | `embree` | `planned` | candidate-coverage threshold decision only |
| `ann_candidate_search` | `optix` | `planned` | candidate-coverage threshold decision only |
| `outlier_detection` | `embree` | `excluded` | source command has no --backend/--mode selector; this row would be a decorative engine label rather than a real engine comparison |
| `outlier_detection` | `optix` | `planned` | prepared fixed-radius scalar threshold-count |
| `dbscan_clustering` | `embree` | `excluded` | source command has no --backend/--mode selector; this row would be a decorative engine label rather than a real engine comparison |
| `dbscan_clustering` | `optix` | `shared_primitive_alias` | prepared fixed-radius scalar core-count |
| `robot_collision_screening` | `embree` | `planned` | prepared ray/triangle any-hit pose-count summary |
| `robot_collision_screening` | `optix` | `planned` | prepared ray/triangle any-hit pose-count summary |
| `barnes_hut_force_app` | `embree` | `planned` | node-coverage threshold decision only |
| `barnes_hut_force_app` | `optix` | `planned` | node-coverage threshold decision only |
| `hiprt_ray_triangle_hitcount` | `embree` | `excluded` | app has no v1.6.11 Embree/OptiX pod command in Goal1659 matrix |
| `hiprt_ray_triangle_hitcount` | `optix` | `excluded` | app has no v1.6.11 Embree/OptiX pod command in Goal1659 matrix |

## Pod Contract

Use two clean checkouts or worktrees on the pod: one at tag v1.0 and one at current main for the v1.6.11 release candidate.

Build Embree and OptiX separately in each checkout from that checkout's source. Record commit, GPU, driver, CUDA, OptiX SDK, and build command.

Compare only rows where both versions complete the same engine command with accepted parity/status. Missing v1.0 script or schema drift must be reported as unsupported, not as slower or faster.

## Boundary

This manifest prepares the v1.6.11 versus v1.0 performance comparison. It does not publish v1.6.11, authorize a tag, or authorize public speedup wording. Final evidence needs a pod because OptiX/NVIDIA RT rows require real NVIDIA RT hardware.
