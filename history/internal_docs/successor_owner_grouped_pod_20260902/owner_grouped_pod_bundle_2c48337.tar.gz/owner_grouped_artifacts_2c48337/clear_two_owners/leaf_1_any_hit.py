# rtdl.v4.generated_formal_numba_leaf.v1
# callback_ir_sha256=566cba0b01d6640becd6c39344fe79a73d829951a755b01835a22022e2a746af
# callback_abi_sha256=ec2e204893c211a362c074ce4936f95b6a6d323630bf7484e6c5cee226fc9811
def rtdl_v4_any_hit_566cba0b01d6640b(in_context_launch_index, in_hit_t, in_hit_hit_kind, in_payload_token, status_ok, status_error_code, status_stage, status_role, status_launch_index, status_error_site, status_effect_tag, status_nonce_word, status_invocation_mask, status_first_error_claimed, out_effect_tag, out_accept_continue_payload_token):
    status_ok[0] = 0
    status_error_code[0] = 0
    status_stage[0] = 3
    status_role[0] = 4
    status_launch_index[0] = in_context_launch_index
    status_error_site[0] = 0
    status_effect_tag[0] = 0
    status_nonce_word[0] = 1714909166
    status_invocation_mask[0] = 8
    status_first_error_claimed[0] = 0
    out_effect_tag[0] = 0
    out_accept_continue_payload_token[0] = 0
    if not math.isfinite(in_hit_t):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 1
        return
    status_error_code[0] = 0
    out_accept_continue_payload_token[0] = in_payload_token
    out_effect_tag[0] = 5
    status_effect_tag[0] = 5
    status_error_code[0] = 0
    status_ok[0] = 1
    return
