
#include <optix_device.h>
struct V4CurveOwnerGroupedStatus {
    unsigned int first_error_claimed, error_code, stage, role;
    unsigned long long launch_index;
    unsigned int error_site, effect_tag, nonce_word, invocation_mask;
};
struct V4CurveOwnerGroupedParams {
    OptixTraversableHandle traversable;
    const float* query_sx; const float* query_sy; const float* query_sz;
    const float* query_ex; const float* query_ey; const float* query_ez;
    const unsigned int* owner_ids;
    unsigned int primitive_count, query_count, owner_count;
    unsigned int* owner_hit_bits;
    unsigned int* query_completion_tokens;
    V4CurveOwnerGroupedStatus* status;
    unsigned long long* role_counters;
};
extern "C" { __constant__ V4CurveOwnerGroupedParams params; }
static __forceinline__ __device__ void v4_owner_grouped_first_error(
        unsigned int query, unsigned int code, unsigned int stage,
        unsigned int role, unsigned long long launch_index,
        unsigned int site, unsigned int effect, unsigned int nonce) {
    if (query >= params.query_count || code == 0u) return;
    V4CurveOwnerGroupedStatus* record = params.status + query;
    if (atomicCAS(&record->first_error_claimed, 0u, 1u) == 0u) {
        record->error_code = code; record->stage = stage; record->role = role;
        record->launch_index = launch_index; record->error_site = site;
        record->effect_tag = effect; record->nonce_word = nonce;
    }
}
static __forceinline__ __device__ bool v4_commit_leaf_status(
        unsigned int query, unsigned int ok, unsigned int error_code,
        unsigned int stage, unsigned int role, unsigned long long launch_index,
        unsigned int error_site, unsigned int effect_tag, unsigned int nonce,
        unsigned int invocation_mask, unsigned int first_error_claimed,
        unsigned int expected_stage, unsigned int expected_role,
        unsigned int expected_nonce) {
    const unsigned int expected_mask = 1u << (expected_role - 1u);
    const unsigned int expected_effect_tag = (expected_role == 2u ? 2u : expected_role == 4u ? 5u : expected_role == 6u ? 8u : expected_role == 7u ? 9u : 0u);
    const bool valid = ok == 1u && error_code == 0u &&
        stage == expected_stage && role == expected_role &&
        launch_index == (unsigned long long)query && error_site == 0u &&
        nonce == expected_nonce && invocation_mask == expected_mask &&
        first_error_claimed == 0u && expected_effect_tag != 0u &&
        effect_tag == expected_effect_tag;
    if (!valid) {
        v4_owner_grouped_first_error(
            query, error_code ? error_code : 0xffff6101u,
            stage, role, launch_index, error_site, effect_tag, nonce);
        return false;
    }
    atomicOr(&params.status[query].invocation_mask, invocation_mask);
    atomicAdd(params.role_counters + expected_role - 1u, 1ull);
    return true;
}

extern "C" __device__ unsigned long long rtdl_v4_make_ray_566cba0b01d6640b(unsigned long long, unsigned int, const float*, const float*, const float*, const float*, const float*, const float*, unsigned long long, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, float*, float*, float*, float*, float*, float*, unsigned int*, float*, float*);
extern "C" __device__ unsigned long long rtdl_v4_any_hit_566cba0b01d6640b(unsigned long long, float, unsigned int, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
extern "C" __device__ unsigned long long rtdl_v4_miss_566cba0b01d6640b(unsigned long long, float, float, float, float, float, float, float, float, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
extern "C" __device__ unsigned long long rtdl_v4_finalize_566cba0b01d6640b(unsigned long long, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);

extern "C" __global__ void __raygen__rtdl_v4_curve_owner_grouped() {
    const unsigned int query = optixGetLaunchIndex().x;
    if (query >= params.query_count) return;
    params.status[query] = {0u,0u,0u,0u,(unsigned long long)query,0u,0u,0u,0u};
    unsigned int mr_status_ok = 0;
    unsigned int mr_status_error_code = 0;
    unsigned int mr_status_stage = 0;
    unsigned int mr_status_role = 0;
    unsigned long long mr_status_launch_index = 0;
    unsigned int mr_status_error_site = 0;
    unsigned int mr_status_effect_tag = 0;
    unsigned int mr_status_nonce_word = 0;
    unsigned int mr_status_invocation_mask = 0;
    unsigned int mr_status_first_error_claimed = 0;
    unsigned int mr_out_effect_tag = 0;
    float mr_out_trace_request_direction_x = 0;
    float mr_out_trace_request_direction_y = 0;
    float mr_out_trace_request_direction_z = 0;
    float mr_out_trace_request_origin_x = 0;
    float mr_out_trace_request_origin_y = 0;
    float mr_out_trace_request_origin_z = 0;
    unsigned int mr_out_trace_request_payload_token = 0;
    float mr_out_trace_request_tmax = 0;
    float mr_out_trace_request_tmin = 0;
    (void)rtdl_v4_make_ray_566cba0b01d6640b(query, query, params.query_sx, params.query_sy, params.query_sz, params.query_ex, params.query_ey, params.query_ez, (unsigned long long)params.query_count, &mr_status_ok, &mr_status_error_code, &mr_status_stage, &mr_status_role, &mr_status_launch_index, &mr_status_error_site, &mr_status_effect_tag, &mr_status_nonce_word, &mr_status_invocation_mask, &mr_status_first_error_claimed, &mr_out_effect_tag, &mr_out_trace_request_direction_x, &mr_out_trace_request_direction_y, &mr_out_trace_request_direction_z, &mr_out_trace_request_origin_x, &mr_out_trace_request_origin_y, &mr_out_trace_request_origin_z, &mr_out_trace_request_payload_token, &mr_out_trace_request_tmax, &mr_out_trace_request_tmin);
    if (!v4_commit_leaf_status(query, mr_status_ok, mr_status_error_code, mr_status_stage, mr_status_role, mr_status_launch_index, mr_status_error_site, mr_status_effect_tag, mr_status_nonce_word, mr_status_invocation_mask, mr_status_first_error_claimed, 2u, 2u, 1440864722u)) { return; }
    if (mr_out_effect_tag != 2u) {
        v4_owner_grouped_first_error(query,0xffff6102u,0u,0u,query,0u,
                                     mr_out_effect_tag,0u); return;
    }
    unsigned int payload_token = mr_out_trace_request_payload_token;
    const float ray_tmin = mr_out_trace_request_tmin;
    const float ray_tmax = mr_out_trace_request_tmax;
    optixTrace(params.traversable,
        make_float3(mr_out_trace_request_origin_x,
                    mr_out_trace_request_origin_y,
                    mr_out_trace_request_origin_z),
        make_float3(mr_out_trace_request_direction_x,
                    mr_out_trace_request_direction_y,
                    mr_out_trace_request_direction_z),
        ray_tmin, ray_tmax, 0.0f, OptixVisibilityMask(255),
        OPTIX_RAY_FLAG_DISABLE_CLOSESTHIT, 0, 1, 0, payload_token);
    if (params.status[query].first_error_claimed != 0u) return;
    unsigned int fin_status_ok = 0;
    unsigned int fin_status_error_code = 0;
    unsigned int fin_status_stage = 0;
    unsigned int fin_status_role = 0;
    unsigned long long fin_status_launch_index = 0;
    unsigned int fin_status_error_site = 0;
    unsigned int fin_status_effect_tag = 0;
    unsigned int fin_status_nonce_word = 0;
    unsigned int fin_status_invocation_mask = 0;
    unsigned int fin_status_first_error_claimed = 0;
    unsigned int fin_out_effect_tag = 0;
    unsigned int fin_out_output_value_token = 0;
    (void)rtdl_v4_finalize_566cba0b01d6640b(query, payload_token, &fin_status_ok, &fin_status_error_code, &fin_status_stage, &fin_status_role, &fin_status_launch_index, &fin_status_error_site, &fin_status_effect_tag, &fin_status_nonce_word, &fin_status_invocation_mask, &fin_status_first_error_claimed, &fin_out_effect_tag, &fin_out_output_value_token);
    if (!v4_commit_leaf_status(query, fin_status_ok, fin_status_error_code, fin_status_stage, fin_status_role, fin_status_launch_index, fin_status_error_site, fin_status_effect_tag, fin_status_nonce_word, fin_status_invocation_mask, fin_status_first_error_claimed, 2u, 7u, 432555211u)) { return; }
    if (fin_out_effect_tag != 9u) {
        v4_owner_grouped_first_error(query,0xffff6103u,0u,0u,query,0u,
                                     fin_out_effect_tag,0u); return;
    }
    params.query_completion_tokens[query] =
        fin_out_output_value_token;
}

extern "C" __global__ void __anyhit__rtdl_v4_curve_owner_grouped() {
    const unsigned int query = optixGetLaunchIndex().x;
    const unsigned int primitive = optixGetPrimitiveIndex();
    if (query >= params.query_count || primitive >= params.primitive_count) {
        v4_owner_grouped_first_error(query,0xffff6104u,0u,0u,query,0u,0u,0u);
        optixTerminateRay(); return;
    }
    unsigned int payload_token = optixGetPayload_0();
    unsigned int ah_status_ok = 0;
    unsigned int ah_status_error_code = 0;
    unsigned int ah_status_stage = 0;
    unsigned int ah_status_role = 0;
    unsigned long long ah_status_launch_index = 0;
    unsigned int ah_status_error_site = 0;
    unsigned int ah_status_effect_tag = 0;
    unsigned int ah_status_nonce_word = 0;
    unsigned int ah_status_invocation_mask = 0;
    unsigned int ah_status_first_error_claimed = 0;
    unsigned int ah_out_effect_tag = 0;
    unsigned int ah_out_accept_continue_payload_token = 0;
    (void)rtdl_v4_any_hit_566cba0b01d6640b(query, optixGetRayTmax(), optixGetHitKind(), payload_token, &ah_status_ok, &ah_status_error_code, &ah_status_stage, &ah_status_role, &ah_status_launch_index, &ah_status_error_site, &ah_status_effect_tag, &ah_status_nonce_word, &ah_status_invocation_mask, &ah_status_first_error_claimed, &ah_out_effect_tag, &ah_out_accept_continue_payload_token);
    if (!v4_commit_leaf_status(query, ah_status_ok, ah_status_error_code, ah_status_stage, ah_status_role, ah_status_launch_index, ah_status_error_site, ah_status_effect_tag, ah_status_nonce_word, ah_status_invocation_mask, ah_status_first_error_claimed, 3u, 4u, 1714909166u)) { optixTerminateRay(); return; }
    if (ah_out_effect_tag != 5u) {
        v4_owner_grouped_first_error(query,0xffff6105u,0u,0u,query,0u,
                                     ah_out_effect_tag,0u);
        optixTerminateRay(); return;
    }
    const unsigned int owner = params.owner_ids[primitive];
    if (owner >= params.owner_count) {
        v4_owner_grouped_first_error(query,0xffff6106u,0u,0u,query,0u,
                                     ah_out_effect_tag,0u);
        optixTerminateRay(); return;
    }
    atomicOr(params.owner_hit_bits + owner, 1u);
    payload_token = ah_out_accept_continue_payload_token;
    optixSetPayload_0(payload_token);
    optixIgnoreIntersection();
}

extern "C" __global__ void __miss__rtdl_v4_curve_owner_grouped() {
    const unsigned int query = optixGetLaunchIndex().x;
    unsigned int payload_token = optixGetPayload_0();
    unsigned int ms_status_ok = 0;
    unsigned int ms_status_error_code = 0;
    unsigned int ms_status_stage = 0;
    unsigned int ms_status_role = 0;
    unsigned long long ms_status_launch_index = 0;
    unsigned int ms_status_error_site = 0;
    unsigned int ms_status_effect_tag = 0;
    unsigned int ms_status_nonce_word = 0;
    unsigned int ms_status_invocation_mask = 0;
    unsigned int ms_status_first_error_claimed = 0;
    unsigned int ms_out_effect_tag = 0;
    unsigned int ms_out_payload_payload_token = 0;
    (void)rtdl_v4_miss_566cba0b01d6640b(query, optixGetWorldRayOrigin().x, optixGetWorldRayOrigin().y, optixGetWorldRayOrigin().z, optixGetWorldRayDirection().x, optixGetWorldRayDirection().y, optixGetWorldRayDirection().z, optixGetRayTmin(), optixGetRayTmax(), payload_token, &ms_status_ok, &ms_status_error_code, &ms_status_stage, &ms_status_role, &ms_status_launch_index, &ms_status_error_site, &ms_status_effect_tag, &ms_status_nonce_word, &ms_status_invocation_mask, &ms_status_first_error_claimed, &ms_out_effect_tag, &ms_out_payload_payload_token);
    if (!v4_commit_leaf_status(query, ms_status_ok, ms_status_error_code, ms_status_stage, ms_status_role, ms_status_launch_index, ms_status_error_site, ms_status_effect_tag, ms_status_nonce_word, ms_status_invocation_mask, ms_status_first_error_claimed, 3u, 6u, 1078321996u)) { return; }
    if (ms_out_effect_tag != 8u) {
        v4_owner_grouped_first_error(query,0xffff6107u,0u,0u,query,0u,
                                     ms_out_effect_tag,0u); return;
    }
    optixSetPayload_0(ms_out_payload_payload_token);
}
