"""Public successor namespace for RTDL V4 round-linear built-in curves."""

from .v4_curve_physical_schema import (
    BUILTIN_CURVE_CONTRACT,
    CurvePhysicalSchemaError,
)
from .v4_public_builtin_curve import (
    BuiltinCurveFieldIds,
    BuiltinCurveStaticInput,
    CurveMotionSegmentBatch,
    MaterializedBuiltinCurveProgram,
    PreparedBuiltinCurveProgram,
    PublicCurveLifecycleError,
    V4CurveTarget,
    VerifiedBuiltinCurveProgram,
    VerifiedBuiltinCurveSource,
    compile_builtin_curve_callback_program,
    curve_first_contact_source,
    materialize_builtin_curve_callback_program,
    verify_builtin_curve_callback_source,
)


__all__ = sorted([
    "BUILTIN_CURVE_CONTRACT",
    "BuiltinCurveFieldIds",
    "BuiltinCurveStaticInput",
    "CurveMotionSegmentBatch",
    "CurvePhysicalSchemaError",
    "MaterializedBuiltinCurveProgram",
    "PreparedBuiltinCurveProgram",
    "PublicCurveLifecycleError",
    "V4CurveTarget",
    "VerifiedBuiltinCurveProgram",
    "VerifiedBuiltinCurveSource",
    "compile_builtin_curve_callback_program",
    "curve_first_contact_source",
    "materialize_builtin_curve_callback_program",
    "verify_builtin_curve_callback_source",
])
