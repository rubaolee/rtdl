# rtdl.v4.generated_formal_numba_leaf.v1
# callback_ir_sha256=027cab8547463df6c6089ab696daf6823ca299e51f182790c178f1c384182497
# callback_abi_sha256=96f38229bad52b99ccc0520f7df4582717ccd3089fceccff4cb7b0d8d69729fb
def rtdl_v4_make_ray_027cab8547463df6(in_context_launch_index, in_launch_id, in_queries_columns_origin_x, in_queries_columns_origin_y, in_queries_columns_origin_z, in_queries_columns_direction_x, in_queries_columns_direction_y, in_queries_columns_direction_z, in_queries_columns_tmax, in_queries_length, status_ok, status_error_code, status_stage, status_role, status_launch_index, status_error_site, status_effect_tag, status_nonce_word, status_invocation_mask, status_first_error_claimed, out_effect_tag, out_trace_request_direction_x, out_trace_request_direction_y, out_trace_request_direction_z, out_trace_request_origin_x, out_trace_request_origin_y, out_trace_request_origin_z, out_trace_request_payload_face_id, out_trace_request_payload_neighbor_cell, out_trace_request_payload_selected_cell, out_trace_request_tmax, out_trace_request_tmin):
    status_ok[0] = 0
    status_error_code[0] = 0
    status_stage[0] = 2
    status_role[0] = 2
    status_launch_index[0] = in_context_launch_index
    status_error_site[0] = 0
    status_effect_tag[0] = 0
    status_nonce_word[0] = 6882761
    status_invocation_mask[0] = 2
    status_first_error_claimed[0] = 0
    out_effect_tag[0] = 0
    out_trace_request_direction_x[0] = 0.0
    out_trace_request_direction_y[0] = 0.0
    out_trace_request_direction_z[0] = 0.0
    out_trace_request_origin_x[0] = 0.0
    out_trace_request_origin_y[0] = 0.0
    out_trace_request_origin_z[0] = 0.0
    out_trace_request_payload_face_id[0] = 0
    out_trace_request_payload_neighbor_cell[0] = 0
    out_trace_request_payload_selected_cell[0] = 0
    out_trace_request_tmax[0] = 0.0
    out_trace_request_tmin[0] = 0.0
    status_error_code[0] = 0
    if in_launch_id < 0 or in_launch_id >= in_queries_length:
        status_ok[0] = 0
        status_error_code[0] = 7
        status_error_site[0] = 1
        return
    if not math.isfinite(in_queries_columns_origin_x[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 2
        return
    if not math.isfinite(in_queries_columns_origin_y[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 3
        return
    if not math.isfinite(in_queries_columns_origin_z[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 4
        return
    if not math.isfinite(in_queries_columns_direction_x[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 5
        return
    if not math.isfinite(in_queries_columns_direction_y[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 6
        return
    if not math.isfinite(in_queries_columns_direction_z[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 7
        return
    if not math.isfinite(in_queries_columns_tmax[in_launch_id]):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 8
        return
    _rtdl_local_query = (in_queries_columns_origin_x[in_launch_id], in_queries_columns_origin_y[in_launch_id], in_queries_columns_origin_z[in_launch_id], in_queries_columns_direction_x[in_launch_id], in_queries_columns_direction_y[in_launch_id], in_queries_columns_direction_z[in_launch_id], in_queries_columns_tmax[in_launch_id],)
    _rtdl_local_initial = (4294967295, 4294967295, 4294967295,)
    if not math.isfinite(_rtdl_local_query[0]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 9
        return
    if not math.isfinite(_rtdl_local_query[1]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 10
        return
    if not math.isfinite(_rtdl_local_query[2]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 11
        return
    if not math.isfinite(_rtdl_local_query[3]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 12
        return
    if not math.isfinite(_rtdl_local_query[4]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 13
        return
    if not math.isfinite(_rtdl_local_query[5]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 14
        return
    if not math.isfinite(_f32(0.0)):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 15
        return
    if not math.isfinite(_rtdl_local_query[6]):
        status_ok[0] = 0
        status_error_code[0] = 3
        status_error_site[0] = 16
        return
    if ((_rtdl_local_query[3] == 0.0) and (_rtdl_local_query[4] == 0.0) and (_rtdl_local_query[5] == 0.0)) or (not (0.0 <= _f32(0.0) < _rtdl_local_query[6])): 
        status_ok[0] = 0
        status_error_code[0] = 9
        status_error_site[0] = 17
        return
    out_trace_request_origin_x[0] = _rtdl_local_query[0]
    out_trace_request_origin_y[0] = _rtdl_local_query[1]
    out_trace_request_origin_z[0] = _rtdl_local_query[2]
    out_trace_request_direction_x[0] = _rtdl_local_query[3]
    out_trace_request_direction_y[0] = _rtdl_local_query[4]
    out_trace_request_direction_z[0] = _rtdl_local_query[5]
    out_trace_request_tmin[0] = _f32(0.0)
    out_trace_request_tmax[0] = _rtdl_local_query[6]
    out_trace_request_payload_face_id[0] = _rtdl_local_initial[0]
    out_trace_request_payload_selected_cell[0] = _rtdl_local_initial[1]
    out_trace_request_payload_neighbor_cell[0] = _rtdl_local_initial[2]
    out_effect_tag[0] = 2
    status_effect_tag[0] = 2
    status_error_code[0] = 0
    status_ok[0] = 1
    return
