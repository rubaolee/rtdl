
@optix.payload
class FaceFirstPayload:
    face_id: u32
    selected_cell: u32
    neighbor_cell: u32

@optix.record
class Query:
    origin: vec3f32
    direction: vec3f32
    tmax: f32

@optix.output
class FaceFirstOutput:
    face_id: u32
    selected_cell: u32
    neighbor_cell: u32

@optix.program(payload=FaceFirstPayload, output=FaceFirstOutput, attributes=(), max_trace_depth=1, max_callable_depth=0)
class ParticleFaceFirstTransition:
    @optix.make_ray
    def make_ray(launch_id: u32, queries: ReadOnlyView[Query]) -> TraceRequest:
        query = queries[launch_id]
        initial = FaceFirstPayload(face_id=U32_MAX, selected_cell=U32_MAX, neighbor_cell=U32_MAX)
        return optix.trace_request(origin=query.origin, direction=query.direction, tmin=0.0, tmax=query.tmax, payload=initial)

    @optix.closest_hit
    def closest_hit(hit: TriangleHit, payload: FaceFirstPayload, first_side: ReadOnlyView[u32], second_side: ReadOnlyView[u32]) -> FaceFirstPayload:
        is_front = hit.hit_kind == FRONT_HIT_KIND
        selected = first_side[hit.primitive_index] if is_front else second_side[hit.primitive_index]
        neighbor = second_side[hit.primitive_index] if is_front else first_side[hit.primitive_index]
        updated = FaceFirstPayload(face_id=hit.primitive_index, selected_cell=selected, neighbor_cell=neighbor)
        return optix.payload(payload=updated)

    @optix.miss
    def miss(ray: Ray3f, payload: FaceFirstPayload) -> FaceFirstPayload:
        return optix.payload(payload=payload)

    @optix.finalize
    def finalize(payload: FaceFirstPayload) -> FaceFirstOutput:
        result = FaceFirstOutput(face_id=payload.face_id, selected_cell=payload.selected_cell, neighbor_cell=payload.neighbor_cell)
        return optix.output(value=result)
