# rtdl.v4.generated_formal_numba_leaf.v1
# callback_ir_sha256=027cab8547463df6c6089ab696daf6823ca299e51f182790c178f1c384182497
# callback_abi_sha256=96f38229bad52b99ccc0520f7df4582717ccd3089fceccff4cb7b0d8d69729fb
def rtdl_v4_miss_027cab8547463df6(in_context_launch_index, in_ray_origin_x, in_ray_origin_y, in_ray_origin_z, in_ray_direction_x, in_ray_direction_y, in_ray_direction_z, in_ray_tmin, in_ray_tmax, in_payload_face_id, in_payload_selected_cell, in_payload_neighbor_cell, status_ok, status_error_code, status_stage, status_role, status_launch_index, status_error_site, status_effect_tag, status_nonce_word, status_invocation_mask, status_first_error_claimed, out_effect_tag, out_payload_payload_face_id, out_payload_payload_neighbor_cell, out_payload_payload_selected_cell):
    status_ok[0] = 0
    status_error_code[0] = 0
    status_stage[0] = 3
    status_role[0] = 6
    status_launch_index[0] = in_context_launch_index
    status_error_site[0] = 0
    status_effect_tag[0] = 0
    status_nonce_word[0] = 2208848750
    status_invocation_mask[0] = 32
    status_first_error_claimed[0] = 0
    out_effect_tag[0] = 0
    out_payload_payload_face_id[0] = 0
    out_payload_payload_neighbor_cell[0] = 0
    out_payload_payload_selected_cell[0] = 0
    if not math.isfinite(in_ray_origin_x):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 1
        return
    if not math.isfinite(in_ray_origin_y):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 2
        return
    if not math.isfinite(in_ray_origin_z):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 3
        return
    if not math.isfinite(in_ray_direction_x):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 4
        return
    if not math.isfinite(in_ray_direction_y):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 5
        return
    if not math.isfinite(in_ray_direction_z):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 6
        return
    if not math.isfinite(in_ray_tmin):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 7
        return
    if not math.isfinite(in_ray_tmax):
        status_ok[0] = 0
        status_error_code[0] = 2
        status_error_site[0] = 8
        return
    status_error_code[0] = 0
    out_payload_payload_face_id[0] = in_payload_face_id
    out_payload_payload_selected_cell[0] = in_payload_selected_cell
    out_payload_payload_neighbor_cell[0] = in_payload_neighbor_cell
    out_effect_tag[0] = 8
    status_effect_tag[0] = 8
    status_error_code[0] = 0
    status_ok[0] = 1
    return
