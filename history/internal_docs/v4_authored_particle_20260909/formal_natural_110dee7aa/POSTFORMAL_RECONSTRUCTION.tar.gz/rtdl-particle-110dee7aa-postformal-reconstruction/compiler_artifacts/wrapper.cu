
#include <optix_device.h>

struct V4TriangleLaunchStatus {
    unsigned int first_error_claimed, error_code, stage, role;
    unsigned long long launch_index;
    unsigned int error_site, effect_tag, nonce_word, invocation_mask;
};
struct V4TriangleCompactControl {
    unsigned int schema_version, ok, first_error_claimed, error_code;
    unsigned long long validated_row_count;
    unsigned int required_invocation_mask, terminal_invocation_mask;
    unsigned int invalid_row_count;
    unsigned long long first_invalid_row;
    unsigned long long role_counters[7];
    unsigned long long success_status_d2h_bytes;
};
struct V4TriangleParams {
    OptixTraversableHandle traversable;
    const float* query_ox; const float* query_oy; const float* query_oz;
    const float* query_dx; const float* query_dy; const float* query_dz;
    const float* query_tmax;
    const unsigned int* front_values; const unsigned int* back_values;
    const float3* vertices; const uint3* triangle_indices;
    const unsigned int* boundary_owner;
    unsigned int primitive_count, query_count;
    unsigned int* output_0; unsigned int* output_1; unsigned int* output_2;
    unsigned int* output_rows;
    unsigned int* observed_primitive_index; unsigned int* observed_hit_kind;
    float* observed_barycentric_x; float* observed_barycentric_y;
    V4TriangleLaunchStatus* status; unsigned long long* role_counters;
    V4TriangleCompactControl* compact_control;
};
extern "C" { __constant__ V4TriangleParams params; }

static __forceinline__ __device__ void v4_first_error(
        unsigned int query, unsigned int code, unsigned int stage,
        unsigned int role, unsigned long long launch_index,
        unsigned int site, unsigned int effect, unsigned int nonce) {
    if (query >= params.query_count || code == 0u) return;
    if (params.status == nullptr) {
        V4TriangleCompactControl* control = params.compact_control;
        if (control == nullptr) return;
        atomicAdd(&control->invalid_row_count, 1u);
        atomicMin(&control->first_invalid_row, (unsigned long long)query);
        atomicExch(&control->ok, 0u);
        if (atomicCAS(&control->first_error_claimed, 0u, 1u) == 0u)
            control->error_code = code;
        return;
    }
    V4TriangleLaunchStatus* record = params.status + query;
    if (atomicCAS(&record->first_error_claimed, 0u, 1u) == 0u) {
        record->error_code = code; record->stage = stage; record->role = role;
        record->launch_index = launch_index; record->error_site = site;
        record->effect_tag = effect; record->nonce_word = nonce;
        if (params.compact_control != nullptr) {
            V4TriangleCompactControl* control = params.compact_control;
            atomicAdd(&control->invalid_row_count, 1u);
            atomicMin(&control->first_invalid_row,
                      (unsigned long long)query);
            atomicExch(&control->ok, 0u);
            if (atomicCAS(&control->first_error_claimed, 0u, 1u) == 0u)
                control->error_code = code;
        }
    }
}
static __forceinline__ __device__ bool v4_complete_query(
        unsigned int query) {
    if (params.status == nullptr) {
        if (params.compact_control == nullptr) return false;
        return true;
    }
    V4TriangleLaunchStatus* record = params.status + query;
    const unsigned int mask = record->invocation_mask;
    const unsigned int required = (1u << 1u) | (1u << 6u);
    const unsigned int terminal = mask & ((1u << 4u) | (1u << 5u));
    const bool valid = record->first_error_claimed == 0u &&
        record->error_code == 0u && record->stage == 0u &&
        record->role == 0u && record->error_site == 0u &&
        record->effect_tag == 0u && record->nonce_word == 0u &&
        (mask & ~((1u << 7u) - 1u)) == 0u &&
        (mask & required) == required &&
        (terminal == (1u << 4u) || terminal == (1u << 5u));
    if (!valid) {
        v4_first_error(
            query, 0xffff5001u, 0u, 0u, query, 0u, 0u, 0u);
        return false;
    }
    if (params.compact_control != nullptr)
        atomicAdd(&params.compact_control->validated_row_count, 1ull);
    return true;
}
static __forceinline__ __device__ bool v4_commit_leaf_status(
        unsigned int query, unsigned int ok, unsigned int error_code,
        unsigned int stage, unsigned int role, unsigned long long launch_index,
        unsigned int error_site, unsigned int effect_tag, unsigned int nonce,
        unsigned int invocation_mask, unsigned int first_error_claimed,
        unsigned int expected_stage, unsigned int expected_role,
        unsigned int expected_nonce) {
    const unsigned int expected_mask = 1u << (expected_role - 1u);
    const bool valid = ok == 1u && error_code == 0u &&
        stage == expected_stage && role == expected_role &&
        launch_index == (unsigned long long)query && error_site == 0u &&
        nonce == expected_nonce && invocation_mask == expected_mask &&
        first_error_claimed == 0u && effect_tag != 0u;
    if (!valid) {
        v4_first_error(query, error_code ? error_code : 0xffff1001u,
                       stage, role, launch_index, error_site, effect_tag, nonce);
        return false;
    }
    if (params.status != nullptr) {
        atomicOr(&params.status[query].invocation_mask, invocation_mask);
        atomicAdd(params.role_counters + expected_role - 1u, 1ull);
    } else if (expected_role == 5u || expected_role == 6u) {
        // Structured native-closest raygen invokes make-ray and finalize once
        // per successful query.  Only the closest/miss terminal choice needs
        // a contended runtime count in compact mode.
        atomicAdd(params.role_counters + expected_role - 1u, 1ull);
    }
    return true;
}

// RTDL_METADATA_ARGUMENT_2=primitive_front_value;SOURCE=params.front_values
// RTDL_METADATA_ARGUMENT_3=primitive_back_value;SOURCE=params.back_values
// RTDL_INLINE_STRAIGHT_LINE_PROJECTION=enabled;SHA256=fa0a475c5bf804ac1ce6a63fbac962696730e6c1ea5a86733ddabb85c9f98805
extern "C" __device__ unsigned long long rtdl_v4_make_ray_027cab8547463df6(unsigned long long, unsigned int, const float*, const float*, const float*, const float*, const float*, const float*, const float*, unsigned long long, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, float*, float*, float*, float*, float*, float*, unsigned int*, unsigned int*, unsigned int*, float*, float*);
extern "C" __device__ unsigned long long rtdl_v4_closest_hit_027cab8547463df6(unsigned long long, float, unsigned int, unsigned int, float, float, unsigned int, unsigned int, unsigned int, const unsigned int*, unsigned long long, const unsigned int*, unsigned long long, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
extern "C" __device__ unsigned long long rtdl_v4_miss_027cab8547463df6(unsigned long long, float, float, float, float, float, float, float, float, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
extern "C" __device__ unsigned long long rtdl_v4_finalize_027cab8547463df6(unsigned long long, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned long long*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);

extern "C" __global__ void __raygen__rtdl_v4_triangle() {
    const unsigned int query = optixGetLaunchIndex().x;
    if (query >= params.query_count) return;

    if (params.status == nullptr) {
        if ((unsigned long long)(query) >= (unsigned long long)(params.query_count)) { v4_first_error(query, 0xffff1101u, 0u, 0u, query, 0u, 0u, 0u); return; }
        const float _rtdl_inline_make_ray_let_1_0 = params.query_ox[query];
        const float _rtdl_inline_make_ray_let_1_1 = params.query_oy[query];
        const float _rtdl_inline_make_ray_let_1_2 = params.query_oz[query];
        const float _rtdl_inline_make_ray_let_1_3 = params.query_dx[query];
        const float _rtdl_inline_make_ray_let_1_4 = params.query_dy[query];
        const float _rtdl_inline_make_ray_let_1_5 = params.query_dz[query];
        const float _rtdl_inline_make_ray_let_1_6 = params.query_tmax[query];
        const unsigned int _rtdl_inline_make_ray_let_2_0 = 4294967295u;
        const unsigned int _rtdl_inline_make_ray_let_2_1 = 4294967295u;
        const unsigned int _rtdl_inline_make_ray_let_2_2 = 4294967295u;
        unsigned int payload_0 = _rtdl_inline_make_ray_let_2_0;
        unsigned int payload_1 = _rtdl_inline_make_ray_let_2_1;
        unsigned int payload_2 = _rtdl_inline_make_ray_let_2_2;
        optixTrace(params.traversable,
            make_float3(_rtdl_inline_make_ray_let_1_0, _rtdl_inline_make_ray_let_1_1,
                        _rtdl_inline_make_ray_let_1_2),
            make_float3(_rtdl_inline_make_ray_let_1_3,
                        _rtdl_inline_make_ray_let_1_4,
                        _rtdl_inline_make_ray_let_1_5),
            __int_as_float(0x00000000u), _rtdl_inline_make_ray_let_1_6, 0.0f,
            OptixVisibilityMask(255), OPTIX_RAY_FLAG_DISABLE_ANYHIT,
            0, 1, 0, payload_0, payload_1, payload_2);
        if (params.compact_control != nullptr &&
                params.compact_control->first_error_claimed != 0u) return;
        const unsigned int _rtdl_inline_finalize_let_1_0 = payload_0;
        const unsigned int _rtdl_inline_finalize_let_1_1 = payload_1;
        const unsigned int _rtdl_inline_finalize_let_1_2 = payload_2;
        if (params.output_rows != nullptr) {
            const unsigned int row = query * 3u;
            params.output_rows[row + 0u] = _rtdl_inline_finalize_let_1_0;
            params.output_rows[row + 1u] = _rtdl_inline_finalize_let_1_1;
            params.output_rows[row + 2u] = _rtdl_inline_finalize_let_1_2;
        } else {
            params.output_0[query] = _rtdl_inline_finalize_let_1_0;
            params.output_1[query] = _rtdl_inline_finalize_let_1_1;
            params.output_2[query] = _rtdl_inline_finalize_let_1_2;
        }
        return;
    }

    if (params.status != nullptr)
        params.status[query] = {0u, 0u, 0u, 0u, (unsigned long long)query, 0u, 0u, 0u, 0u};
    if (params.observed_primitive_index != nullptr)
        params.observed_primitive_index[query] = 0xffffffffu;
    if (params.observed_hit_kind != nullptr)
        params.observed_hit_kind[query] = 0xffffffffu;
    if (params.observed_barycentric_x != nullptr)
        params.observed_barycentric_x[query] = __int_as_float(0x7fffffffu);
    if (params.observed_barycentric_y != nullptr)
        params.observed_barycentric_y[query] = __int_as_float(0x7fffffffu);
    unsigned int mr_status_ok = 0;
    unsigned int mr_status_error_code = 0;
    unsigned int mr_status_stage = 0;
    unsigned int mr_status_role = 0;
    unsigned long long mr_status_launch_index = 0;
    unsigned int mr_status_error_site = 0;
    unsigned int mr_status_effect_tag = 0;
    unsigned int mr_status_nonce_word = 0;
    unsigned int mr_status_invocation_mask = 0;
    unsigned int mr_status_first_error_claimed = 0;
    unsigned int mr_out_effect_tag = 0;
    float mr_out_trace_request_direction_x = 0;
    float mr_out_trace_request_direction_y = 0;
    float mr_out_trace_request_direction_z = 0;
    float mr_out_trace_request_origin_x = 0;
    float mr_out_trace_request_origin_y = 0;
    float mr_out_trace_request_origin_z = 0;
    unsigned int mr_out_trace_request_payload_face_id = 0;
    unsigned int mr_out_trace_request_payload_neighbor_cell = 0;
    unsigned int mr_out_trace_request_payload_selected_cell = 0;
    float mr_out_trace_request_tmax = 0;
    float mr_out_trace_request_tmin = 0;
    (void)rtdl_v4_make_ray_027cab8547463df6(query, query, params.query_ox, params.query_oy, params.query_oz, params.query_dx, params.query_dy, params.query_dz, params.query_tmax, (unsigned long long)params.query_count, &mr_status_ok, &mr_status_error_code, &mr_status_stage, &mr_status_role, &mr_status_launch_index, &mr_status_error_site, &mr_status_effect_tag, &mr_status_nonce_word, &mr_status_invocation_mask, &mr_status_first_error_claimed, &mr_out_effect_tag, &mr_out_trace_request_direction_x, &mr_out_trace_request_direction_y, &mr_out_trace_request_direction_z, &mr_out_trace_request_origin_x, &mr_out_trace_request_origin_y, &mr_out_trace_request_origin_z, &mr_out_trace_request_payload_face_id, &mr_out_trace_request_payload_neighbor_cell, &mr_out_trace_request_payload_selected_cell, &mr_out_trace_request_tmax, &mr_out_trace_request_tmin);
    if (!v4_commit_leaf_status(query, mr_status_ok, mr_status_error_code, mr_status_stage, mr_status_role, mr_status_launch_index, mr_status_error_site, mr_status_effect_tag, mr_status_nonce_word, mr_status_invocation_mask, mr_status_first_error_claimed, 2u, 2u, 6882761u)) { return; }
    if (mr_out_effect_tag != 2u) {
        v4_first_error(query, 0xffff1002u, 0u, 0u, query, 0u, mr_out_effect_tag, 0u); return;
    }
    unsigned int payload_0 = mr_out_trace_request_payload_face_id;
    unsigned int payload_1 = mr_out_trace_request_payload_selected_cell;
    unsigned int payload_2 = mr_out_trace_request_payload_neighbor_cell;
    optixTrace(params.traversable,
        make_float3(mr_out_trace_request_origin_x, mr_out_trace_request_origin_y, mr_out_trace_request_origin_z),
        make_float3(mr_out_trace_request_direction_x, mr_out_trace_request_direction_y, mr_out_trace_request_direction_z),
        mr_out_trace_request_tmin, mr_out_trace_request_tmax, 0.0f,
        OptixVisibilityMask(255), OPTIX_RAY_FLAG_DISABLE_ANYHIT,
        0, 1, 0, payload_0, payload_1, payload_2);
    if (params.status != nullptr &&
            params.status[query].first_error_claimed != 0u) return;
    unsigned int fin_status_ok = 0;
    unsigned int fin_status_error_code = 0;
    unsigned int fin_status_stage = 0;
    unsigned int fin_status_role = 0;
    unsigned long long fin_status_launch_index = 0;
    unsigned int fin_status_error_site = 0;
    unsigned int fin_status_effect_tag = 0;
    unsigned int fin_status_nonce_word = 0;
    unsigned int fin_status_invocation_mask = 0;
    unsigned int fin_status_first_error_claimed = 0;
    unsigned int fin_out_effect_tag = 0;
    unsigned int fin_out_output_value_face_id = 0;
    unsigned int fin_out_output_value_neighbor_cell = 0;
    unsigned int fin_out_output_value_selected_cell = 0;
    (void)rtdl_v4_finalize_027cab8547463df6(query, payload_0, payload_1, payload_2, &fin_status_ok, &fin_status_error_code, &fin_status_stage, &fin_status_role, &fin_status_launch_index, &fin_status_error_site, &fin_status_effect_tag, &fin_status_nonce_word, &fin_status_invocation_mask, &fin_status_first_error_claimed, &fin_out_effect_tag, &fin_out_output_value_face_id, &fin_out_output_value_neighbor_cell, &fin_out_output_value_selected_cell);
    if (!v4_commit_leaf_status(query, fin_status_ok, fin_status_error_code, fin_status_stage, fin_status_role, fin_status_launch_index, fin_status_error_site, fin_status_effect_tag, fin_status_nonce_word, fin_status_invocation_mask, fin_status_first_error_claimed, 2u, 7u, 4050619692u)) { return; }
    if (fin_out_effect_tag != 9u) {
        v4_first_error(query, 0xffff1003u, 0u, 0u, query, 0u, fin_out_effect_tag, 0u); return;
    }
    if (params.output_rows != nullptr) {
        const unsigned int row = query * 3u;
        params.output_rows[row + 0u] = fin_out_output_value_face_id;
        params.output_rows[row + 1u] = fin_out_output_value_selected_cell;
        params.output_rows[row + 2u] = fin_out_output_value_neighbor_cell;
    } else {
        params.output_0[query] = fin_out_output_value_face_id;
        params.output_1[query] = fin_out_output_value_selected_cell;
        params.output_2[query] = fin_out_output_value_neighbor_cell;
    }
    if (!v4_complete_query(query)) return;
}

extern "C" __global__ void __closesthit__rtdl_v4_triangle_native() {
    const unsigned int query = optixGetLaunchIndex().x;
    const unsigned int primitive_index = optixGetPrimitiveIndex();
    const unsigned int hit_kind = optixGetHitKind();
    const float2 barycentrics = optixGetTriangleBarycentrics();
    if (query >= params.query_count || primitive_index >= params.primitive_count ||
            (hit_kind != 0xfeu && hit_kind != 0xffu) ||
            !isfinite(optixGetRayTmax()) || !isfinite(barycentrics.x) ||
            !isfinite(barycentrics.y)) {
        v4_first_error(query, 0xffff1004u, 0u, 0u, query, 0u, 0u, 0u); return;
    }

    if (params.status == nullptr) {
        const bool _rtdl_inline_closest_hit_let_1_0 = (hit_kind == 254u);
        if ((unsigned long long)(primitive_index) >= (unsigned long long)(params.primitive_count)) { v4_first_error(query, 0xffff1102u, 0u, 0u, query, 0u, 0u, 0u); return; }
        const unsigned int _rtdl_inline_closest_hit_let_2_0 = (_rtdl_inline_closest_hit_let_1_0 ? params.front_values[primitive_index] : params.back_values[primitive_index]);
        const unsigned int _rtdl_inline_closest_hit_let_3_0 = (_rtdl_inline_closest_hit_let_1_0 ? params.back_values[primitive_index] : params.front_values[primitive_index]);
        const unsigned int _rtdl_inline_closest_hit_let_4_0 = primitive_index;
        const unsigned int _rtdl_inline_closest_hit_let_4_1 = _rtdl_inline_closest_hit_let_2_0;
        const unsigned int _rtdl_inline_closest_hit_let_4_2 = _rtdl_inline_closest_hit_let_3_0;
        optixSetPayload_0(_rtdl_inline_closest_hit_let_4_0);
        optixSetPayload_1(_rtdl_inline_closest_hit_let_4_1);
        optixSetPayload_2(_rtdl_inline_closest_hit_let_4_2);
        atomicAdd(params.role_counters + 4u, 1ull);
        return;
    }

    if (params.observed_primitive_index != nullptr)
        params.observed_primitive_index[query] = primitive_index;
    if (params.observed_hit_kind != nullptr)
        params.observed_hit_kind[query] = hit_kind;
    if (params.observed_barycentric_x != nullptr)
        params.observed_barycentric_x[query] = barycentrics.x;
    if (params.observed_barycentric_y != nullptr)
        params.observed_barycentric_y[query] = barycentrics.y;
    unsigned int ch_status_ok = 0;
    unsigned int ch_status_error_code = 0;
    unsigned int ch_status_stage = 0;
    unsigned int ch_status_role = 0;
    unsigned long long ch_status_launch_index = 0;
    unsigned int ch_status_error_site = 0;
    unsigned int ch_status_effect_tag = 0;
    unsigned int ch_status_nonce_word = 0;
    unsigned int ch_status_invocation_mask = 0;
    unsigned int ch_status_first_error_claimed = 0;
    unsigned int ch_out_effect_tag = 0;
    unsigned int ch_out_payload_payload_face_id = 0;
    unsigned int ch_out_payload_payload_neighbor_cell = 0;
    unsigned int ch_out_payload_payload_selected_cell = 0;
    (void)rtdl_v4_closest_hit_027cab8547463df6(query, optixGetRayTmax(), primitive_index, hit_kind, barycentrics.x, barycentrics.y, optixGetPayload_0(), optixGetPayload_1(), optixGetPayload_2(), params.front_values, (unsigned long long)params.primitive_count, params.back_values, (unsigned long long)params.primitive_count, &ch_status_ok, &ch_status_error_code, &ch_status_stage, &ch_status_role, &ch_status_launch_index, &ch_status_error_site, &ch_status_effect_tag, &ch_status_nonce_word, &ch_status_invocation_mask, &ch_status_first_error_claimed, &ch_out_effect_tag, &ch_out_payload_payload_face_id, &ch_out_payload_payload_neighbor_cell, &ch_out_payload_payload_selected_cell);
    if (!v4_commit_leaf_status(query, ch_status_ok, ch_status_error_code, ch_status_stage, ch_status_role, ch_status_launch_index, ch_status_error_site, ch_status_effect_tag, ch_status_nonce_word, ch_status_invocation_mask, ch_status_first_error_claimed, 3u, 5u, 3825738357u)) { return; }
    if (ch_out_effect_tag != 8u) {
        v4_first_error(query, 0xffff1005u, 0u, 0u, query, 0u, ch_out_effect_tag, 0u); return;
    }
    optixSetPayload_0(ch_out_payload_payload_face_id);
    optixSetPayload_1(ch_out_payload_payload_selected_cell);
    optixSetPayload_2(ch_out_payload_payload_neighbor_cell);
}

extern "C" __global__ void __miss__rtdl_v4_triangle() {
    const unsigned int query = optixGetLaunchIndex().x;
    if (query >= params.query_count) return;
    const float3 ray_origin = optixGetWorldRayOrigin();
    const float3 ray_direction = optixGetWorldRayDirection();

    if (params.status == nullptr) {

        optixSetPayload_0(optixGetPayload_0());
        optixSetPayload_1(optixGetPayload_1());
        optixSetPayload_2(optixGetPayload_2());
        atomicAdd(params.role_counters + 5u, 1ull);
        return;
    }

    unsigned int ms_status_ok = 0;
    unsigned int ms_status_error_code = 0;
    unsigned int ms_status_stage = 0;
    unsigned int ms_status_role = 0;
    unsigned long long ms_status_launch_index = 0;
    unsigned int ms_status_error_site = 0;
    unsigned int ms_status_effect_tag = 0;
    unsigned int ms_status_nonce_word = 0;
    unsigned int ms_status_invocation_mask = 0;
    unsigned int ms_status_first_error_claimed = 0;
    unsigned int ms_out_effect_tag = 0;
    unsigned int ms_out_payload_payload_face_id = 0;
    unsigned int ms_out_payload_payload_neighbor_cell = 0;
    unsigned int ms_out_payload_payload_selected_cell = 0;
    (void)rtdl_v4_miss_027cab8547463df6(query, ray_origin.x, ray_origin.y, ray_origin.z, ray_direction.x, ray_direction.y, ray_direction.z, optixGetRayTmin(), optixGetRayTmax(), optixGetPayload_0(), optixGetPayload_1(), optixGetPayload_2(), &ms_status_ok, &ms_status_error_code, &ms_status_stage, &ms_status_role, &ms_status_launch_index, &ms_status_error_site, &ms_status_effect_tag, &ms_status_nonce_word, &ms_status_invocation_mask, &ms_status_first_error_claimed, &ms_out_effect_tag, &ms_out_payload_payload_face_id, &ms_out_payload_payload_neighbor_cell, &ms_out_payload_payload_selected_cell);
    if (!v4_commit_leaf_status(query, ms_status_ok, ms_status_error_code, ms_status_stage, ms_status_role, ms_status_launch_index, ms_status_error_site, ms_status_effect_tag, ms_status_nonce_word, ms_status_invocation_mask, ms_status_first_error_claimed, 3u, 6u, 2208848750u)) { return; }
    if (ms_out_effect_tag != 8u) {
        v4_first_error(query, 0xffff1006u, 0u, 0u, query, 0u, ms_out_effect_tag, 0u); return;
    }
    optixSetPayload_0(ms_out_payload_payload_face_id);
    optixSetPayload_1(ms_out_payload_payload_selected_cell);
    optixSetPayload_2(ms_out_payload_payload_neighbor_cell);
}
