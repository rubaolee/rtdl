#!/usr/bin/env python3
"""Verify the durable Particle handoff without importing RTDL."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import numpy as np


def sha256(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def array_digest(value: np.ndarray) -> str:
    value = np.ascontiguousarray(value, dtype=np.uint32)
    result = hashlib.sha256()
    result.update(value.dtype.str.encode("ascii"))
    result.update(str(tuple(value.shape)).encode("ascii"))
    result.update(memoryview(value).cast("B"))
    return result.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    root = args.root.resolve(strict=True)

    expected_rows: dict[str, str] = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        expected_rows[relative] = digest
    for relative, digest in expected_rows.items():
        path = root / relative
        if sha256(path) != digest:
            raise RuntimeError(f"member hash differs: {relative}")

    queries = np.load(
        root / "data/transition_ensemble/queries_f32.npy",
        mmap_mode="r", allow_pickle=False,
    )
    oracle = np.load(
        root / "data/transition_ensemble/expected_u32.npy",
        mmap_mode="r", allow_pickle=False,
    )
    observed = np.load(
        root / "data/observed_output_u32.npy",
        mmap_mode="r", allow_pickle=False,
    )
    if queries.shape != (160_000_000, 7) or queries.dtype != np.float32:
        raise RuntimeError("query shape/dtype differs")
    if oracle.shape != (160_000_000, 3) or oracle.dtype != np.uint32:
        raise RuntimeError("oracle shape/dtype differs")
    if observed.shape != (160_000_000, 3) or observed.dtype != np.uint32:
        raise RuntimeError("observed output shape/dtype differs")

    # The independent ensemble stores (selected, neighbor, face); the public
    # output contract is (face, selected, neighbor). Compare in bounded chunks.
    block = 1_000_000
    for start in range(0, len(observed), block):
        stop = min(start + block, len(observed))
        if not np.array_equal(observed[start:stop], oracle[start:stop, (2, 0, 1)]):
            raise RuntimeError(f"observed output differs in rows [{start},{stop})")
    digest = array_digest(observed)
    if digest != "6c4ec71524be3d7b241c3d66c4cd06a5aa7089b3948bf1d8dd8aab550f0dec89":
        raise RuntimeError("observed output array digest differs")
    print(
        "PASS durable Particle handoff: "
        f"{len(expected_rows)} files; output={digest}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
