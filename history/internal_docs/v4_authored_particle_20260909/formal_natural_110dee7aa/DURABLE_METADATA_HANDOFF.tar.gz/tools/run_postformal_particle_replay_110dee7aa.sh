#!/usr/bin/env bash
set -euo pipefail

export CUDA_HOME=/tmp/rtdl-crossgpu/venv/lib/python3.12/site-packages/nvidia/cuda_nvcc
export NUMBA_CUDA_USE_NVIDIA_BINDING=1
export LD_LIBRARY_PATH=/tmp/rtdl-crossgpu/venv/lib/python3.12/site-packages/nvidia/cuda_nvrtc/lib:/tmp/rtdl-crossgpu/venv/lib/python3.12/site-packages/optix:/usr/local/cuda-12.8/targets/x86_64-linux/lib
export PYTHONPATH=/tmp/rtdl-particle-110dee7aa/src:/tmp/rtdl-particle-110dee7aa

cd /tmp/rtdl-particle-110dee7aa
/tmp/rtdl-crossgpu/venv/bin/python \
  /workspace/rtdl-particle-110dee7aa-durable/tools/postformal_particle_reconstruct.py \
  --source-root /tmp/rtdl-particle-110dee7aa \
  --archive /tmp/rtdl-authored-particle-formal-110dee7aa.tar.gz \
  --base-particle-dir /tmp/rtdl-authored-particle-data-ba8c93eed/particle \
  --ensemble-dir /dev/shm/rtdl-particle-transition-ensemble-160m-63c35f720 \
  --native /tmp/rtdl-authored-particle-native-110dee7aa/librtdl_optix.so \
  --optix-include /tmp/rtdl-crossgpu/optix-dev/include \
  --cuda-include /usr/local/cuda-12.8/targets/x86_64-linux/include \
  --output /workspace/rtdl-particle-110dee7aa-durable/postformal_replay \
  --save-observed-output \
    /workspace/rtdl-particle-110dee7aa-durable/data/observed_output_u32.npy
