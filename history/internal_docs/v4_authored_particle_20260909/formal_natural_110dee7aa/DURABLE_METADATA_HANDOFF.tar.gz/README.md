# Particle `110dee7aa` durable data handoff

Date: 2026-09-09

This directory is a post-formal durability handoff on the RunPod network
volume. It does not change or extend the original formal timing transaction.

## Identity and boundary

- Source commit: `110dee7aa11e57e984cc2509163e021d787c692a`.
- Source tree: `1e549d791fedd23659bb0e0636747016938cd1c4`.
- Original formal archive SHA-256:
  `42ebdf176e9625c8c95d7b2e2504ddccc70b42ed4b692fe3360f3c2c5b08bccf`.
- The original timed workers did not retain generated compiler bytes, complete
  traversal receipts, or output arrays.
- `postformal_replay/` and `data/observed_output_u32.npy` are from a later,
  untimed same-source/toolchain replay. They are not original timed-worker
  bytes and are not pooled into the formal estimator.
- The post-formal reconstructed program/executable identities match all eight
  original RTDL worker records, and the replay output matches the transformed
  independent oracle.

## Contents

- `data/transition_ensemble/`: original 160M distinct-query ensemble and
  independent adjacency oracle.
- `data/base_particle/`: real Particle mesh and the smaller base fixture.
- `data/observed_output_u32.npy`: complete 160M-by-3 U32 face-first output from
  the post-formal replay.
- `artifacts/native/`: measured RTDL native DSO and build record.
- `artifacts/pyoptix/`: measured public-PyOptiX PTX and build record.
- `artifacts/formal/`: immutable original archive, preregistration and recount.
- `artifacts/source_110dee7aa.tar.gz`: exact Git source-tree archive. It lacks
  `.git`; use a clean Git checkout at the exact commit for fail-closed replay.
- `postformal_replay/`: 13 generated compiler files, a complete traversal and
  lifecycle receipt, and the reconstruction manifest.
- `tools/postformal_particle_reconstruct.py`: exact post-formal export/replay
  tool used for the saved observed output.
- `tools/run_postformal_particle_replay_110dee7aa.sh`: original command using
  the still-live `/tmp` source/data locations.
- `tools/run_postformal_particle_replay_from_durable_110dee7aa.sh`: equivalent
  command reading the durable data/artifacts. Set `SOURCE_ROOT` to a clean Git
  checkout at exact commit `110dee7aa`.
- `tools/verify_durable_particle_110dee7aa.py`: hashes every registered member,
  validates shapes/dtypes, and compares the observed output to the independent
  oracle column transformation.
- `PEAK_MEMORY_DIAGNOSTIC.json` and its exact tool: a separate descriptive
  `A,C,C,A` NVML/RSS sampling run. Monitoring perturbs latency, and the result
  is not formal timing evidence.

`SHA256SUMS` and `FILE_SIZES.tsv` cover all payload files except themselves.
`ENVIRONMENT.txt` and `PIP_FREEZE.txt` record the producing pod environment.

RunPod network-volume persistence is stronger than `/tmp` or `/dev/shm`, but
it is not repository custody and survives only while the owner retains the
underlying network volume. The multi-gigabyte files are not in Git.
