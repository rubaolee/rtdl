
// helpers -------------------------------------------------------------------

template <typename T>
static void set_error(const std::string& msg, T* buf, size_t sz) {
    if (!buf || !sz) return;
    size_t n = std::min(sz - 1, msg.size());
    std::memcpy(buf, msg.data(), n);
    buf[n] = '\0';
}

struct Bounds2D {
    double min_x, min_y, max_x, max_y;
};

static bool segment_intersection_denominator_is_degenerate(
        double denom,
        double rx,
        double ry,
        double sx,
        double sy)
{
    const double scale = std::hypot(rx, ry) * std::hypot(sx, sy);
    const double threshold = 64.0 * std::numeric_limits<double>::epsilon() * std::max(1.0, scale);
    return std::abs(denom) <= threshold;
}

#define VK_CHECK(call)                                                         \
    do {                                                                       \
        VkResult _r = (call);                                                  \
        if (_r != VK_SUCCESS)                                                  \
            throw std::runtime_error(std::string("Vulkan error " #call ": ")  \
                                     + std::to_string((int)_r));               \
    } while (0)

// extension function-pointer table -----------------------------------------
// Base Vulkan functions (vkCreateInstance, vkEnumeratePhysicalDevices, etc.)
// are provided by -lvulkan at link time.  Extension functions are loaded
// dynamically via vkGetDeviceProcAddr / vkGetInstanceProcAddr.

struct VkFunctions {
    // Core 1.2 (instance-level)
    PFN_vkGetPhysicalDeviceProperties2 vkGetPhysicalDeviceProperties2;
    // Core 1.2 (device-level, promoted from KHR)
    PFN_vkGetBufferDeviceAddress vkGetBufferDeviceAddress;
    // VK_KHR_acceleration_structure
    PFN_vkCreateAccelerationStructureKHR          vkCreateAccelerationStructureKHR;
    PFN_vkDestroyAccelerationStructureKHR         vkDestroyAccelerationStructureKHR;
    PFN_vkGetAccelerationStructureBuildSizesKHR   vkGetAccelerationStructureBuildSizesKHR;
    PFN_vkCmdBuildAccelerationStructuresKHR       vkCmdBuildAccelerationStructuresKHR;
    PFN_vkGetAccelerationStructureDeviceAddressKHR vkGetAccelerationStructureDeviceAddressKHR;
    // VK_KHR_ray_tracing_pipeline
    PFN_vkCreateRayTracingPipelinesKHR       vkCreateRayTracingPipelinesKHR;
    PFN_vkGetRayTracingShaderGroupHandlesKHR vkGetRayTracingShaderGroupHandlesKHR;
    PFN_vkCmdTraceRaysKHR                    vkCmdTraceRaysKHR;
};

#define LOAD_DEV(name) \
    fns.name = reinterpret_cast<PFN_##name>(vkGetDeviceProcAddr(dev, #name)); \
    if (!fns.name) throw std::runtime_error("failed to load Vulkan function: " #name)

static VkFunctions load_functions(VkInstance inst, VkDevice dev) {
    VkFunctions fns{};
    fns.vkGetPhysicalDeviceProperties2 =
        reinterpret_cast<PFN_vkGetPhysicalDeviceProperties2>(
            vkGetInstanceProcAddr(inst, "vkGetPhysicalDeviceProperties2"));
    LOAD_DEV(vkGetBufferDeviceAddress);
    LOAD_DEV(vkCreateAccelerationStructureKHR);
    LOAD_DEV(vkDestroyAccelerationStructureKHR);
    LOAD_DEV(vkGetAccelerationStructureBuildSizesKHR);
    LOAD_DEV(vkCmdBuildAccelerationStructuresKHR);
    LOAD_DEV(vkGetAccelerationStructureDeviceAddressKHR);
    LOAD_DEV(vkCreateRayTracingPipelinesKHR);
    LOAD_DEV(vkGetRayTracingShaderGroupHandlesKHR);
    LOAD_DEV(vkCmdTraceRaysKHR);
    return fns;
}

// Vulkan context ------------------------------------------------------------

struct VkContext {
    VkInstance       instance     = VK_NULL_HANDLE;
    VkPhysicalDevice phys_dev     = VK_NULL_HANDLE;
    VkDevice         device       = VK_NULL_HANDLE;
    VkQueue          queue        = VK_NULL_HANDLE;
    uint32_t         queue_family = 0;
    VkCommandPool    cmd_pool     = VK_NULL_HANDLE;
    VkFunctions      fns          = {};
    VkPhysicalDeviceRayTracingPipelinePropertiesKHR rt_props{};
    uint32_t         handle_size  = 0;
    uint32_t         handle_align = 0;
};

static VkContext*  g_ctx  = nullptr;
static std::once_flag g_ctx_init;

static uint32_t find_memory_type(VkPhysicalDevice phys, uint32_t type_filter,
                                  VkMemoryPropertyFlags props) {
    VkPhysicalDeviceMemoryProperties mem_props;
    vkGetPhysicalDeviceMemoryProperties(phys, &mem_props);
    for (uint32_t i = 0; i < mem_props.memoryTypeCount; ++i)
        if ((type_filter & (1u << i)) &&
            (mem_props.memoryTypes[i].propertyFlags & props) == props)
            return i;
    throw std::runtime_error("no suitable Vulkan memory type");
}

static VkContext* get_context() {
    std::call_once(g_ctx_init, []() {
        auto* ctx = new VkContext();

        // Instance
        VkApplicationInfo app_info{ VK_STRUCTURE_TYPE_APPLICATION_INFO };
        app_info.apiVersion = VK_API_VERSION_1_2;
        const char* inst_exts[] = {
            VK_KHR_GET_PHYSICAL_DEVICE_PROPERTIES_2_EXTENSION_NAME,
        };
        VkInstanceCreateInfo inst_ci{ VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO };
        inst_ci.pApplicationInfo        = &app_info;
        inst_ci.enabledExtensionCount   = 1;
        inst_ci.ppEnabledExtensionNames = inst_exts;
        VK_CHECK(vkCreateInstance(&inst_ci, nullptr, &ctx->instance));

        // Physical device selection - prefer discrete GPU with RT support
        uint32_t pdev_count = 0;
        vkEnumeratePhysicalDevices(ctx->instance, &pdev_count, nullptr);
        std::vector<VkPhysicalDevice> pdevs(pdev_count);
        vkEnumeratePhysicalDevices(ctx->instance, &pdev_count, pdevs.data());

        auto has_rt = [](VkPhysicalDevice pd) -> bool {
            uint32_t ext_count = 0;
            vkEnumerateDeviceExtensionProperties(pd, nullptr, &ext_count, nullptr);
            std::vector<VkExtensionProperties> exts(ext_count);
            vkEnumerateDeviceExtensionProperties(pd, nullptr, &ext_count, exts.data());
            bool has_as = false, has_rtp = false;
            for (auto& e : exts) {
                if (strcmp(e.extensionName, VK_KHR_ACCELERATION_STRUCTURE_EXTENSION_NAME) == 0) has_as  = true;
                if (strcmp(e.extensionName, VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME)   == 0) has_rtp = true;
            }
            return has_as && has_rtp;
        };

        for (auto pd : pdevs) {
            VkPhysicalDeviceProperties props;
            vkGetPhysicalDeviceProperties(pd, &props);
            if (has_rt(pd) && props.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU) {
                ctx->phys_dev = pd;
                break;
            }
        }
        if (ctx->phys_dev == VK_NULL_HANDLE)
            for (auto pd : pdevs)
                if (has_rt(pd)) { ctx->phys_dev = pd; break; }
        if (ctx->phys_dev == VK_NULL_HANDLE)
            throw std::runtime_error("no Vulkan device with ray-tracing support found");

        // Queue family
        uint32_t qf_count = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(ctx->phys_dev, &qf_count, nullptr);
        std::vector<VkQueueFamilyProperties> qfs(qf_count);
        vkGetPhysicalDeviceQueueFamilyProperties(ctx->phys_dev, &qf_count, qfs.data());
        ctx->queue_family = UINT32_MAX;
        for (uint32_t i = 0; i < qf_count; ++i)
            if (qfs[i].queueFlags & (VK_QUEUE_GRAPHICS_BIT | VK_QUEUE_COMPUTE_BIT))
                { ctx->queue_family = i; break; }
        if (ctx->queue_family == UINT32_MAX)
            throw std::runtime_error("no suitable Vulkan queue family");

        // Device features chain
        VkPhysicalDeviceBufferDeviceAddressFeaturesKHR bda_feats{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_BUFFER_DEVICE_ADDRESS_FEATURES_KHR };
        bda_feats.bufferDeviceAddress = VK_TRUE;

        VkPhysicalDeviceRayTracingPipelineFeaturesKHR rt_feats{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_TRACING_PIPELINE_FEATURES_KHR };
        rt_feats.rayTracingPipeline = VK_TRUE;
        rt_feats.pNext = &bda_feats;

        VkPhysicalDeviceAccelerationStructureFeaturesKHR as_feats{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ACCELERATION_STRUCTURE_FEATURES_KHR };
        as_feats.accelerationStructure = VK_TRUE;
        as_feats.pNext = &rt_feats;

        VkPhysicalDeviceDescriptorIndexingFeaturesEXT di_feats{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DESCRIPTOR_INDEXING_FEATURES_EXT };
        di_feats.runtimeDescriptorArray = VK_TRUE;
        di_feats.pNext = &as_feats;

        VkPhysicalDeviceFeatures2 feats2{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2 };
        feats2.pNext = &di_feats;

        const char* dev_exts[] = {
            VK_KHR_ACCELERATION_STRUCTURE_EXTENSION_NAME,
            VK_KHR_RAY_TRACING_PIPELINE_EXTENSION_NAME,
            VK_KHR_DEFERRED_HOST_OPERATIONS_EXTENSION_NAME,
            VK_KHR_BUFFER_DEVICE_ADDRESS_EXTENSION_NAME,
            VK_EXT_DESCRIPTOR_INDEXING_EXTENSION_NAME,
            VK_KHR_SPIRV_1_4_EXTENSION_NAME,
            VK_KHR_SHADER_FLOAT_CONTROLS_EXTENSION_NAME,
        };
        float queue_prio = 1.0f;
        VkDeviceQueueCreateInfo queue_ci{ VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO };
        queue_ci.queueFamilyIndex = ctx->queue_family;
        queue_ci.queueCount       = 1;
        queue_ci.pQueuePriorities = &queue_prio;

        VkDeviceCreateInfo dev_ci{ VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO };
        dev_ci.pNext                   = &feats2;
        dev_ci.queueCreateInfoCount    = 1;
        dev_ci.pQueueCreateInfos       = &queue_ci;
        dev_ci.enabledExtensionCount   = static_cast<uint32_t>(std::size(dev_exts));
        dev_ci.ppEnabledExtensionNames = dev_exts;
        VK_CHECK(vkCreateDevice(ctx->phys_dev, &dev_ci, nullptr, &ctx->device));
        vkGetDeviceQueue(ctx->device, ctx->queue_family, 0, &ctx->queue);

        // Command pool
        VkCommandPoolCreateInfo pool_ci{ VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO };
        pool_ci.queueFamilyIndex = ctx->queue_family;
        pool_ci.flags            = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        VK_CHECK(vkCreateCommandPool(ctx->device, &pool_ci, nullptr, &ctx->cmd_pool));

        // Load extension functions
        ctx->fns = load_functions(ctx->instance, ctx->device);

        // Query RT pipeline properties
        ctx->rt_props       = {};
        ctx->rt_props.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_RAY_TRACING_PIPELINE_PROPERTIES_KHR;
        VkPhysicalDeviceProperties2 dev_props2{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2 };
        dev_props2.pNext = &ctx->rt_props;
        if (ctx->fns.vkGetPhysicalDeviceProperties2)
            ctx->fns.vkGetPhysicalDeviceProperties2(ctx->phys_dev, &dev_props2);
        else
            vkGetPhysicalDeviceProperties2(ctx->phys_dev, &dev_props2);
        ctx->handle_size  = ctx->rt_props.shaderGroupHandleSize;
        ctx->handle_align = ctx->rt_props.shaderGroupHandleAlignment;

        g_ctx = ctx;
    });
    return g_ctx;
}

// buffer management ---------------------------------------------------------

struct BufMem {
    VkBuffer       buffer = VK_NULL_HANDLE;
    VkDeviceMemory memory = VK_NULL_HANDLE;
    VkDeviceSize   size   = 0;
};

static BufMem alloc_buffer(VkContext* ctx, VkDeviceSize size,
                            VkBufferUsageFlags usage, VkMemoryPropertyFlags mem_props) {
    BufMem bm;
    bm.size = size;
    VkBufferCreateInfo ci{ VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO };
    ci.size        = size;
    ci.usage       = usage;
    ci.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    VK_CHECK(vkCreateBuffer(ctx->device, &ci, nullptr, &bm.buffer));

    VkMemoryRequirements reqs;
    vkGetBufferMemoryRequirements(ctx->device, bm.buffer, &reqs);

    VkMemoryAllocateFlagsInfo flags_info{ VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_FLAGS_INFO };
    bool need_addr = (usage & VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT);
    if (need_addr) flags_info.flags = VK_MEMORY_ALLOCATE_DEVICE_ADDRESS_BIT;

    VkMemoryAllocateInfo alloc_info{ VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO };
    alloc_info.pNext           = need_addr ? &flags_info : nullptr;
    alloc_info.allocationSize  = reqs.size;
    alloc_info.memoryTypeIndex = find_memory_type(ctx->phys_dev, reqs.memoryTypeBits, mem_props);
    VK_CHECK(vkAllocateMemory(ctx->device, &alloc_info, nullptr, &bm.memory));
    VK_CHECK(vkBindBufferMemory(ctx->device, bm.buffer, bm.memory, 0));
    return bm;
}

static void free_buf(VkContext* ctx, BufMem& bm) {
    if (bm.buffer != VK_NULL_HANDLE) vkDestroyBuffer(ctx->device, bm.buffer, nullptr);
    if (bm.memory != VK_NULL_HANDLE) vkFreeMemory  (ctx->device, bm.memory, nullptr);
    bm = {};
}

static void upload_to_buf(VkContext* ctx, BufMem& dst, const void* src, VkDeviceSize sz) {
    // Stage -> device
    BufMem staging = alloc_buffer(ctx, sz,
        VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mapped;
    VK_CHECK(vkMapMemory(ctx->device, staging.memory, 0, sz, 0, &mapped));
    std::memcpy(mapped, src, sz);
    vkUnmapMemory(ctx->device, staging.memory);

    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool        = ctx->cmd_pool;
    alloc.level              = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    VkBufferCopy copy{ 0, 0, sz };
    vkCmdCopyBuffer(cmd, staging.buffer, dst.buffer, 1, &copy);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1;
    sub.pCommandBuffers    = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
    free_buf(ctx, staging);
}

static void download_from_buf(VkContext* ctx, void* dst, BufMem& src, VkDeviceSize sz) {
    BufMem staging = alloc_buffer(ctx, sz,
        VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);

    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool = ctx->cmd_pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    VkBufferCopy copy{ 0, 0, sz };
    vkCmdCopyBuffer(cmd, src.buffer, staging.buffer, 1, &copy);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);

    void* mapped;
    VK_CHECK(vkMapMemory(ctx->device, staging.memory, 0, sz, 0, &mapped));
    std::memcpy(dst, mapped, sz);
    vkUnmapMemory(ctx->device, staging.memory);
    free_buf(ctx, staging);
}

static void zero_buf(VkContext* ctx, BufMem& buf) {
    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool = ctx->cmd_pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    vkCmdFillBuffer(cmd, buf.buffer, 0, buf.size, 0u);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
}

static VkDeviceAddress buf_addr(VkContext* ctx, VkBuffer buf) {
    VkBufferDeviceAddressInfo info{ VK_STRUCTURE_TYPE_BUFFER_DEVICE_ADDRESS_INFO };
    info.buffer = buf;
    return ctx->fns.vkGetBufferDeviceAddress(ctx->device, &info);
}

// SPIR-V compilation via shaderc -------------------------------------------

static std::vector<uint32_t> compile_glsl(const char* glsl_src,
                                           shaderc_shader_kind kind,
                                           const char* name) {
    shaderc_compiler_t compiler = shaderc_compiler_initialize();
    shaderc_compile_options_t opts = shaderc_compile_options_initialize();
    shaderc_compile_options_set_target_env(opts, shaderc_target_env_vulkan,
                                           shaderc_env_version_vulkan_1_2);
    shaderc_compile_options_set_target_spirv(opts, shaderc_spirv_version_1_5);
    shaderc_compile_options_set_optimization_level(opts, shaderc_optimization_level_performance);

    shaderc_compilation_result_t result =
        shaderc_compile_into_spv(compiler, glsl_src, std::strlen(glsl_src),
                                  kind, name, "main", opts);
    shaderc_compile_options_release(opts);

    shaderc_compilation_status status = shaderc_result_get_compilation_status(result);
    if (status != shaderc_compilation_status_success) {
        std::string err = shaderc_result_get_error_message(result);
        shaderc_result_release(result);
        shaderc_compiler_release(compiler);
        throw std::runtime_error(std::string("GLSL compile error (") + name + "): " + err);
    }

    size_t sz = shaderc_result_get_length(result);
    const uint32_t* ptr = reinterpret_cast<const uint32_t*>(shaderc_result_get_bytes(result));
    std::vector<uint32_t> spv(ptr, ptr + sz / 4);
    shaderc_result_release(result);
    shaderc_compiler_release(compiler);
    return spv;
}

// Acceleration structure building ------------------------------------------

struct AccelResult {
    BufMem as_buf;
    VkAccelerationStructureKHR handle = VK_NULL_HANDLE;
    VkDeviceAddress device_addr       = 0;
};

static void destroy_accel(VkContext* ctx, AccelResult& a) {
    if (a.handle != VK_NULL_HANDLE)
        ctx->fns.vkDestroyAccelerationStructureKHR(ctx->device, a.handle, nullptr);
    free_buf(ctx, a.as_buf);
    a = {};
}

static constexpr float kAabbEps = 1e-4f;
static constexpr size_t kMaxOutputBytes = 512ull * 1024ull * 1024ull;
struct GpuAabb { float min_x, min_y, min_z, max_x, max_y, max_z; };

static size_t checked_mul_size_t(size_t a, size_t b, const char* label) {
    if (a != 0 && b > (std::numeric_limits<size_t>::max() / a)) {
        throw std::runtime_error(std::string(label) + " row-count overflow");
    }
    return a * b;
}

static size_t checked_output_bytes(size_t row_count, size_t row_size, const char* label) {
    size_t bytes = checked_mul_size_t(row_count, row_size, label);
    if (bytes > kMaxOutputBytes) {
        throw std::runtime_error(
            std::string(label) + " output exceeds current Vulkan guardrail of "
            + std::to_string(kMaxOutputBytes) + " bytes");
    }
    return bytes;
}

static uint32_t checked_output_capacity_u32(size_t a, size_t b, size_t row_size, const char* label) {
    size_t rows = checked_mul_size_t(a, b, label);
    if (rows > static_cast<size_t>(std::numeric_limits<uint32_t>::max())) {
        throw std::runtime_error(std::string(label) + " row-count exceeds uint32_t capacity");
    }
    checked_output_bytes(rows, row_size, label);
    return static_cast<uint32_t>(rows);
}

constexpr uint32_t kDbKindInt64 = 1u;
constexpr uint32_t kDbKindFloat64 = 2u;
constexpr uint32_t kDbKindBool = 3u;
constexpr uint32_t kDbKindText = 4u;

constexpr uint32_t kDbOpEq = 1u;
constexpr uint32_t kDbOpLt = 2u;
constexpr uint32_t kDbOpLe = 3u;
constexpr uint32_t kDbOpGt = 4u;
constexpr uint32_t kDbOpGe = 5u;
constexpr uint32_t kDbOpBetween = 6u;

constexpr size_t kDbMaxRowsPerJob = 1000000;
constexpr size_t kDbMaxCandidateRowsPerJob = 250000;
constexpr size_t kDbMaxGroupsPerJob = 65536;
constexpr float kDbBoxPad = 1.0e-3f;

struct DbPrimaryAxis {
    size_t field_index;
    std::vector<double> sorted_values;
    int64_t encoded_lo;
    int64_t encoded_hi;
};

struct DbRowMeta {
    size_t row_index;
    uint32_t row_id;
};

struct VulkanDbDatasetImpl {
    std::vector<std::string> field_names;
    std::vector<RtdlDbField> fields;
    std::vector<std::string> scalar_strings;
    std::vector<RtdlDbScalar> row_values;
    size_t row_count = 0;
    std::vector<DbPrimaryAxis> primary_axes;
    std::vector<DbRowMeta> row_metas;
    std::vector<GpuAabb> aabbs;
    AccelResult blas;
    AccelResult tlas;
};

static GpuAabb aabb_for_segment(float x0, float y0, float x1, float y1) {
    return { std::min(x0,x1) - kAabbEps, std::min(y0,y1) - kAabbEps, -0.5f,
             std::max(x0,x1) + kAabbEps, std::max(y0,y1) + kAabbEps,  0.5f };
}
static GpuAabb aabb_for_polygon(const float* vxy, uint32_t off, uint32_t cnt) {
    float xmin = 1e30f, ymin = 1e30f, xmax = -1e30f, ymax = -1e30f;
    for (uint32_t i = 0; i < cnt; ++i) {
        float x = vxy[(off+i)*2], y = vxy[(off+i)*2+1];
        xmin = std::min(xmin, x); ymin = std::min(ymin, y);
        xmax = std::max(xmax, x); ymax = std::max(ymax, y);
    }
    return { xmin-kAabbEps, ymin-kAabbEps, -0.5f, xmax+kAabbEps, ymax+kAabbEps, 0.5f };
}

static AccelResult build_aabb_blas(VkContext* ctx,
                                    const std::vector<GpuAabb>& aabbs) {
    size_t aabb_sz = sizeof(GpuAabb) * aabbs.size();
    BufMem aabb_buf = alloc_buffer(ctx, aabb_sz,
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, aabb_buf, aabbs.data(), aabb_sz);

    VkAccelerationStructureGeometryAabbsDataKHR aabb_data{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_AABBS_DATA_KHR };
    aabb_data.data.deviceAddress = buf_addr(ctx, aabb_buf.buffer);
    aabb_data.stride             = sizeof(GpuAabb);

    VkAccelerationStructureGeometryKHR geom{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_KHR };
    geom.geometryType        = VK_GEOMETRY_TYPE_AABBS_KHR;
    geom.geometry.aabbs      = aabb_data;
    geom.flags               = 0; // non-opaque so anyhit shader is invoked

    uint32_t prim_count = static_cast<uint32_t>(aabbs.size());
    VkAccelerationStructureBuildGeometryInfoKHR build_info{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_GEOMETRY_INFO_KHR };
    build_info.type          = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR;
    build_info.flags         = VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR;
    build_info.mode          = VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR;
    build_info.geometryCount = 1;
    build_info.pGeometries   = &geom;

    VkAccelerationStructureBuildSizesInfoKHR sizes{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_SIZES_INFO_KHR };
    ctx->fns.vkGetAccelerationStructureBuildSizesKHR(
        ctx->device, VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR,
        &build_info, &prim_count, &sizes);

    AccelResult result;
    result.as_buf = alloc_buffer(ctx, sizes.accelerationStructureSize,
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    VkAccelerationStructureCreateInfoKHR as_ci{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_CREATE_INFO_KHR };
    as_ci.buffer = result.as_buf.buffer;
    as_ci.size   = sizes.accelerationStructureSize;
    as_ci.type   = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR;
    VK_CHECK(ctx->fns.vkCreateAccelerationStructureKHR(ctx->device, &as_ci, nullptr,
                                                        &result.handle));

    BufMem scratch = alloc_buffer(ctx, sizes.buildScratchSize,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    build_info.dstAccelerationStructure  = result.handle;
    build_info.scratchData.deviceAddress = buf_addr(ctx, scratch.buffer);

    VkAccelerationStructureBuildRangeInfoKHR range{ prim_count, 0, 0, 0 };
    const VkAccelerationStructureBuildRangeInfoKHR* p_range = &range;

    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool = ctx->cmd_pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    ctx->fns.vkCmdBuildAccelerationStructuresKHR(cmd, 1, &build_info, &p_range);
    // Barrier: ensure BLAS build completes before it's used
    VkMemoryBarrier barrier{ VK_STRUCTURE_TYPE_MEMORY_BARRIER };
    barrier.srcAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_WRITE_BIT_KHR;
    barrier.dstAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
        VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
        0, 1, &barrier, 0, nullptr, 0, nullptr);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
    free_buf(ctx, scratch);
    free_buf(ctx, aabb_buf);

    VkAccelerationStructureDeviceAddressInfoKHR addr_info{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_DEVICE_ADDRESS_INFO_KHR };
    addr_info.accelerationStructure = result.handle;
    result.device_addr = ctx->fns.vkGetAccelerationStructureDeviceAddressKHR(ctx->device, &addr_info);
    return result;
}

// Build a BLAS from native 3D triangle geometry (VK_GEOMETRY_TYPE_TRIANGLES_KHR).
// vertices: flat float3 array, 9 floats per triangle (3 verts x xyz).
static AccelResult build_triangle_blas_3d(VkContext* ctx, const std::vector<float>& vertices) {
    size_t vert_sz     = sizeof(float) * vertices.size();
    uint32_t tri_count = static_cast<uint32_t>(vertices.size() / 9u);
    uint32_t max_vert  = tri_count * 3u;

    BufMem vert_buf = alloc_buffer(ctx, vert_sz == 0 ? 4 : vert_sz,
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    if (vert_sz > 0) upload_to_buf(ctx, vert_buf, vertices.data(), vert_sz);

    VkAccelerationStructureGeometryTrianglesDataKHR tris_data{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_TRIANGLES_DATA_KHR };
    tris_data.vertexFormat             = VK_FORMAT_R32G32B32_SFLOAT;
    tris_data.vertexData.deviceAddress = buf_addr(ctx, vert_buf.buffer);
    tris_data.vertexStride             = sizeof(float) * 3u;
    tris_data.maxVertex                = (max_vert > 0u) ? max_vert - 1u : 0u;
    tris_data.indexType                = VK_INDEX_TYPE_NONE_KHR;

    VkAccelerationStructureGeometryKHR geom{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_KHR };
    geom.geometryType     = VK_GEOMETRY_TYPE_TRIANGLES_KHR;
    geom.geometry.triangles = tris_data;
    geom.flags            = 0; // non-opaque -> any-hit shader invoked

    VkAccelerationStructureBuildGeometryInfoKHR build_info{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_GEOMETRY_INFO_KHR };
    build_info.type          = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR;
    build_info.flags         = VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR;
    build_info.mode          = VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR;
    build_info.geometryCount = 1;
    build_info.pGeometries   = &geom;

    VkAccelerationStructureBuildSizesInfoKHR sizes{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_SIZES_INFO_KHR };
    ctx->fns.vkGetAccelerationStructureBuildSizesKHR(
        ctx->device, VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR,
        &build_info, &tri_count, &sizes);

    AccelResult result;
    result.as_buf = alloc_buffer(ctx, sizes.accelerationStructureSize,
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    VkAccelerationStructureCreateInfoKHR as_ci{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_CREATE_INFO_KHR };
    as_ci.buffer = result.as_buf.buffer;
    as_ci.size   = sizes.accelerationStructureSize;
    as_ci.type   = VK_ACCELERATION_STRUCTURE_TYPE_BOTTOM_LEVEL_KHR;
    VK_CHECK(ctx->fns.vkCreateAccelerationStructureKHR(ctx->device, &as_ci, nullptr,
                                                        &result.handle));

    BufMem scratch = alloc_buffer(ctx, sizes.buildScratchSize,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    build_info.dstAccelerationStructure  = result.handle;
    build_info.scratchData.deviceAddress = buf_addr(ctx, scratch.buffer);

    VkAccelerationStructureBuildRangeInfoKHR range{ tri_count, 0, 0, 0 };
    const VkAccelerationStructureBuildRangeInfoKHR* p_range = &range;

    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc_ci{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc_ci.commandPool = ctx->cmd_pool; alloc_ci.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc_ci.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc_ci, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    ctx->fns.vkCmdBuildAccelerationStructuresKHR(cmd, 1, &build_info, &p_range);
    VkMemoryBarrier barrier{ VK_STRUCTURE_TYPE_MEMORY_BARRIER };
    barrier.srcAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_WRITE_BIT_KHR;
    barrier.dstAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
        VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
        0, 1, &barrier, 0, nullptr, 0, nullptr);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
    free_buf(ctx, scratch);
    free_buf(ctx, vert_buf);

    VkAccelerationStructureDeviceAddressInfoKHR addr_info{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_DEVICE_ADDRESS_INFO_KHR };
    addr_info.accelerationStructure = result.handle;
    result.device_addr = ctx->fns.vkGetAccelerationStructureDeviceAddressKHR(ctx->device, &addr_info);
    return result;
}

static AccelResult build_tlas(VkContext* ctx, VkAccelerationStructureKHR blas,
                                VkDeviceAddress blas_addr) {
    VkAccelerationStructureInstanceKHR instance{};
    // Identity transform (column-major 3x4)
    instance.transform.matrix[0][0] = 1.f; instance.transform.matrix[1][1] = 1.f;
    instance.transform.matrix[2][2] = 1.f;
    instance.instanceCustomIndex                    = 0;
    instance.mask                                   = 0xFF;
    instance.instanceShaderBindingTableRecordOffset = 0;
    instance.flags = VK_GEOMETRY_INSTANCE_TRIANGLE_FACING_CULL_DISABLE_BIT_KHR;
    instance.accelerationStructureReference         = blas_addr;

    BufMem inst_buf = alloc_buffer(ctx, sizeof(instance),
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_BUILD_INPUT_READ_ONLY_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, inst_buf, &instance, sizeof(instance));

    VkAccelerationStructureGeometryInstancesDataKHR inst_data{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_INSTANCES_DATA_KHR };
    inst_data.data.deviceAddress = buf_addr(ctx, inst_buf.buffer);

    VkAccelerationStructureGeometryKHR geom{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_GEOMETRY_KHR };
    geom.geometryType         = VK_GEOMETRY_TYPE_INSTANCES_KHR;
    geom.geometry.instances   = inst_data;

    uint32_t one = 1;
    VkAccelerationStructureBuildGeometryInfoKHR build_info{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_GEOMETRY_INFO_KHR };
    build_info.type          = VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR;
    build_info.flags         = VK_BUILD_ACCELERATION_STRUCTURE_PREFER_FAST_TRACE_BIT_KHR;
    build_info.mode          = VK_BUILD_ACCELERATION_STRUCTURE_MODE_BUILD_KHR;
    build_info.geometryCount = 1;
    build_info.pGeometries   = &geom;

    VkAccelerationStructureBuildSizesInfoKHR sizes{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_BUILD_SIZES_INFO_KHR };
    ctx->fns.vkGetAccelerationStructureBuildSizesKHR(
        ctx->device, VK_ACCELERATION_STRUCTURE_BUILD_TYPE_DEVICE_KHR,
        &build_info, &one, &sizes);

    AccelResult result;
    result.as_buf = alloc_buffer(ctx, sizes.accelerationStructureSize,
        VK_BUFFER_USAGE_ACCELERATION_STRUCTURE_STORAGE_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    VkAccelerationStructureCreateInfoKHR as_ci{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_CREATE_INFO_KHR };
    as_ci.buffer = result.as_buf.buffer;
    as_ci.size   = sizes.accelerationStructureSize;
    as_ci.type   = VK_ACCELERATION_STRUCTURE_TYPE_TOP_LEVEL_KHR;
    VK_CHECK(ctx->fns.vkCreateAccelerationStructureKHR(ctx->device, &as_ci, nullptr,
                                                        &result.handle));

    BufMem scratch = alloc_buffer(ctx, sizes.buildScratchSize,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    build_info.dstAccelerationStructure  = result.handle;
    build_info.scratchData.deviceAddress = buf_addr(ctx, scratch.buffer);

    VkAccelerationStructureBuildRangeInfoKHR range{ 1, 0, 0, 0 };
    const VkAccelerationStructureBuildRangeInfoKHR* p_range = &range;

    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool = ctx->cmd_pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    ctx->fns.vkCmdBuildAccelerationStructuresKHR(cmd, 1, &build_info, &p_range);
    VkMemoryBarrier barrier{ VK_STRUCTURE_TYPE_MEMORY_BARRIER };
    barrier.srcAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_WRITE_BIT_KHR;
    barrier.dstAccessMask = VK_ACCESS_ACCELERATION_STRUCTURE_READ_BIT_KHR;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_ACCELERATION_STRUCTURE_BUILD_BIT_KHR,
        VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
        0, 1, &barrier, 0, nullptr, 0, nullptr);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
    free_buf(ctx, scratch);
    free_buf(ctx, inst_buf);

    VkAccelerationStructureDeviceAddressInfoKHR addr_info{
        VK_STRUCTURE_TYPE_ACCELERATION_STRUCTURE_DEVICE_ADDRESS_INFO_KHR };
    addr_info.accelerationStructure = result.handle;
    result.device_addr = ctx->fns.vkGetAccelerationStructureDeviceAddressKHR(ctx->device, &addr_info);
    return result;
}

// GPU data structs (matching GLSL std430 layout) ---------------------------

#pragma pack(push, 1)
struct GpuSegment    { float x0, y0, x1, y1; uint32_t id; };        // 20 bytes
struct GpuPoint      { float x, y;            uint32_t id; };        // 12 bytes
struct GpuPoint3D    { float x, y, z;         uint32_t id; };        // 16 bytes
struct GpuPolygonRef { uint32_t id, vertex_offset, vertex_count; };  // 12 bytes
struct GpuTriangle   { float x0, y0, x1, y1, x2, y2; uint32_t id; };// 28 bytes
struct GpuRay        { float ox, oy, dx, dy, tmax; uint32_t id; };   // 24 bytes
struct GpuRay3D      { float ox, oy, oz, dx, dy, dz, tmax; uint32_t id; }; // 32 bytes

struct GpuSegmentPairIntersectionRecord      { uint32_t left_id, right_id; float ix, iy; };        // 16 bytes
struct GpuPipRecord      { uint32_t point_id, polygon_id, contains; };          // 12 bytes
struct GpuPipCandidate   { uint32_t point_index, poly_index; };                  //  8 bytes
struct GpuShapePairRelationFlags   { uint32_t requires_segment_intersection, requires_point_containment; };              //  8 bytes
struct GpuRayHitRecord   { uint32_t ray_id, hit_count; };                        //  8 bytes
struct GpuSegPolyRecord  { uint32_t segment_id, hit_count; };                    //  8 bytes
struct GpuPnsRecord      { uint32_t point_id, segment_id; float distance; };     // 12 bytes
struct GpuFrnRecord      { uint32_t query_id, neighbor_id; float distance; };    // 12 bytes
struct GpuKnnRecord      { uint32_t query_id, neighbor_id; float distance; uint32_t neighbor_rank; }; // 16 bytes
#pragma pack(pop)

struct VulkanPreparedRayAnyhit2D {
    VkContext* ctx = nullptr;
    BufMem d_tris;
    AccelResult blas;
    AccelResult tlas;
    bool empty_scene = false;

    ~VulkanPreparedRayAnyhit2D() {
        if (ctx != nullptr) {
            destroy_accel(ctx, tlas);
            destroy_accel(ctx, blas);
            free_buf(ctx, d_tris);
        }
    }

    VulkanPreparedRayAnyhit2D(const VulkanPreparedRayAnyhit2D&) = delete;
    VulkanPreparedRayAnyhit2D& operator=(const VulkanPreparedRayAnyhit2D&) = delete;
    VulkanPreparedRayAnyhit2D() = default;
};

static bool exact_segment_intersection(
        const RtdlSegment& left,
        const RtdlSegment& right,
        double* ix_out,
        double* iy_out)
{
    const double px = left.x0;
    const double py = left.y0;
    const double rx = left.x1 - left.x0;
    const double ry = left.y1 - left.y0;
    const double qx = right.x0;
    const double qy = right.y0;
    const double sx = right.x1 - right.x0;
    const double sy = right.y1 - right.y0;

    const double denom = rx * sy - ry * sx;
    if (segment_intersection_denominator_is_degenerate(denom, rx, ry, sx, sy)) {
        return false;
    }

    const double qpx = qx - px;
    const double qpy = qy - py;
    const double t = (qpx * sy - qpy * sx) / denom;
    const double u = (qpx * ry - qpy * rx) / denom;
    if (!(0.0 <= t && t <= 1.0 && 0.0 <= u && u <= 1.0)) {
        return false;
    }

    *ix_out = px + t * rx;
    *iy_out = py + t * ry;
    return true;
}

static bool exact_ray_hits_triangle_3d(
        const RtdlRay3D& ray,
        const RtdlTriangle3D& triangle)
{
    const double edge1x = triangle.x1 - triangle.x0;
    const double edge1y = triangle.y1 - triangle.y0;
    const double edge1z = triangle.z1 - triangle.z0;
    const double edge2x = triangle.x2 - triangle.x0;
    const double edge2y = triangle.y2 - triangle.y0;
    const double edge2z = triangle.z2 - triangle.z0;

    const double pvx = ray.dy * edge2z - ray.dz * edge2y;
    const double pvy = ray.dz * edge2x - ray.dx * edge2z;
    const double pvz = ray.dx * edge2y - ray.dy * edge2x;
    const double det = edge1x * pvx + edge1y * pvy + edge1z * pvz;
    if (std::abs(det) <= 1.0e-8) {
        return false;
    }

    const double inv_det = 1.0 / det;
    const double tvx = ray.ox - triangle.x0;
    const double tvy = ray.oy - triangle.y0;
    const double tvz = ray.oz - triangle.z0;
    const double u = (tvx * pvx + tvy * pvy + tvz * pvz) * inv_det;
    if (u < 0.0 || u > 1.0) {
        return false;
    }

    const double qvx = tvy * edge1z - tvz * edge1y;
    const double qvy = tvz * edge1x - tvx * edge1z;
    const double qvz = tvx * edge1y - tvy * edge1x;
    const double v = (ray.dx * qvx + ray.dy * qvy + ray.dz * qvz) * inv_det;
    if (v < 0.0 || (u + v) > 1.0) {
        return false;
    }

    const double t = (edge2x * qvx + edge2y * qvy + edge2z * qvz) * inv_det;
    return t >= 0.0 && t <= ray.tmax;
}

#if RTDL_VULKAN_HAS_GEOS
class GeosPreparedPolygonRefs {
  public:
    GeosPreparedPolygonRefs(const RtdlPolygonRef* polys, size_t poly_count, const double* vertices_xy)
        : context_(GEOS_init_r()) {
        if (context_ == nullptr) {
            throw std::runtime_error("failed to initialize GEOS context");
        }
        geometries_.reserve(poly_count);
        prepared_.reserve(poly_count);
        for (size_t i = 0; i < poly_count; ++i) {
            GEOSGeometry* geometry = build_polygon_geometry(polys[i], vertices_xy);
            if (geometry == nullptr) {
                throw std::runtime_error("failed to build GEOS polygon geometry");
            }
            const GEOSPreparedGeometry* prepared = GEOSPrepare_r(context_, geometry);
            if (prepared == nullptr) {
                GEOSGeom_destroy_r(context_, geometry);
                throw std::runtime_error("failed to prepare GEOS polygon geometry");
            }
            geometries_.push_back(geometry);
            prepared_.push_back(prepared);
        }
    }

    GeosPreparedPolygonRefs(const GeosPreparedPolygonRefs&) = delete;
    GeosPreparedPolygonRefs& operator=(const GeosPreparedPolygonRefs&) = delete;

    ~GeosPreparedPolygonRefs() {
        if (context_ == nullptr) return;
        for (const GEOSPreparedGeometry* prepared : prepared_) {
            if (prepared != nullptr) {
                GEOSPreparedGeom_destroy_r(context_, prepared);
            }
        }
        for (GEOSGeometry* geometry : geometries_) {
            if (geometry != nullptr) {
                GEOSGeom_destroy_r(context_, geometry);
            }
        }
        GEOS_finish_r(context_);
    }

    bool covers(size_t polygon_index, double x, double y) const {
        GEOSGeometry* point = build_point_geometry(x, y);
        if (point == nullptr) {
            throw std::runtime_error("failed to build GEOS point geometry");
        }
        char covers_value = GEOSPreparedCovers_r(context_, prepared_.at(polygon_index), point);
        GEOSGeom_destroy_r(context_, point);
        if (covers_value == 2) {
            throw std::runtime_error("GEOSPreparedCovers_r failed");
        }
        return covers_value == 1;
    }

  private:
    GEOSGeometry* build_point_geometry(double x, double y) const {
        GEOSCoordSequence* sequence = GEOSCoordSeq_create_r(context_, 1, 2);
        if (sequence == nullptr) return nullptr;
        if (!GEOSCoordSeq_setX_r(context_, sequence, 0, x) ||
            !GEOSCoordSeq_setY_r(context_, sequence, 0, y)) {
            GEOSCoordSeq_destroy_r(context_, sequence);
            return nullptr;
        }
        return GEOSGeom_createPoint_r(context_, sequence);
    }

    GEOSGeometry* build_polygon_geometry(const RtdlPolygonRef& poly, const double* vertices_xy) const {
        size_t ring_size = poly.vertex_count;
        bool closed = ring_size > 0 &&
                      vertices_xy[poly.vertex_offset * 2] == vertices_xy[(poly.vertex_offset + poly.vertex_count - 1) * 2] &&
                      vertices_xy[poly.vertex_offset * 2 + 1] == vertices_xy[(poly.vertex_offset + poly.vertex_count - 1) * 2 + 1];
        if (!closed) {
            ring_size += 1;
        }
        GEOSCoordSequence* sequence = GEOSCoordSeq_create_r(context_, ring_size, 2);
        if (sequence == nullptr) return nullptr;
        for (size_t i = 0; i < poly.vertex_count; ++i) {
            const size_t vertex_index = poly.vertex_offset + i;
            if (!GEOSCoordSeq_setX_r(context_, sequence, i, vertices_xy[vertex_index * 2]) ||
                !GEOSCoordSeq_setY_r(context_, sequence, i, vertices_xy[vertex_index * 2 + 1])) {
                GEOSCoordSeq_destroy_r(context_, sequence);
                return nullptr;
            }
        }
        if (!closed) {
            if (!GEOSCoordSeq_setX_r(context_, sequence, ring_size - 1, vertices_xy[poly.vertex_offset * 2]) ||
                !GEOSCoordSeq_setY_r(context_, sequence, ring_size - 1, vertices_xy[poly.vertex_offset * 2 + 1])) {
                GEOSCoordSeq_destroy_r(context_, sequence);
                return nullptr;
            }
        }
        GEOSGeometry* ring = GEOSGeom_createLinearRing_r(context_, sequence);
        if (ring == nullptr) return nullptr;
        GEOSGeometry* polygon = GEOSGeom_createPolygon_r(context_, ring, nullptr, 0);
        if (polygon == nullptr) {
            GEOSGeom_destroy_r(context_, ring);
            return nullptr;
        }
        return polygon;
    }

    GEOSContextHandle_t context_;
    std::vector<GEOSGeometry*> geometries_;
    std::vector<const GEOSPreparedGeometry*> prepared_;
};
#endif

static bool exact_point_on_segment(
        double px,
        double py,
        double ax,
        double ay,
        double bx,
        double by)
{
    const double point_eps = 1.0e-12;
    const double len2 = (bx - ax) * (bx - ax) + (by - ay) * (by - ay);
    if (len2 <= point_eps * point_eps) {
        return std::abs(px - ax) <= point_eps && std::abs(py - ay) <= point_eps;
    }
    const double len = std::sqrt(len2);
    const double cross = (px - ax) * (by - ay) - (py - ay) * (bx - ax);
    if (std::abs(cross) > point_eps * len) {
        return false;
    }
    const double dot = (px - ax) * (bx - ax) + (py - ay) * (by - ay);
    const double along_eps = point_eps * len;
    if (dot < -along_eps) {
        return false;
    }
    return dot <= len2 + along_eps;
}

static bool exact_point_in_polygon(
        double x,
        double y,
        const RtdlPolygonRef& poly,
        const double* vertices_xy)
{
    const uint32_t n = poly.vertex_count;
    const uint32_t off = poly.vertex_offset;
    for (uint32_t i = 0; i < n; ++i) {
        const uint32_t j = (i + 1) % n;
        const double ax = vertices_xy[(off + i) * 2];
        const double ay = vertices_xy[(off + i) * 2 + 1];
        const double bx = vertices_xy[(off + j) * 2];
        const double by = vertices_xy[(off + j) * 2 + 1];
        if (exact_point_on_segment(x, y, ax, ay, bx, by)) {
            return true;
        }
    }

    bool inside = false;
    for (uint32_t i = 0, j = n - 1; i < n; j = i++) {
        const double xi = vertices_xy[(off + i) * 2];
        const double yi = vertices_xy[(off + i) * 2 + 1];
        const double xj = vertices_xy[(off + j) * 2];
        const double yj = vertices_xy[(off + j) * 2 + 1];
        if ((yi > y) != (yj > y)) {
            const double denom = (yj - yi) != 0.0 ? (yj - yi) : 1.0e-20;
            const double x_cross = (xj - xi) * (y - yi) / denom + xi;
            if (x <= x_cross) {
                inside = !inside;
            }
        }
    }
    return inside;
}

static Bounds2D bounds_for_segment(const RtdlSegment& segment)
{
    return {
        std::min(segment.x0, segment.x1),
        std::min(segment.y0, segment.y1),
        std::max(segment.x0, segment.x1),
        std::max(segment.y0, segment.y1),
    };
}

static Bounds2D bounds_for_polygon(
        const RtdlPolygonRef& poly,
        const double* vertices_xy)
{
    Bounds2D bounds {
        vertices_xy[poly.vertex_offset * 2],
        vertices_xy[poly.vertex_offset * 2 + 1],
        vertices_xy[poly.vertex_offset * 2],
        vertices_xy[poly.vertex_offset * 2 + 1],
    };
    for (uint32_t i = 0; i < poly.vertex_count; ++i) {
        const size_t base = static_cast<size_t>(poly.vertex_offset + i) * 2;
        const double x = vertices_xy[base];
        const double y = vertices_xy[base + 1];
        bounds.min_x = std::min(bounds.min_x, x);
        bounds.min_y = std::min(bounds.min_y, y);
        bounds.max_x = std::max(bounds.max_x, x);
        bounds.max_y = std::max(bounds.max_y, y);
    }
    return bounds;
}

static bool bounds_overlap(const Bounds2D& left, const Bounds2D& right)
{
    return !(left.max_x < right.min_x || right.max_x < left.min_x ||
             left.max_y < right.min_y || right.max_y < left.min_y);
}

struct PolygonBucketIndex {
    double origin_x;
    double bucket_width;
    std::vector<std::vector<size_t>> buckets;
};

static PolygonBucketIndex build_polygon_bucket_index(
        const std::vector<Bounds2D>& polygon_bounds)
{
    if (polygon_bounds.empty()) {
        return {0.0, 1.0, {}};
    }
    double global_min = polygon_bounds.front().min_x;
    double global_max = polygon_bounds.front().max_x;
    for (const Bounds2D& bounds : polygon_bounds) {
        global_min = std::min(global_min, bounds.min_x);
        global_max = std::max(global_max, bounds.max_x);
    }
    const double span = std::max(global_max - global_min, 1.0e-9);
    const size_t bucket_count = std::max<size_t>(16, std::min<size_t>(polygon_bounds.size() * 2, 8192));
    const double bucket_width = span / static_cast<double>(bucket_count);
    std::vector<std::vector<size_t>> buckets(bucket_count);
    for (size_t polygon_index = 0; polygon_index < polygon_bounds.size(); ++polygon_index) {
        const Bounds2D& bounds = polygon_bounds[polygon_index];
        const auto first = static_cast<size_t>(std::clamp(
            static_cast<long long>(std::floor((bounds.min_x - global_min) / bucket_width)),
            0LL,
            static_cast<long long>(bucket_count - 1)));
        const auto last = static_cast<size_t>(std::clamp(
            static_cast<long long>(std::floor((bounds.max_x - global_min) / bucket_width)),
            0LL,
            static_cast<long long>(bucket_count - 1)));
        for (size_t bucket_id = first; bucket_id <= last; ++bucket_id) {
            buckets[bucket_id].push_back(polygon_index);
        }
    }
    return {global_min, bucket_width, std::move(buckets)};
}

static bool exact_segment_hits_polygon(
        const RtdlSegment& segment,
        const RtdlPolygonRef& poly,
        const double* vertices_xy)
{
    if (exact_point_in_polygon(segment.x0, segment.y0, poly, vertices_xy) ||
        exact_point_in_polygon(segment.x1, segment.y1, poly, vertices_xy)) {
        return true;
    }
    const uint32_t n = poly.vertex_count;
    const uint32_t off = poly.vertex_offset;
    for (uint32_t i = 0; i < n; ++i) {
        const uint32_t j = (i + 1) % n;
        RtdlSegment edge{
            poly.id,
            vertices_xy[(off + i) * 2],
            vertices_xy[(off + i) * 2 + 1],
            vertices_xy[(off + j) * 2],
            vertices_xy[(off + j) * 2 + 1],
        };
        double ix = 0.0;
        double iy = 0.0;
        if (exact_segment_intersection(segment, edge, &ix, &iy)) {
            return true;
        }
    }
    return false;
}

static std::vector<RtdlSegmentPairIntersectionRow> exact_segment_pair_intersection_rows(
        const RtdlSegment* left,
        size_t left_count,
        const RtdlSegment* right,
        size_t right_count)
{
    std::vector<RtdlSegmentPairIntersectionRow> rows;
    rows.reserve(left_count);
    for (size_t li = 0; li < left_count; ++li) {
        for (size_t ri = 0; ri < right_count; ++ri) {
            double ix = 0.0;
            double iy = 0.0;
            if (!exact_segment_intersection(left[li], right[ri], &ix, &iy)) {
                continue;
            }
            rows.push_back(RtdlSegmentPairIntersectionRow{left[li].id, right[ri].id, ix, iy});
        }
    }
    return rows;
}

static std::vector<RtdlSegment> polygon_edge_segments(
        const RtdlPolygonRef* polys,
        size_t poly_count,
        const double* vertices_xy)
{
    std::vector<RtdlSegment> segments;
    for (size_t pi = 0; pi < poly_count; ++pi) {
        const RtdlPolygonRef& poly = polys[pi];
        for (uint32_t i = 0; i < poly.vertex_count; ++i) {
            const uint32_t j = (i + 1) % poly.vertex_count;
            const uint32_t i0 = poly.vertex_offset + i;
            const uint32_t i1 = poly.vertex_offset + j;
            segments.push_back(RtdlSegment{
                poly.id,
                vertices_xy[i0 * 2],
                vertices_xy[i0 * 2 + 1],
                vertices_xy[i1 * 2],
                vertices_xy[i1 * 2 + 1],
            });
        }
    }
    return segments;
}

// GLSL source strings -------------------------------------------------------

// ---------- segment-pair intersection shaders -------------------------------------------------------
// Build: right segments as AABB geometry.
// Probe: one ray per left segment; ray encodes the segment (origin=start,
//        dir=end-start, tmax=1).
// Intersection: segment-segment geometric test; passes (buildIdx, ix, iy) as
//               hit attributes.
// Anyhit: writes output record atomically, ignores intersection to continue.

static const char* kSegmentPairIntersectionRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint nprobes; uint capacity; };
layout(set=0, binding=4, std430) readonly buffer ProbeBuf {
    float data[]; // GpuSegment: x0,y0,x1,y1,id(bits) per 5 floats
} probeSegs;
layout(location=0) rayPayloadEXT uint probeIdx;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= nprobes) return;
    uint base = idx * 5u;
    float x0 = probeSegs.data[base+0u], y0 = probeSegs.data[base+1u];
    float x1 = probeSegs.data[base+2u], y1 = probeSegs.data[base+3u];
    float dx = x1 - x0, dy = y1 - y0;
    float len = sqrt(dx*dx + dy*dy);
    probeIdx = idx;
    if (len < 1e-9) return;
    traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                vec3(x0, y0, 0.0), 0.001, vec3(dx, dy, 0.0), 1.0001, 0);
}
)GLSL";

static const char* kSegmentPairIntersectionRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint probeIdx;
void main() {}
)GLSL";

static const char* kSegmentPairIntersectionRint = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
struct HitAttr { uint buildIdx; float ix; float iy; };
hitAttributeEXT HitAttr hitAttr;
layout(set=0, binding=4, std430) readonly buffer ProbeBuf { float data[]; } probeSegs;
layout(set=0, binding=5, std430) readonly buffer BuildBuf { float data[]; } buildSegs;
void main() {
    uint primIdx   = gl_PrimitiveID;
    uint probeIdx  = gl_LaunchIDEXT.x;
    uint pbase = probeIdx * 5u;
    float ax0 = probeSegs.data[pbase+0u], ay0 = probeSegs.data[pbase+1u];
    float ax1 = probeSegs.data[pbase+2u], ay1 = probeSegs.data[pbase+3u];
    uint bbase = primIdx * 5u;
    float bx0 = buildSegs.data[bbase+0u], by0 = buildSegs.data[bbase+1u];
    float bx1 = buildSegs.data[bbase+2u], by1 = buildSegs.data[bbase+3u];
    float rx = ax1-ax0, ry = ay1-ay0;
    float sx = bx1-bx0, sy = by1-by0;
    float denom = rx*sy - ry*sx;
    if (abs(denom) < 1e-7) return;
    float qpx = bx0-ax0, qpy = by0-ay0;
    float t = (qpx*sy - qpy*sx) / denom;
    float u = (qpx*ry - qpy*rx) / denom;
    if (t < 0.0 || t > 1.0 || u < 0.0 || u > 1.0) return;
    hitAttr.buildIdx = primIdx;
    hitAttr.ix = ax0 + t*rx;
    hitAttr.iy = ay0 + t*ry;
    reportIntersectionEXT(max(t, 0.001), 0u);
}
)GLSL";

static const char* kSegmentPairIntersectionRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
struct HitAttr { uint buildIdx; float ix; float iy; };
hitAttributeEXT HitAttr hitAttr;
layout(set=0, binding=1, std430) buffer OutBuf  { uint data[]; } output_buf;
layout(set=0, binding=2, std430) buffer CountBuf{ uint counter; };
layout(set=0, binding=3, std140) uniform Params { uint nprobes; uint capacity; };
layout(set=0, binding=4, std430) readonly buffer ProbeBuf { float data[]; } probeSegs;
layout(set=0, binding=5, std430) readonly buffer BuildBuf { float data[]; } buildSegs;
layout(location=0) rayPayloadInEXT uint probeIdx;
void main() {
    uint slot = atomicAdd(counter, 1u);
    if (slot < capacity) {
        // GpuSegmentPairIntersectionRecord: uint left_id, right_id; float ix, iy -> 4xuint slots
        uint pbase = probeIdx * 5u;
        uint bbase = hitAttr.buildIdx * 5u;
        uint left_id  = floatBitsToUint(probeSegs.data[pbase+4u]);
        uint right_id = floatBitsToUint(buildSegs.data[bbase+4u]);
        uint obase = slot * 4u;
        output_buf.data[obase+0u] = left_id;
        output_buf.data[obase+1u] = right_id;
        output_buf.data[obase+2u] = floatBitsToUint(hitAttr.ix);
        output_buf.data[obase+3u] = floatBitsToUint(hitAttr.iy);
    }
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- PIP shaders -------------------------------------------------------
// Build: polygon bounding-box AABBs.
// Probe: vertical ray (dir 0,1,0) from each point.
// Intersection: full PIP test (ray cast) on the polygon's actual vertices.
// Anyhit: write to pre-allocated output[probeIdx * npolygons + primIdx].

static const char* kPipRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint npoints; uint npolygons; };
layout(set=0, binding=4, std430) readonly buffer PointBuf { float data[]; } points;
layout(location=0) rayPayloadEXT uint dummy;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= npoints) return;
    uint base = idx * 3u;
    float px = points.data[base+0u], py = points.data[base+1u];
    traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                vec3(px, py, 0.0), 0.0, vec3(0.0, 1.0, 0.0), 1e30, 0);
}
)GLSL";

static const char* kPipRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint dummy;
void main() {}
)GLSL";

static const char* kPipRint = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=3, std140) uniform Params { uint npoints; uint npolygons; };
layout(set=0, binding=4, std430) readonly buffer PointBuf   { float data[]; } points;
layout(set=0, binding=5, std430) readonly buffer PolyRefBuf { uint  data[]; } polyrefs; // id,vertOff,vertCnt triplets
layout(set=0, binding=6, std430) readonly buffer VertBuf    { float data[]; } vertices; // interleaved x,y
void main() {
    uint primIdx  = gl_PrimitiveID;
    uint probeIdx = gl_LaunchIDEXT.x;
    uint pbase = probeIdx * 3u;
    float px = points.data[pbase+0u], py = points.data[pbase+1u];
    uint rbase = primIdx * 3u;
    uint vert_off = polyrefs.data[rbase+1u];
    uint vert_cnt = polyrefs.data[rbase+2u];
    // Ray-cast: count crossings of +y ray from (px,py)
    // Boundary check first
    for (uint i = 0u; i < vert_cnt; ++i) {
        uint j = (i + 1u) % vert_cnt;
        float ax = vertices.data[(vert_off+i)*2u],   ay = vertices.data[(vert_off+i)*2u+1u];
        float bx = vertices.data[(vert_off+j)*2u],   by = vertices.data[(vert_off+j)*2u+1u];
        float cross = (px-ax)*(by-ay) - (py-ay)*(bx-ax);
        if (abs(cross) < 1e-6) {
            float dot = (px-ax)*(bx-ax) + (py-ay)*(by-ay);
            float len2 = (bx-ax)*(bx-ax) + (by-ay)*(by-ay);
            if (dot >= -1e-6 && dot <= len2+1e-6) {
                reportIntersectionEXT(0.5, 0u); return;
            }
        }
    }
    bool inside = false;
    uint j2 = vert_cnt - 1u;
    for (uint i = 0u; i < vert_cnt; j2 = i++) {
        float xi = vertices.data[(vert_off+i)*2u],   yi = vertices.data[(vert_off+i)*2u+1u];
        float xj = vertices.data[(vert_off+j2)*2u],  yj = vertices.data[(vert_off+j2)*2u+1u];
        if (((yi > py) != (yj > py)) &&
            (px <= (xj-xi)*(py-yi)/((yj-yi) != 0.0 ? (yj-yi) : 1e-20) + xi))
            inside = !inside;
    }
    if (inside) reportIntersectionEXT(0.5, 0u);
}
)GLSL";

static const char* kPipRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(set=0, binding=3, std140) uniform Params { uint npoints; uint npolygons; };
layout(set=0, binding=4, std430) readonly buffer PointBuf   { float data[]; } points;
layout(set=0, binding=5, std430) readonly buffer PolyRefBuf { uint  data[]; } polyrefs;
layout(location=0) rayPayloadInEXT uint dummy;
void main() {
    uint probeIdx = gl_LaunchIDEXT.x;
    uint primIdx  = gl_PrimitiveID;
    // GpuPipRecord: uint point_id, polygon_id, contains -> 3 uint slots
    uint slot  = probeIdx * npolygons + primIdx;
    uint obase = slot * 3u;
    uint pbase = probeIdx * 3u;
    uint rbase = primIdx  * 3u;
    output_buf.data[obase+0u] = floatBitsToUint(points.data[pbase+2u]);   // point_id (stored as float bits)
    output_buf.data[obase+1u] = polyrefs.data[rbase+0u];                  // polygon_id
    output_buf.data[obase+2u] = 1u;                                        // contains = true
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- PIP positive-hit sparse shaders ----------------------------------
// rgen/rmiss/rint are shared with the dense PIP pipeline (kPipRgen, kPipRmiss,
// kPipRint).  Only the anyhit differs: instead of writing to a dense indexed
// slot, it atomically appends a (point_index, poly_index) pair to a compact
// candidate list.  The host then exact-finalizes only those candidates.

static const char* kPipPosRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=1, std430) buffer CandBuf    { uvec2 data[]; } cand_buf;
layout(set=0, binding=2, std430) buffer CounterBuf { uint count; };
layout(set=0, binding=3, std140) uniform Params    { uint npoints; uint capacity; };
layout(location=0) rayPayloadInEXT uint dummy;
void main() {
    uint point_index = gl_LaunchIDEXT.x;
    uint poly_index  = gl_PrimitiveID;
    uint slot = atomicAdd(count, 1u);
    if (slot < capacity) {
        cand_buf.data[slot] = uvec2(point_index, poly_index);
    }
    ignoreIntersectionEXT;
}
)GLSL";

static const char* kPipPosCountRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=2, std430) buffer CounterBuf { uint count; };
layout(location=0) rayPayloadInEXT uint dummy;
void main() {
    atomicAdd(count, 1u);
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- shape-pair relation shaders ---------------------------------------------------
// Build: right polygon bounding-box AABBs.
// Probe: one ray per (left_polygon, edge) pair, encoding the edge.
// Intersection: test probe edge against all right polygon edges (segment-pair intersection test).
// Anyhit: set output[lpidx * right_count + rpidx].requires_segment_intersection = 1 atomically.

static const char* kShapePairRelationRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params {
    uint left_count; uint right_count; uint max_edges; uint launch_count;
};
layout(set=0, binding=4, std430) readonly buffer LPolyBuf { uint data[]; } left_polys;
layout(set=0, binding=5, std430) readonly buffer LVertBuf { float data[]; } left_verts;
layout(location=0) rayPayloadEXT uint lpidx_payload;
void main() {
    uint gidx  = gl_LaunchIDEXT.x;
    if (gidx >= launch_count) return;
    uint lpidx  = gidx / max_edges;
    uint edge_i = gidx % max_edges;
    if (lpidx >= left_count) return;
    uint rbase = lpidx * 3u;
    uint vert_off = left_polys.data[rbase+1u];
    uint vert_cnt = left_polys.data[rbase+2u];
    if (edge_i >= vert_cnt) return;
    uint i0 = vert_off + edge_i;
    uint i1 = vert_off + (edge_i + 1u) % vert_cnt;
    float ex0 = left_verts.data[i0*2u],   ey0 = left_verts.data[i0*2u+1u];
    float ex1 = left_verts.data[i1*2u],   ey1 = left_verts.data[i1*2u+1u];
    float dx = ex1-ex0, dy = ey1-ey0;
    lpidx_payload = lpidx;
    traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                vec3(ex0, ey0, 0.0), 0.001, vec3(dx, dy, 0.0), 1.0001, 0);
}
)GLSL";

static const char* kShapePairRelationRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint lpidx_payload;
void main() {}
)GLSL";

static const char* kShapePairRelationRint = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=3, std140) uniform Params {
    uint left_count; uint right_count; uint max_edges; uint launch_count;
};
layout(set=0, binding=4, std430) readonly buffer LPolyBuf  { uint  data[]; } left_polys;
layout(set=0, binding=5, std430) readonly buffer LVertBuf  { float data[]; } left_verts;
layout(set=0, binding=6, std430) readonly buffer RPolyBuf  { uint  data[]; } right_polys;
layout(set=0, binding=7, std430) readonly buffer RVertBuf  { float data[]; } right_verts;
hitAttributeEXT uint rpidx_attr;
void main() {
    uint rpidx  = gl_PrimitiveID;
    uint gidx   = gl_LaunchIDEXT.x;
    uint lpidx  = gidx / max_edges;
    uint edge_i = gidx % max_edges;
    uint lrbase  = lpidx * 3u;
    uint lv_off  = left_polys.data[lrbase+1u];
    uint lv_cnt  = left_polys.data[lrbase+2u];
    if (edge_i >= lv_cnt) return;
    uint i0 = lv_off + edge_i;
    uint i1 = lv_off + (edge_i + 1u) % lv_cnt;
    float ax0 = left_verts.data[i0*2u],  ay0 = left_verts.data[i0*2u+1u];
    float ax1 = left_verts.data[i1*2u],  ay1 = left_verts.data[i1*2u+1u];
    float rx = ax1-ax0, ry = ay1-ay0;
    uint rrbase = rpidx * 3u;
    uint rv_off = right_polys.data[rrbase+1u];
    uint rv_cnt = right_polys.data[rrbase+2u];
    for (uint k = 0u; k < rv_cnt; ++k) {
        uint j0 = rv_off + k;
        uint j1 = rv_off + (k + 1u) % rv_cnt;
        float bx0 = right_verts.data[j0*2u], by0 = right_verts.data[j0*2u+1u];
        float bx1 = right_verts.data[j1*2u], by1 = right_verts.data[j1*2u+1u];
        float sx = bx1-bx0, sy = by1-by0;
        float denom = rx*sy - ry*sx;
        if (abs(denom) < 1e-7) continue;
        float qpx = bx0-ax0, qpy = by0-ay0;
        float t = (qpx*sy - qpy*sx) / denom;
        float u = (qpx*ry - qpy*rx) / denom;
        if (t >= 0.0 && t <= 1.0 && u >= 0.0 && u <= 1.0) {
            rpidx_attr = rpidx;
            reportIntersectionEXT(0.5, 1u);
            return;
        }
    }
}
)GLSL";

static const char* kShapePairRelationRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
hitAttributeEXT uint rpidx_attr;
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(set=0, binding=3, std140) uniform Params {
    uint left_count; uint right_count; uint max_edges; uint launch_count;
};
layout(location=0) rayPayloadInEXT uint lpidx_payload;
void main() {
    uint lpidx = lpidx_payload;
    uint rpidx = rpidx_attr;
    uint slot  = lpidx * right_count + rpidx;
    // GpuShapePairRelationFlags: requires_segment_intersection at offset 0, requires_point_containment at offset 1
    atomicOr(output_buf.data[slot*2u+0u], 1u);
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- RayHitCount shaders -----------------------------------------------
// Build: triangle AABBs (custom geometry, same as OptiX).
// Probe: one ray per input 2D ray.
// Intersection: full 2D ray-vs-triangle test.
// Anyhit: increment hit count in payload, ignore intersection.
// Raygen: after trace, write (ray_id, hit_count) to per-ray output slot.

static const char* kRhcRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint nrays; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer RayBuf { float data[]; } rays;
// GpuRay: ox,oy,dx,dy,tmax,id -> 6 floats per ray
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(location=0) rayPayloadEXT uint hitCount;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= nrays) return;
    uint base = idx * 6u;
    float ox = rays.data[base+0u], oy = rays.data[base+1u];
    float dx = rays.data[base+2u], dy = rays.data[base+3u];
    float tmax = rays.data[base+4u];
    uint  ray_id = floatBitsToUint(rays.data[base+5u]);
    float len = sqrt(dx*dx + dy*dy);
    hitCount = 0u;
    if (len >= 1e-10) {
        traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                    vec3(ox, oy, 0.0), 0.0, vec3(dx/len, dy/len, 0.0), tmax*len, 0);
    }
    uint obase = idx * 2u;
    output_buf.data[obase+0u] = ray_id;
    output_buf.data[obase+1u] = hitCount;
}
)GLSL";

static const char* kRhcRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint hitCount;
void main() {}
)GLSL";

static const char* kRhcRint = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=3, std140) uniform Params { uint nrays; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer RayBuf { float data[]; } rays;
layout(set=0, binding=5, std430) readonly buffer TriBuf { float data[]; } tris;
// GpuTriangle: x0,y0,x1,y1,x2,y2,id -> 7 floats
void main() {
    uint  primIdx = gl_PrimitiveID;
    uint  rayIdx  = gl_LaunchIDEXT.x;
    uint  rbase = rayIdx  * 6u;
    float rox   = rays.data[rbase+0u], roy = rays.data[rbase+1u];
    float rdx   = rays.data[rbase+2u], rdy = rays.data[rbase+3u];
    float rtmax = rays.data[rbase+4u];
    uint  tbase = primIdx * 7u;
    float tx0 = tris.data[tbase+0u], ty0 = tris.data[tbase+1u];
    float tx1 = tris.data[tbase+2u], ty1 = tris.data[tbase+3u];
    float tx2 = tris.data[tbase+4u], ty2 = tris.data[tbase+5u];
    // 2D ray segment: from (rox,roy) to (rox+rdx*rtmax, roy+rdy*rtmax)
    float rex = rox + rdx*rtmax, rey = roy + rdy*rtmax;
    bool hit = false;
    // Check ray vs each triangle edge
    float rx = rex-rox, ry = rey-roy;
    float bx[3] = float[3](tx0,tx1,tx2), by[3] = float[3](ty0,ty1,ty2);
    for (int i = 0; i < 3; ++i) {
        float ax0 = bx[i], ay0 = by[i], ax1 = bx[(i+1)%3], ay1 = by[(i+1)%3];
        float sx = ax1-ax0, sy = ay1-ay0;
        float denom = rx*sy - ry*sx;
        if (abs(denom) < 1e-7) continue;
        float qpx = ax0-rox, qpy = ay0-roy;
        float t = (qpx*sy - qpy*sx) / denom;
        float u = (qpx*ry - qpy*rx) / denom;
        if (t >= 0.0 && t <= 1.0 && u >= 0.0 && u <= 1.0) { hit = true; break; }
    }
    // Also check if ray origin is inside triangle
    if (!hit) {
        float d1 = (rox-ty2)*(tx0-ty2) - (tx2-ty2)*(roy-ty2);
        float d2 = (rox-ty0)*(tx1-ty0) - (tx1-tx0)*(roy-ty0);
        float d3 = (rox-ty1)*(tx2-ty1) - (tx2-tx1)*(roy-ty1);
        bool has_neg = (d1<0)||(d2<0)||(d3<0);
        bool has_pos = (d1>0)||(d2>0)||(d3>0);
        if (!(has_neg && has_pos)) hit = true;
    }
    if (hit) reportIntersectionEXT(0.5, 0u);
}
)GLSL";

static const char* kRhcRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint hitCount;
void main() {
    hitCount += 1u;
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- RayAnyHit shaders ------------------------------------------------
// Same 2D custom-intersection geometry as RayHitCount, but the any-hit shader
// terminates traversal after the first accepted hit.

static const char* kRahRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint nrays; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer RayBuf { float data[]; } rays;
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(location=0) rayPayloadEXT uint anyHit;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= nrays) return;
    uint base = idx * 6u;
    float ox = rays.data[base+0u], oy = rays.data[base+1u];
    float dx = rays.data[base+2u], dy = rays.data[base+3u];
    float tmax = rays.data[base+4u];
    uint  ray_id = floatBitsToUint(rays.data[base+5u]);
    float len = sqrt(dx*dx + dy*dy);
    anyHit = 0u;
    if (len >= 1e-10) {
        traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                    vec3(ox, oy, 0.0), 0.0, vec3(dx/len, dy/len, 0.0), tmax*len, 0);
    }
    uint obase = idx * 2u;
    output_buf.data[obase+0u] = ray_id;
    output_buf.data[obase+1u] = anyHit;
}
)GLSL";

static const char* kRahRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint anyHit;
void main() {}
)GLSL";

static const char* kRahRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint anyHit;
void main() {
    anyHit = 1u;
    terminateRayEXT;
}
)GLSL";

// ---------- RayHitCount3D shaders (native Vulkan triangle geometry) -----------
// Build: BLAS from VK_GEOMETRY_TYPE_TRIANGLES_KHR - hardware handles intersection.
// No intersection shader needed. Any-hit counts all hits; ignoreIntersectionEXT
// forces continued traversal so every triangle is reported.

static const char* kRhc3dRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint nrays; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer RayBuf { float data[]; } rays;
// GpuRay3D layout: ox,oy,oz,dx,dy,dz,tmax,id  (8 floats / 32 bytes per ray)
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(location=0) rayPayloadEXT uint hitCount;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= nrays) return;
    uint base = idx * 8u;
    float ox = rays.data[base+0u], oy = rays.data[base+1u], oz = rays.data[base+2u];
    float dx = rays.data[base+3u], dy = rays.data[base+4u], dz = rays.data[base+5u];
    float tmax  = rays.data[base+6u];
    uint ray_id = floatBitsToUint(rays.data[base+7u]);
    hitCount = 0u;
    traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                vec3(ox, oy, oz), 0.0, vec3(dx, dy, dz), tmax, 0);
    uint obase = idx * 2u;
    output_buf.data[obase+0u] = ray_id;
    output_buf.data[obase+1u] = hitCount;
}
)GLSL";

static const char* kRhc3dRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint hitCount;
void main() {}
)GLSL";

static const char* kRhc3dRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint hitCount;
void main() {
    hitCount += 1u;
    ignoreIntersectionEXT;
}
)GLSL";

static const char* kRah3dRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint nrays; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer RayBuf { float data[]; } rays;
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(location=0) rayPayloadEXT uint anyHit;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= nrays) return;
    uint base = idx * 8u;
    float ox = rays.data[base+0u], oy = rays.data[base+1u], oz = rays.data[base+2u];
    float dx = rays.data[base+3u], dy = rays.data[base+4u], dz = rays.data[base+5u];
    float tmax  = rays.data[base+6u];
    uint ray_id = floatBitsToUint(rays.data[base+7u]);
    anyHit = 0u;
    traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                vec3(ox, oy, oz), 0.0, vec3(dx, dy, dz), tmax, 0);
    uint obase = idx * 2u;
    output_buf.data[obase+0u] = ray_id;
    output_buf.data[obase+1u] = anyHit;
}
)GLSL";

static const char* kRah3dRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint anyHit;
void main() {}
)GLSL";

static const char* kRah3dRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint anyHit;
void main() {
    anyHit = 1u;
    terminateRayEXT;
}
)GLSL";

// ---------- DBScan shaders ----------------------------------------------------
// Build: per-row AABB primitives in encoded x/y/z.
// Probe: one ray per (x,y) cell across the bounded query slab.
// Intersection: accept the AABB candidate immediately.
// Anyhit: set the row bit in a hit-bitset and continue traversal.

static const char* kDbScanRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params {
    uint hit_word_count;
    uint x_lo;
    uint y_lo;
    uint z_lo;
    uint z_hi;
    uint x_count;
    uint y_count;
    uint pad0;
};
layout(location=0) rayPayloadEXT uint dbPayload;
void main() {
    uint ix = gl_LaunchIDEXT.x;
    uint iy = gl_LaunchIDEXT.y;
    if (ix >= x_count || iy >= y_count) return;
    float x = float(x_lo + ix);
    float y = float(y_lo + iy);
    float zmin = float(z_lo) - 1.0;
    float tmax = float((z_hi - z_lo) + 2u);
    dbPayload = 0u;
    traceRayEXT(
        tlas,
        gl_RayFlagsNoneEXT,
        0xFF,
        0, 1, 0,
        vec3(x, y, zmin),
        0.0,
        vec3(0.0, 0.0, 1.0),
        tmax,
        0);
}
)GLSL";

static const char* kDbScanRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint dbPayload;
void main() {}
)GLSL";

static const char* kDbScanRint = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
void main() {
    reportIntersectionEXT(max(gl_RayTminEXT, 0.001), 0u);
}
)GLSL";

static const char* kDbScanRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=1, std430) buffer HitBuf { uint data[]; } hit_words;
layout(set=0, binding=3, std140) uniform Params {
    uint hit_word_count;
    uint x_lo;
    uint y_lo;
    uint z_lo;
    uint z_hi;
    uint x_count;
    uint y_count;
    uint pad0;
};
layout(location=0) rayPayloadInEXT uint dbPayload;
void main() {
    uint prim_idx = gl_PrimitiveID;
    uint word = prim_idx >> 5u;
    if (word < hit_word_count) {
        atomicOr(hit_words.data[word], 1u << (prim_idx & 31u));
    }
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- SegmentPolygonHitcount shaders ------------------------------------
// Build: polygon bounding-box AABBs.
// Probe: one ray per segment (encoded like segment-pair intersection probe).
// Intersection: test probe segment against all polygon edges.
// Anyhit: increment hit count in payload, ignore intersection.
// Raygen: after trace, write (segment_id, hit_count) to output.

static const char* kSphRgen = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=0) uniform accelerationStructureEXT tlas;
layout(set=0, binding=3, std140) uniform Params { uint nsegs; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer SegBuf { float data[]; } segs;
layout(set=0, binding=1, std430) buffer OutBuf { uint data[]; } output_buf;
layout(location=0) rayPayloadEXT uint hitCount;
void main() {
    uint idx = gl_LaunchIDEXT.x;
    if (idx >= nsegs) return;
    uint base = idx * 5u;
    float x0 = segs.data[base+0u], y0 = segs.data[base+1u];
    float x1 = segs.data[base+2u], y1 = segs.data[base+3u];
    uint  seg_id = floatBitsToUint(segs.data[base+4u]);
    float dx = x1-x0, dy = y1-y0;
    float len = sqrt(dx*dx + dy*dy);
    hitCount = 0u;
    if (len >= 1e-10) {
        traceRayEXT(tlas, gl_RayFlagsNoneEXT, 0xFF, 0, 1, 0,
                    vec3(x0, y0, 0.0), 0.001, vec3(dx/len, dy/len, 0.0), len, 0);
    }
    uint obase = idx * 2u;
    output_buf.data[obase+0u] = seg_id;
    output_buf.data[obase+1u] = hitCount;
}
)GLSL";

static const char* kSphRmiss = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint hitCount;
void main() {}
)GLSL";

static const char* kSphRint = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(set=0, binding=3, std140) uniform Params { uint nsegs; uint pad0; };
layout(set=0, binding=4, std430) readonly buffer SegBuf    { float data[]; } segs;
layout(set=0, binding=5, std430) readonly buffer PolyBuf   { uint  data[]; } polyrefs;
layout(set=0, binding=6, std430) readonly buffer VertBuf   { float data[]; } vertices;
void main() {
    uint primIdx  = gl_PrimitiveID;
    uint probeIdx = gl_LaunchIDEXT.x;
    uint sbase = probeIdx * 5u;
    float sx0 = segs.data[sbase+0u], sy0 = segs.data[sbase+1u];
    float sx1 = segs.data[sbase+2u], sy1 = segs.data[sbase+3u];
    float rx = sx1-sx0, ry = sy1-sy0;
    uint rbase = primIdx * 3u;
    uint vert_off = polyrefs.data[rbase+1u];
    uint vert_cnt = polyrefs.data[rbase+2u];
    bool hit = false;
    // Segment-vs-polygon-edges test
    for (uint k = 0u; k < vert_cnt; ++k) {
        uint j0 = vert_off + k;
        uint j1 = vert_off + (k + 1u) % vert_cnt;
        float ax = vertices.data[j0*2u], ay = vertices.data[j0*2u+1u];
        float bx = vertices.data[j1*2u], by = vertices.data[j1*2u+1u];
        float sx = bx-ax, sy = by-ay;
        float denom = rx*sy - ry*sx;
        if (abs(denom) < 1e-7) continue;
        float qpx = ax-sx0, qpy = ay-sy0;
        float t = (qpx*sy - qpy*sx) / denom;
        float u = (qpx*ry - qpy*rx) / denom;
        if (t >= 0.0 && t <= 1.0 && u >= 0.0 && u <= 1.0) { hit = true; break; }
    }
    // Also check if segment midpoint is inside polygon
    if (!hit) {
        float mx = (sx0+sx1)*0.5, my = (sy0+sy1)*0.5;
        bool inside = false;
        uint j2 = vert_cnt - 1u;
        for (uint i = 0u; i < vert_cnt; j2 = i++) {
            float xi = vertices.data[(vert_off+i)*2u],  yi = vertices.data[(vert_off+i)*2u+1u];
            float xj = vertices.data[(vert_off+j2)*2u], yj = vertices.data[(vert_off+j2)*2u+1u];
            if (((yi > my) != (yj > my)) &&
                (mx <= (xj-xi)*(my-yi)/((yj-yi) != 0.0 ? (yj-yi) : 1e-20) + xi))
                inside = !inside;
        }
        if (inside) hit = true;
    }
    if (hit) reportIntersectionEXT(0.5, 0u);
}
)GLSL";

static const char* kSphRahit = R"GLSL(
#version 460
#extension GL_EXT_ray_tracing : require
layout(location=0) rayPayloadInEXT uint hitCount;
void main() {
    hitCount += 1u;
    ignoreIntersectionEXT;
}
)GLSL";

// ---------- PointNearestSegment compute shader --------------------------------
// Brute-force compute: one workgroup-item per point, iterates all segments.
// Matches the CUDA approach in the OptiX backend.

static const char* kPnsComp = R"GLSL(
#version 460
layout(local_size_x = 64) in;
layout(set=0, binding=0, std430) readonly buffer PointBuf { float data[]; } points;
layout(set=0, binding=1, std430) readonly buffer SegBuf   { float data[]; } segs;
layout(set=0, binding=2, std430) writeonly buffer OutBuf  { uint  data[]; } output_buf;
layout(set=0, binding=3, std140) uniform Params { uint npoints; uint nsegs; };
void main() {
    uint pidx = gl_GlobalInvocationID.x;
    if (pidx >= npoints) return;
    uint pbase = pidx * 3u;
    float px = points.data[pbase+0u], py = points.data[pbase+1u];
    uint  pid = floatBitsToUint(points.data[pbase+2u]);
    float bestDist = 1e30;
    uint  bestSid  = 0u;
    for (uint s = 0u; s < nsegs; ++s) {
        uint sbase = s * 5u;
        float ax = segs.data[sbase+0u], ay = segs.data[sbase+1u];
        float bx = segs.data[sbase+2u], by = segs.data[sbase+3u];
        uint  sid = floatBitsToUint(segs.data[sbase+4u]);
        float vx = bx-ax, vy = by-ay;
        float wx = px-ax, wy = py-ay;
        float denom = vx*vx + vy*vy;
        float t = (denom < 1e-12) ? 0.0 : clamp((wx*vx+wy*vy)/denom, 0.0, 1.0);
        float proj_x = ax+t*vx, proj_y = ay+t*vy;
        float dx = px-proj_x, dy = py-proj_y;
        float dist = sqrt(dx*dx + dy*dy);
        if (dist < bestDist || (abs(dist-bestDist) < 1e-7 && sid < bestSid)) {
            bestDist = dist;
            bestSid  = sid;
        }
    }
    uint obase = pidx * 3u;
    output_buf.data[obase+0u] = pid;
    output_buf.data[obase+1u] = bestSid;
    output_buf.data[obase+2u] = floatBitsToUint(bestDist);
}
)GLSL";

// ---------- FixedRadiusNeighbors compute shader --------------------------------
// Brute-force compute: one workgroup-item per query point, iterates all search
// points, maintains a sorted list of up to k_max neighbours within radius.
// Mirrors the CUDA kernel in the OptiX backend.
//
// Output layout: 3 uint32 words per record, k_max records per query:
//   word 0: query_id
//   word 1: neighbor_id  (0xffffffff = empty/sentinel)
//   word 2: distance as float bits

static const char* kFrnComp = R"GLSL(
#version 460
layout(local_size_x = 64) in;
// Query points: interleaved floats [x, y, id_bits, ...]
layout(set=0, binding=0, std430) readonly buffer QueryBuf  { float data[]; } queries;
// Search points: same format
layout(set=0, binding=1, std430) readonly buffer SearchBuf { float data[]; } search;
// Output: [query_id, neighbor_id (0xffffffff=empty), dist_bits] per slot,
//         k_max slots per query, row-major
layout(set=0, binding=2, std430) buffer OutBuf { uint data[]; } output_buf;
// Uniform parameters
layout(set=0, binding=3, std140) uniform Params {
    uint  nqueries;
    uint  nsearch;
    float radius;
    uint  k_max;
};

void main() {
    uint qidx = gl_GlobalInvocationID.x;
    if (qidx >= nqueries) return;

    // Load query point
    uint qbase_in = qidx * 3u;
    float px = queries.data[qbase_in];
    float py = queries.data[qbase_in + 1u];
    uint  qid = floatBitsToUint(queries.data[qbase_in + 2u]);

    // Base offset in output buffer (3 uints per slot, k_max slots per query)
    uint out_base = qidx * k_max * 3u;

    // Initialise all slots with sentinel
    for (uint s = 0u; s < k_max; ++s) {
        uint ob = out_base + s * 3u;
        output_buf.data[ob]      = qid;
        output_buf.data[ob + 1u] = 0xffffffffu;
        output_buf.data[ob + 2u] = floatBitsToUint(1.0e30);
    }

    float radius_sq = radius * radius;

    // For each search point, test and insert if within radius
    for (uint sidx = 0u; sidx < nsearch; ++sidx) {
        uint sb = sidx * 3u;
        float sx = search.data[sb];
        float sy = search.data[sb + 1u];
        uint  nid = floatBitsToUint(search.data[sb + 2u]);

        float dx = sx - px;
        float dy = sy - py;
        float dist_sq = dx * dx + dy * dy;
        if (dist_sq > radius_sq) continue;
        float dist = sqrt(dist_sq);

        // Find insertion position (sorted by distance ASC, then neighbor_id ASC)
        uint insert_at = k_max;
        for (uint slot = 0u; slot < k_max; ++slot) {
            uint ob = out_base + slot * 3u;
            uint  slot_nid  = output_buf.data[ob + 1u];
            float slot_dist = uintBitsToFloat(output_buf.data[ob + 2u]);
            bool empty       = (slot_nid == 0xffffffffu);
            bool better_dist = dist < slot_dist - 1.0e-7;
            bool same_dist   = abs(dist - slot_dist) <= 1.0e-7;
            bool better_id   = same_dist && (nid < slot_nid);
            if (empty || better_dist || better_id) {
                insert_at = slot;
                break;
            }
        }
        if (insert_at == k_max) continue;

        // Shift existing entries down to make room (from the end toward insert_at+1)
        for (uint slot = k_max - 1u; slot > insert_at; --slot) {
            uint src_b = out_base + (slot - 1u) * 3u;
            uint dst_b = out_base + slot * 3u;
            output_buf.data[dst_b]      = output_buf.data[src_b];
            output_buf.data[dst_b + 1u] = output_buf.data[src_b + 1u];
            output_buf.data[dst_b + 2u] = output_buf.data[src_b + 2u];
        }

        // Write new entry at insert_at
        uint ib = out_base + insert_at * 3u;
        output_buf.data[ib]      = qid;
        output_buf.data[ib + 1u] = nid;
        output_buf.data[ib + 2u] = floatBitsToUint(dist);
    }
}
)GLSL";

static const char* kFrn3DComp = R"GLSL(
#version 460
layout(local_size_x = 64) in;
layout(set=0, binding=0, std430) readonly buffer QueryBuf  { float data[]; } queries;
layout(set=0, binding=1, std430) readonly buffer SearchBuf { float data[]; } search;
layout(set=0, binding=2, std430) buffer OutBuf { uint data[]; } output_buf;
layout(set=0, binding=3, std140) uniform Params {
    uint  nqueries;
    uint  nsearch;
    float radius;
    uint  k_max;
};

void main() {
    uint qidx = gl_GlobalInvocationID.x;
    if (qidx >= nqueries) return;

    uint qbase_in = qidx * 4u;
    float px = queries.data[qbase_in];
    float py = queries.data[qbase_in + 1u];
    float pz = queries.data[qbase_in + 2u];
    uint  qid = floatBitsToUint(queries.data[qbase_in + 3u]);

    uint out_base = qidx * k_max * 3u;
    for (uint s = 0u; s < k_max; ++s) {
        uint ob = out_base + s * 3u;
        output_buf.data[ob]      = qid;
        output_buf.data[ob + 1u] = 0xffffffffu;
        output_buf.data[ob + 2u] = floatBitsToUint(1.0e30);
    }

    float radius_sq = radius * radius;

    for (uint sidx = 0u; sidx < nsearch; ++sidx) {
        uint sb = sidx * 4u;
        float sx = search.data[sb];
        float sy = search.data[sb + 1u];
        float sz = search.data[sb + 2u];
        uint  nid = floatBitsToUint(search.data[sb + 3u]);

        float dx = sx - px;
        float dy = sy - py;
        float dz = sz - pz;
        float dist_sq = dx * dx + dy * dy + dz * dz;
        if (dist_sq > radius_sq) continue;
        float dist = sqrt(dist_sq);

        uint insert_at = k_max;
        for (uint slot = 0u; slot < k_max; ++slot) {
            uint ob = out_base + slot * 3u;
            uint  slot_nid  = output_buf.data[ob + 1u];
            float slot_dist = uintBitsToFloat(output_buf.data[ob + 2u]);
            bool empty       = (slot_nid == 0xffffffffu);
            bool better_dist = dist < slot_dist - 1.0e-7;
            bool same_dist   = abs(dist - slot_dist) <= 1.0e-7;
            bool better_id   = same_dist && (nid < slot_nid);
            if (empty || better_dist || better_id) {
                insert_at = slot;
                break;
            }
        }
        if (insert_at == k_max) continue;

        for (uint slot = k_max - 1u; slot > insert_at; --slot) {
            uint src_b = out_base + (slot - 1u) * 3u;
            uint dst_b = out_base + slot * 3u;
            output_buf.data[dst_b]      = output_buf.data[src_b];
            output_buf.data[dst_b + 1u] = output_buf.data[src_b + 1u];
            output_buf.data[dst_b + 2u] = output_buf.data[src_b + 2u];
        }

        uint ib = out_base + insert_at * 3u;
        output_buf.data[ib]      = qid;
        output_buf.data[ib + 1u] = nid;
        output_buf.data[ib + 2u] = floatBitsToUint(dist);
    }
}
)GLSL";

// ---------- KNNRows compute shader -------------------------------------------
// Brute-force compute: one workgroup-item per query point, iterates all search
// points, maintains the k nearest neighbours sorted by distance ASC then
// neighbor_id ASC, and assigns a 1-based neighbor_rank to non-empty rows.
//
// Output layout: 4 uint32 words per record, k records per query:
//   word 0: query_id
//   word 1: neighbor_id (0xffffffff = empty/sentinel)
//   word 2: distance as float bits
//   word 3: neighbor_rank

static const char* kKClosestHitsComp = R"GLSL(
#version 460
layout(local_size_x = 64) in;
layout(set=0, binding=0, std430) readonly buffer QueryBuf  { float data[]; } queries;
layout(set=0, binding=1, std430) readonly buffer SearchBuf { float data[]; } search;
layout(set=0, binding=2, std430) buffer OutBuf { uint data[]; } output_buf;
layout(set=0, binding=3, std140) uniform Params {
    uint nqueries;
    uint nsearch;
    uint k;
    uint _pad0;
};

void main() {
    uint qidx = gl_GlobalInvocationID.x;
    if (qidx >= nqueries) return;

    uint qbase_in = qidx * 3u;
    float px = queries.data[qbase_in];
    float py = queries.data[qbase_in + 1u];
    uint qid = floatBitsToUint(queries.data[qbase_in + 2u]);

    uint out_base = qidx * k * 4u;
    for (uint s = 0u; s < k; ++s) {
        uint ob = out_base + s * 4u;
        output_buf.data[ob]      = qid;
        output_buf.data[ob + 1u] = 0xffffffffu;
        output_buf.data[ob + 2u] = floatBitsToUint(1.0e30);
        output_buf.data[ob + 3u] = 0u;
    }

    for (uint sidx = 0u; sidx < nsearch; ++sidx) {
        uint sb = sidx * 3u;
        float sx = search.data[sb];
        float sy = search.data[sb + 1u];
        uint nid = floatBitsToUint(search.data[sb + 2u]);

        float dx = sx - px;
        float dy = sy - py;
        float dist = sqrt(dx * dx + dy * dy);

        uint insert_at = k;
        for (uint slot = 0u; slot < k; ++slot) {
            uint ob = out_base + slot * 4u;
            uint slot_nid = output_buf.data[ob + 1u];
            float slot_dist = uintBitsToFloat(output_buf.data[ob + 2u]);
            bool empty = (slot_nid == 0xffffffffu);
            bool better_dist = dist < slot_dist - 1.0e-7;
            bool same_dist = abs(dist - slot_dist) <= 1.0e-7;
            bool better_id = same_dist && (nid < slot_nid);
            if (empty || better_dist || better_id) {
                insert_at = slot;
                break;
            }
        }
        if (insert_at == k) continue;

        for (uint slot = k - 1u; slot > insert_at; --slot) {
            uint src_b = out_base + (slot - 1u) * 4u;
            uint dst_b = out_base + slot * 4u;
            output_buf.data[dst_b]      = output_buf.data[src_b];
            output_buf.data[dst_b + 1u] = output_buf.data[src_b + 1u];
            output_buf.data[dst_b + 2u] = output_buf.data[src_b + 2u];
            output_buf.data[dst_b + 3u] = output_buf.data[src_b + 3u];
        }

        uint ins_b = out_base + insert_at * 4u;
        output_buf.data[ins_b]      = qid;
        output_buf.data[ins_b + 1u] = nid;
        output_buf.data[ins_b + 2u] = floatBitsToUint(dist);
        output_buf.data[ins_b + 3u] = 0u;
    }

    for (uint slot = 0u; slot < k; ++slot) {
        uint ob = out_base + slot * 4u;
        if (output_buf.data[ob + 1u] == 0xffffffffu) break;
        output_buf.data[ob + 3u] = slot + 1u;
    }
}
)GLSL";

static const char* kKClosestHits3DComp = R"GLSL(
#version 460
layout(local_size_x = 64) in;
layout(set=0, binding=0, std430) readonly buffer QueryBuf  { float data[]; } queries;
layout(set=0, binding=1, std430) readonly buffer SearchBuf { float data[]; } search;
layout(set=0, binding=2, std430) buffer OutBuf { uint data[]; } output_buf;
layout(set=0, binding=3, std140) uniform Params {
    uint nqueries;
    uint nsearch;
    uint k;
    uint _pad0;
};

void main() {
    uint qidx = gl_GlobalInvocationID.x;
    if (qidx >= nqueries) return;

    uint qbase_in = qidx * 4u;
    float px = queries.data[qbase_in];
    float py = queries.data[qbase_in + 1u];
    float pz = queries.data[qbase_in + 2u];
    uint qid = floatBitsToUint(queries.data[qbase_in + 3u]);

    uint out_base = qidx * k * 4u;
    for (uint s = 0u; s < k; ++s) {
        uint ob = out_base + s * 4u;
        output_buf.data[ob]      = qid;
        output_buf.data[ob + 1u] = 0xffffffffu;
        output_buf.data[ob + 2u] = floatBitsToUint(1.0e30);
        output_buf.data[ob + 3u] = 0u;
    }

    for (uint sidx = 0u; sidx < nsearch; ++sidx) {
        uint sb = sidx * 4u;
        float sx = search.data[sb];
        float sy = search.data[sb + 1u];
        float sz = search.data[sb + 2u];
        uint nid = floatBitsToUint(search.data[sb + 3u]);

        float dx = sx - px;
        float dy = sy - py;
        float dz = sz - pz;
        float dist = sqrt(dx * dx + dy * dy + dz * dz);

        uint insert_at = k;
        for (uint slot = 0u; slot < k; ++slot) {
            uint ob = out_base + slot * 4u;
            uint slot_nid = output_buf.data[ob + 1u];
            float slot_dist = uintBitsToFloat(output_buf.data[ob + 2u]);
            bool empty = (slot_nid == 0xffffffffu);
            bool better_dist = dist < slot_dist - 1.0e-7;
            bool same_dist = abs(dist - slot_dist) <= 1.0e-7;
            bool better_id = same_dist && (nid < slot_nid);
            if (empty || better_dist || better_id) {
                insert_at = slot;
                break;
            }
        }
        if (insert_at == k) continue;

        for (uint slot = k - 1u; slot > insert_at; --slot) {
            uint src_b = out_base + (slot - 1u) * 4u;
            uint dst_b = out_base + slot * 4u;
            output_buf.data[dst_b]      = output_buf.data[src_b];
            output_buf.data[dst_b + 1u] = output_buf.data[src_b + 1u];
            output_buf.data[dst_b + 2u] = output_buf.data[src_b + 2u];
            output_buf.data[dst_b + 3u] = output_buf.data[src_b + 3u];
        }

        uint ins_b = out_base + insert_at * 4u;
        output_buf.data[ins_b]      = qid;
        output_buf.data[ins_b + 1u] = nid;
        output_buf.data[ins_b + 2u] = floatBitsToUint(dist);
        output_buf.data[ins_b + 3u] = 0u;
    }

    for (uint slot = 0u; slot < k; ++slot) {
        uint ob = out_base + slot * 4u;
        if (output_buf.data[ob + 1u] == 0xffffffffu) break;
        output_buf.data[ob + 3u] = slot + 1u;
    }
}
)GLSL";

// Pipeline building ---------------------------------------------------------

struct RtPipeline {
    VkPipeline            pipeline      = VK_NULL_HANDLE;
    VkPipelineLayout      layout        = VK_NULL_HANDLE;
    VkDescriptorSetLayout dset_layout   = VK_NULL_HANDLE;
    BufMem                sbt_buf       = {};
    VkStridedDeviceAddressRegionKHR rgen_region{};
    VkStridedDeviceAddressRegionKHR miss_region{};
    VkStridedDeviceAddressRegionKHR hit_region{};
    VkStridedDeviceAddressRegionKHR call_region{};
};

struct ComputePipeline {
    VkPipeline            pipeline    = VK_NULL_HANDLE;
    VkPipelineLayout      layout      = VK_NULL_HANDLE;
    VkDescriptorSetLayout dset_layout = VK_NULL_HANDLE;
};

static VkShaderModule make_shader(VkDevice dev, const std::vector<uint32_t>& spv) {
    VkShaderModuleCreateInfo ci{ VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO };
    ci.codeSize = spv.size() * 4;
    ci.pCode    = spv.data();
    VkShaderModule mod;
    VK_CHECK(vkCreateShaderModule(dev, &ci, nullptr, &mod));
    return mod;
}

// Build a ray-tracing pipeline with: rgen, rmiss, rint+rahit hit group.
// binding_count = number of descriptor bindings (TLAS at 0, then storage buffers).
static RtPipeline build_rt_pipeline(
        VkContext* ctx,
        const char* rgen_glsl, const char* rmiss_glsl,
        const char* rint_glsl, const char* rahit_glsl,
        const char* rgen_name, const char* rmiss_name,
        const char* rint_name, const char* rahit_name,
        uint32_t binding_count)
{
    // Compile shaders
    auto rgen_spv = compile_glsl(rgen_glsl, shaderc_raygen_shader,     rgen_name);
    auto rmiss_spv= compile_glsl(rmiss_glsl,shaderc_miss_shader,       rmiss_name);
    auto rint_spv = compile_glsl(rint_glsl, shaderc_intersection_shader,rint_name);
    auto rahit_spv= compile_glsl(rahit_glsl,shaderc_anyhit_shader,     rahit_name);

    VkShaderModule sm_rgen  = make_shader(ctx->device, rgen_spv);
    VkShaderModule sm_rmiss = make_shader(ctx->device, rmiss_spv);
    VkShaderModule sm_rint  = make_shader(ctx->device, rint_spv);
    VkShaderModule sm_rahit = make_shader(ctx->device, rahit_spv);

    // Descriptor set layout
    std::vector<VkDescriptorSetLayoutBinding> bindings(binding_count);
    for (uint32_t i = 0; i < binding_count; ++i) {
        bindings[i].binding         = i;
        bindings[i].stageFlags      = VK_SHADER_STAGE_ALL;
        bindings[i].descriptorCount = 1;
        if (i == 0)
            bindings[i].descriptorType = VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR;
        else
            bindings[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    }
    // binding 3 is UBO
    if (binding_count > 3) bindings[3].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;

    VkDescriptorSetLayoutCreateInfo dsl_ci{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO };
    dsl_ci.bindingCount = binding_count;
    dsl_ci.pBindings    = bindings.data();

    RtPipeline pipe;
    VK_CHECK(vkCreateDescriptorSetLayout(ctx->device, &dsl_ci, nullptr, &pipe.dset_layout));

    VkPipelineLayoutCreateInfo pl_ci{ VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO };
    pl_ci.setLayoutCount = 1;
    pl_ci.pSetLayouts    = &pipe.dset_layout;
    VK_CHECK(vkCreatePipelineLayout(ctx->device, &pl_ci, nullptr, &pipe.layout));

    // Shader stages + groups
    VkPipelineShaderStageCreateInfo stages[4]{};
    stages[0] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_RAYGEN_BIT_KHR,      sm_rgen,  "main", nullptr };
    stages[1] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_MISS_BIT_KHR,         sm_rmiss, "main", nullptr };
    stages[2] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_INTERSECTION_BIT_KHR, sm_rint,  "main", nullptr };
    stages[3] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_ANY_HIT_BIT_KHR,      sm_rahit, "main", nullptr };

    VkRayTracingShaderGroupCreateInfoKHR groups[3]{};
    // raygen group
    groups[0] = { VK_STRUCTURE_TYPE_RAY_TRACING_SHADER_GROUP_CREATE_INFO_KHR };
    groups[0].type               = VK_RAY_TRACING_SHADER_GROUP_TYPE_GENERAL_KHR;
    groups[0].generalShader      = 0;
    groups[0].closestHitShader   = VK_SHADER_UNUSED_KHR;
    groups[0].anyHitShader       = VK_SHADER_UNUSED_KHR;
    groups[0].intersectionShader = VK_SHADER_UNUSED_KHR;
    // miss group
    groups[1] = { VK_STRUCTURE_TYPE_RAY_TRACING_SHADER_GROUP_CREATE_INFO_KHR };
    groups[1].type               = VK_RAY_TRACING_SHADER_GROUP_TYPE_GENERAL_KHR;
    groups[1].generalShader      = 1;
    groups[1].closestHitShader   = VK_SHADER_UNUSED_KHR;
    groups[1].anyHitShader       = VK_SHADER_UNUSED_KHR;
    groups[1].intersectionShader = VK_SHADER_UNUSED_KHR;
    // hit group (custom intersection + anyhit)
    groups[2] = { VK_STRUCTURE_TYPE_RAY_TRACING_SHADER_GROUP_CREATE_INFO_KHR };
    groups[2].type               = VK_RAY_TRACING_SHADER_GROUP_TYPE_PROCEDURAL_HIT_GROUP_KHR;
    groups[2].generalShader      = VK_SHADER_UNUSED_KHR;
    groups[2].closestHitShader   = VK_SHADER_UNUSED_KHR;
    groups[2].anyHitShader       = 3;
    groups[2].intersectionShader = 2;

    VkRayTracingPipelineCreateInfoKHR pipe_ci{
        VK_STRUCTURE_TYPE_RAY_TRACING_PIPELINE_CREATE_INFO_KHR };
    pipe_ci.stageCount          = 4;
    pipe_ci.pStages             = stages;
    pipe_ci.groupCount          = 3;
    pipe_ci.pGroups             = groups;
    pipe_ci.maxPipelineRayRecursionDepth = 1;
    pipe_ci.layout              = pipe.layout;

    VK_CHECK(ctx->fns.vkCreateRayTracingPipelinesKHR(
        ctx->device, VK_NULL_HANDLE, VK_NULL_HANDLE, 1, &pipe_ci, nullptr, &pipe.pipeline));

    vkDestroyShaderModule(ctx->device, sm_rgen,  nullptr);
    vkDestroyShaderModule(ctx->device, sm_rmiss, nullptr);
    vkDestroyShaderModule(ctx->device, sm_rint,  nullptr);
    vkDestroyShaderModule(ctx->device, sm_rahit, nullptr);

    // Shader binding table
    uint32_t h = ctx->handle_size;
    uint32_t a = ctx->handle_align;
    uint32_t entry_sz = (h + (a - 1)) & ~(a - 1);
    // 3 entries: rgen, miss, hitgroup
    uint32_t sbt_sz = 3 * entry_sz;
    std::vector<uint8_t> handles(3 * h);
    VK_CHECK(ctx->fns.vkGetRayTracingShaderGroupHandlesKHR(
        ctx->device, pipe.pipeline, 0, 3, 3 * h, handles.data()));

    // Pack into aligned SBT buffer
    std::vector<uint8_t> sbt_data(sbt_sz, 0);
    std::memcpy(sbt_data.data() + 0 * entry_sz, handles.data() + 0 * h, h);
    std::memcpy(sbt_data.data() + 1 * entry_sz, handles.data() + 1 * h, h);
    std::memcpy(sbt_data.data() + 2 * entry_sz, handles.data() + 2 * h, h);

    uint32_t base_align = ctx->rt_props.shaderGroupBaseAlignment;
    uint32_t sbt_buf_sz = ((sbt_sz + base_align - 1) / base_align) * base_align;
    pipe.sbt_buf = alloc_buffer(ctx, sbt_buf_sz,
        VK_BUFFER_USAGE_SHADER_BINDING_TABLE_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, pipe.sbt_buf, sbt_data.data(), sbt_sz);

    VkDeviceAddress sbt_addr = buf_addr(ctx, pipe.sbt_buf.buffer);
    pipe.rgen_region = { sbt_addr + 0 * entry_sz, entry_sz, entry_sz };
    pipe.miss_region = { sbt_addr + 1 * entry_sz, entry_sz, entry_sz };
    pipe.hit_region  = { sbt_addr + 2 * entry_sz, entry_sz, entry_sz };
    pipe.call_region = { 0, 0, 0 };

    return pipe;
}

// Build a ray-tracing pipeline for native triangle geometry.
// Uses VK_RAY_TRACING_SHADER_GROUP_TYPE_TRIANGLES_HIT_GROUP_KHR (no intersection shader).
// Binding layout matches build_rt_pipeline: TLAS at 0, UBO at 3, SSBOs elsewhere.
static RtPipeline build_rt_pipeline_triangle(
        VkContext* ctx,
        const char* rgen_glsl, const char* rmiss_glsl, const char* rahit_glsl,
        const char* rgen_name, const char* rmiss_name, const char* rahit_name,
        uint32_t binding_count)
{
    auto rgen_spv = compile_glsl(rgen_glsl, shaderc_raygen_shader,  rgen_name);
    auto rmiss_spv= compile_glsl(rmiss_glsl, shaderc_miss_shader,   rmiss_name);
    auto rahit_spv= compile_glsl(rahit_glsl, shaderc_anyhit_shader, rahit_name);

    VkShaderModule sm_rgen  = make_shader(ctx->device, rgen_spv);
    VkShaderModule sm_rmiss = make_shader(ctx->device, rmiss_spv);
    VkShaderModule sm_rahit = make_shader(ctx->device, rahit_spv);

    std::vector<VkDescriptorSetLayoutBinding> bindings(binding_count);
    for (uint32_t i = 0; i < binding_count; ++i) {
        bindings[i].binding         = i;
        bindings[i].stageFlags      = VK_SHADER_STAGE_ALL;
        bindings[i].descriptorCount = 1;
        bindings[i].descriptorType  =
            (i == 0) ? VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR
                     : VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    }
    if (binding_count > 3) bindings[3].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;

    RtPipeline pipe;
    VkDescriptorSetLayoutCreateInfo dsl_ci{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO };
    dsl_ci.bindingCount = binding_count; dsl_ci.pBindings = bindings.data();
    VK_CHECK(vkCreateDescriptorSetLayout(ctx->device, &dsl_ci, nullptr, &pipe.dset_layout));

    VkPipelineLayoutCreateInfo pl_ci{ VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO };
    pl_ci.setLayoutCount = 1; pl_ci.pSetLayouts = &pipe.dset_layout;
    VK_CHECK(vkCreatePipelineLayout(ctx->device, &pl_ci, nullptr, &pipe.layout));

    // Three shader stages: rgen, rmiss, rahit
    VkPipelineShaderStageCreateInfo stages[3]{};
    stages[0] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_RAYGEN_BIT_KHR, sm_rgen,  "main", nullptr };
    stages[1] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_MISS_BIT_KHR,   sm_rmiss, "main", nullptr };
    stages[2] = { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, nullptr, 0,
                  VK_SHADER_STAGE_ANY_HIT_BIT_KHR, sm_rahit, "main", nullptr };

    VkRayTracingShaderGroupCreateInfoKHR groups[3]{};
    groups[0] = { VK_STRUCTURE_TYPE_RAY_TRACING_SHADER_GROUP_CREATE_INFO_KHR };
    groups[0].type = VK_RAY_TRACING_SHADER_GROUP_TYPE_GENERAL_KHR;
    groups[0].generalShader = 0; groups[0].closestHitShader = VK_SHADER_UNUSED_KHR;
    groups[0].anyHitShader  = VK_SHADER_UNUSED_KHR; groups[0].intersectionShader = VK_SHADER_UNUSED_KHR;
    groups[1] = { VK_STRUCTURE_TYPE_RAY_TRACING_SHADER_GROUP_CREATE_INFO_KHR };
    groups[1].type = VK_RAY_TRACING_SHADER_GROUP_TYPE_GENERAL_KHR;
    groups[1].generalShader = 1; groups[1].closestHitShader = VK_SHADER_UNUSED_KHR;
    groups[1].anyHitShader  = VK_SHADER_UNUSED_KHR; groups[1].intersectionShader = VK_SHADER_UNUSED_KHR;
    // Triangle hit group: hardware handles intersection, any-hit counts hits
    groups[2] = { VK_STRUCTURE_TYPE_RAY_TRACING_SHADER_GROUP_CREATE_INFO_KHR };
    groups[2].type = VK_RAY_TRACING_SHADER_GROUP_TYPE_TRIANGLES_HIT_GROUP_KHR;
    groups[2].generalShader      = VK_SHADER_UNUSED_KHR;
    groups[2].closestHitShader   = VK_SHADER_UNUSED_KHR;
    groups[2].anyHitShader       = 2; // rahit stage
    groups[2].intersectionShader = VK_SHADER_UNUSED_KHR;

    VkRayTracingPipelineCreateInfoKHR pipe_ci{
        VK_STRUCTURE_TYPE_RAY_TRACING_PIPELINE_CREATE_INFO_KHR };
    pipe_ci.stageCount = 3; pipe_ci.pStages  = stages;
    pipe_ci.groupCount = 3; pipe_ci.pGroups  = groups;
    pipe_ci.maxPipelineRayRecursionDepth = 1;
    pipe_ci.layout = pipe.layout;
    VK_CHECK(ctx->fns.vkCreateRayTracingPipelinesKHR(
        ctx->device, VK_NULL_HANDLE, VK_NULL_HANDLE, 1, &pipe_ci, nullptr, &pipe.pipeline));

    vkDestroyShaderModule(ctx->device, sm_rgen,  nullptr);
    vkDestroyShaderModule(ctx->device, sm_rmiss, nullptr);
    vkDestroyShaderModule(ctx->device, sm_rahit, nullptr);

    // SBT: 3 entries (rgen, miss, hitgroup) - same layout as build_rt_pipeline
    uint32_t h = ctx->handle_size, a = ctx->handle_align;
    uint32_t entry_sz = (h + (a - 1)) & ~(a - 1);
    uint32_t sbt_sz   = 3u * entry_sz;
    std::vector<uint8_t> handles(3u * h);
    VK_CHECK(ctx->fns.vkGetRayTracingShaderGroupHandlesKHR(
        ctx->device, pipe.pipeline, 0, 3, 3u * h, handles.data()));
    std::vector<uint8_t> sbt_data(sbt_sz, 0);
    std::memcpy(sbt_data.data() + 0 * entry_sz, handles.data() + 0 * h, h);
    std::memcpy(sbt_data.data() + 1 * entry_sz, handles.data() + 1 * h, h);
    std::memcpy(sbt_data.data() + 2 * entry_sz, handles.data() + 2 * h, h);

    uint32_t base_align = ctx->rt_props.shaderGroupBaseAlignment;
    uint32_t sbt_buf_sz = ((sbt_sz + base_align - 1) / base_align) * base_align;
    pipe.sbt_buf = alloc_buffer(ctx, sbt_buf_sz,
        VK_BUFFER_USAGE_SHADER_BINDING_TABLE_BIT_KHR |
        VK_BUFFER_USAGE_SHADER_DEVICE_ADDRESS_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, pipe.sbt_buf, sbt_data.data(), sbt_sz);

    VkDeviceAddress sbt_addr = buf_addr(ctx, pipe.sbt_buf.buffer);
    pipe.rgen_region = { sbt_addr + 0u * entry_sz, entry_sz, entry_sz };
    pipe.miss_region = { sbt_addr + 1u * entry_sz, entry_sz, entry_sz };
    pipe.hit_region  = { sbt_addr + 2u * entry_sz, entry_sz, entry_sz };
    pipe.call_region = { 0, 0, 0 };
    return pipe;
}

static ComputePipeline build_compute_pipeline(
        VkContext* ctx, const char* glsl_src, const char* name,
        uint32_t binding_count) {
    auto spv = compile_glsl(glsl_src, shaderc_compute_shader, name);
    VkShaderModule mod = make_shader(ctx->device, spv);

    std::vector<VkDescriptorSetLayoutBinding> bindings(binding_count);
    for (uint32_t i = 0; i < binding_count; ++i) {
        bindings[i] = { i, VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1, VK_SHADER_STAGE_COMPUTE_BIT };
    }
    if (binding_count > 3) bindings[3].descriptorType = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;

    ComputePipeline pipe;
    VkDescriptorSetLayoutCreateInfo dsl_ci{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO };
    dsl_ci.bindingCount = binding_count; dsl_ci.pBindings = bindings.data();
    VK_CHECK(vkCreateDescriptorSetLayout(ctx->device, &dsl_ci, nullptr, &pipe.dset_layout));
    VkPipelineLayoutCreateInfo pl_ci{ VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO };
    pl_ci.setLayoutCount = 1; pl_ci.pSetLayouts = &pipe.dset_layout;
    VK_CHECK(vkCreatePipelineLayout(ctx->device, &pl_ci, nullptr, &pipe.layout));

    VkPipelineShaderStageCreateInfo stage{ VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO };
    stage.stage  = VK_SHADER_STAGE_COMPUTE_BIT;
    stage.module = mod;
    stage.pName  = "main";
    VkComputePipelineCreateInfo comp_ci{ VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO };
    comp_ci.stage = stage; comp_ci.layout = pipe.layout;
    VK_CHECK(vkCreateComputePipelines(ctx->device, VK_NULL_HANDLE, 1, &comp_ci, nullptr, &pipe.pipeline));
    vkDestroyShaderModule(ctx->device, mod, nullptr);
    return pipe;
}

// Descriptor set management ------------------------------------------------

struct DescriptorSet {
    VkDescriptorPool pool = VK_NULL_HANDLE;
    VkDescriptorSet  set  = VK_NULL_HANDLE;
};

static DescriptorSet alloc_descriptor_set(VkContext* ctx, VkDescriptorSetLayout layout,
                                           uint32_t binding_count, bool has_tlas) {
    std::vector<VkDescriptorPoolSize> pool_sizes;
    if (has_tlas) pool_sizes.push_back({ VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR, 1 });
    pool_sizes.push_back({ VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, binding_count });
    pool_sizes.push_back({ VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER, 1 });

    VkDescriptorPoolCreateInfo pool_ci{ VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO };
    pool_ci.maxSets       = 1;
    pool_ci.poolSizeCount = static_cast<uint32_t>(pool_sizes.size());
    pool_ci.pPoolSizes    = pool_sizes.data();

    DescriptorSet ds;
    VK_CHECK(vkCreateDescriptorPool(ctx->device, &pool_ci, nullptr, &ds.pool));

    VkDescriptorSetAllocateInfo alloc_info{ VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO };
    alloc_info.descriptorPool     = ds.pool;
    alloc_info.descriptorSetCount = 1;
    alloc_info.pSetLayouts        = &layout;
    VK_CHECK(vkAllocateDescriptorSets(ctx->device, &alloc_info, &ds.set));
    return ds;
}

static void bind_tlas(VkContext* ctx, VkDescriptorSet ds,
                       VkAccelerationStructureKHR tlas, uint32_t binding) {
    VkWriteDescriptorSetAccelerationStructureKHR as_write{
        VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET_ACCELERATION_STRUCTURE_KHR };
    as_write.accelerationStructureCount = 1;
    as_write.pAccelerationStructures    = &tlas;
    VkWriteDescriptorSet write{ VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET };
    write.pNext            = &as_write;
    write.dstSet           = ds;
    write.dstBinding       = binding;
    write.descriptorCount  = 1;
    write.descriptorType   = VK_DESCRIPTOR_TYPE_ACCELERATION_STRUCTURE_KHR;
    vkUpdateDescriptorSets(ctx->device, 1, &write, 0, nullptr);
}

static void bind_ssbo(VkDevice dev, VkDescriptorSet ds, VkBuffer buf, VkDeviceSize sz, uint32_t binding) {
    VkDescriptorBufferInfo info{ buf, 0, sz };
    VkWriteDescriptorSet write{ VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET };
    write.dstSet          = ds;
    write.dstBinding      = binding;
    write.descriptorCount = 1;
    write.descriptorType  = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
    write.pBufferInfo     = &info;
    vkUpdateDescriptorSets(dev, 1, &write, 0, nullptr);
}

static void bind_ubo(VkDevice dev, VkDescriptorSet ds, VkBuffer buf, VkDeviceSize sz, uint32_t binding) {
    VkDescriptorBufferInfo info{ buf, 0, sz };
    VkWriteDescriptorSet write{ VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET };
    write.dstSet          = ds;
    write.dstBinding      = binding;
    write.descriptorCount = 1;
    write.descriptorType  = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER;
    write.pBufferInfo     = &info;
    vkUpdateDescriptorSets(dev, 1, &write, 0, nullptr);
}

// Dispatch a ray-tracing pipeline and wait for completion
static void dispatch_rt(VkContext* ctx, RtPipeline& pipe,
                         VkDescriptorSet ds, uint32_t width, uint32_t height = 1u, uint32_t depth = 1u) {
    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool = ctx->cmd_pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_RAY_TRACING_KHR, pipe.pipeline);
    vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_RAY_TRACING_KHR,
                             pipe.layout, 0, 1, &ds, 0, nullptr);
    ctx->fns.vkCmdTraceRaysKHR(cmd,
        &pipe.rgen_region, &pipe.miss_region, &pipe.hit_region, &pipe.call_region,
        width, height, depth);
    // Barrier: RT writes -> host reads
    VkMemoryBarrier barrier{ VK_STRUCTURE_TYPE_MEMORY_BARRIER };
    barrier.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_RAY_TRACING_SHADER_BIT_KHR,
        VK_PIPELINE_STAGE_TRANSFER_BIT,
        0, 1, &barrier, 0, nullptr, 0, nullptr);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
}

static void dispatch_compute(VkContext* ctx, ComputePipeline& pipe,
                              VkDescriptorSet ds, uint32_t groups_x) {
    VkCommandBuffer cmd;
    VkCommandBufferAllocateInfo alloc{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
    alloc.commandPool = ctx->cmd_pool; alloc.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    alloc.commandBufferCount = 1;
    VK_CHECK(vkAllocateCommandBuffers(ctx->device, &alloc, &cmd));
    VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    vkBeginCommandBuffer(cmd, &begin);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipe.pipeline);
    vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE,
                             pipe.layout, 0, 1, &ds, 0, nullptr);
    vkCmdDispatch(cmd, groups_x, 1, 1);
    VkMemoryBarrier barrier{ VK_STRUCTURE_TYPE_MEMORY_BARRIER };
    barrier.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
    barrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    vkCmdPipelineBarrier(cmd,
        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
        VK_PIPELINE_STAGE_TRANSFER_BIT,
        0, 1, &barrier, 0, nullptr, 0, nullptr);
    vkEndCommandBuffer(cmd);
    VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
    sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
    vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
    vkQueueWaitIdle(ctx->queue);
    vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
}

// Pipeline cache singletons ------------------------------------------------

static RtPipeline*      g_segment_pair_intersection_pipe    = nullptr;
static RtPipeline*      g_pip_pipe    = nullptr;
static RtPipeline*      g_pip_pos_count_pipe = nullptr;
static RtPipeline*      g_pip_pos_pipe= nullptr;
static RtPipeline*      g_shape_pair_relation_pipe= nullptr;
static RtPipeline*      g_rhc_pipe    = nullptr;
static RtPipeline*      g_rah_pipe    = nullptr;
static RtPipeline*      g_sph_pipe    = nullptr;
static ComputePipeline* g_pns_pipe    = nullptr;
static ComputePipeline* g_frn_pipe    = nullptr;
static ComputePipeline* g_frn3d_pipe  = nullptr;
static ComputePipeline* g_knn_pipe    = nullptr;
static ComputePipeline* g_knn3d_pipe  = nullptr;
static RtPipeline*      g_dbscan_pipe = nullptr;
static std::once_flag   g_segment_pair_intersection_init, g_pip_init, g_pip_pos_count_init, g_pip_pos_init, g_shape_pair_relation_init;
static std::once_flag   g_rhc_init, g_rah_init, g_sph_init, g_pns_init, g_frn_init, g_knn_init;
static std::once_flag   g_frn3d_init, g_knn3d_init;
static RtPipeline*      g_rhc3d_pipe = nullptr;
static RtPipeline*      g_rah3d_pipe = nullptr;
static std::once_flag   g_rhc3d_init, g_rah3d_init;
static std::once_flag   g_dbscan_init;

// Workload run functions ---------------------------------------------------

struct DbScanParams {
    uint32_t hit_word_count;
    uint32_t x_lo;
    uint32_t y_lo;
    uint32_t z_lo;
    uint32_t z_hi;
    uint32_t x_count;
    uint32_t y_count;
    uint32_t pad0;
};

static size_t db_find_field_index_or_throw(
        const RtdlDbField* fields,
        size_t field_count,
        const char* name)
{
    if (!name) {
        throw std::runtime_error("DB field name must not be null");
    }
    for (size_t index = 0; index < field_count; ++index) {
        if (fields[index].name && std::strcmp(fields[index].name, name) == 0) {
            return index;
        }
    }
    throw std::runtime_error(std::string("unknown DB field: ") + name);
}

static const RtdlDbScalar& db_row_value(
        const RtdlDbScalar* row_values,
        size_t row_index,
        size_t field_count,
        size_t field_index)
{
    return row_values[row_index * field_count + field_index];
}

static bool db_scalar_is_numeric(const RtdlDbScalar& value)
{
    return value.kind == kDbKindInt64 || value.kind == kDbKindFloat64 || value.kind == kDbKindBool;
}

static bool db_field_kind_is_numeric(uint32_t kind)
{
    return kind == kDbKindInt64 || kind == kDbKindFloat64 || kind == kDbKindBool;
}

static double db_scalar_as_double(const RtdlDbScalar& value)
{
    if (value.kind == kDbKindInt64 || value.kind == kDbKindBool) {
        return static_cast<double>(value.int_value);
    }
    if (value.kind == kDbKindFloat64) {
        return value.double_value;
    }
    throw std::runtime_error("DB scalar is not numeric");
}

static int db_compare_scalar(const RtdlDbScalar& left, const RtdlDbScalar& right)
{
    if (left.kind != right.kind) {
        const double lhs = db_scalar_as_double(left);
        const double rhs = db_scalar_as_double(right);
        if (lhs < rhs) return -1;
        if (lhs > rhs) return 1;
        return 0;
    }
    switch (left.kind) {
        case kDbKindInt64:
        case kDbKindBool:
            if (left.int_value < right.int_value) return -1;
            if (left.int_value > right.int_value) return 1;
            return 0;
        case kDbKindFloat64:
            if (left.double_value < right.double_value) return -1;
            if (left.double_value > right.double_value) return 1;
            return 0;
        case kDbKindText: {
            const char* lhs = left.string_value ? left.string_value : "";
            const char* rhs = right.string_value ? right.string_value : "";
            const int cmp = std::strcmp(lhs, rhs);
            if (cmp < 0) return -1;
            if (cmp > 0) return 1;
            return 0;
        }
        default:
            throw std::runtime_error("unsupported DB scalar kind");
    }
}

static bool db_clause_matches_scalar(const RtdlDbClause& clause, const RtdlDbScalar& candidate)
{
    const int cmp_lo = db_compare_scalar(candidate, clause.value);
    switch (clause.op) {
        case kDbOpEq:
            return cmp_lo == 0;
        case kDbOpLt:
            return cmp_lo < 0;
        case kDbOpLe:
            return cmp_lo <= 0;
        case kDbOpGt:
            return cmp_lo > 0;
        case kDbOpGe:
            return cmp_lo >= 0;
        case kDbOpBetween:
            return cmp_lo >= 0 && db_compare_scalar(candidate, clause.value_hi) <= 0;
        default:
            throw std::runtime_error("unsupported DB clause op");
    }
}

static bool db_row_matches_all_clauses(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_index,
        const RtdlDbClause* clauses,
        size_t clause_count)
{
    for (size_t clause_index = 0; clause_index < clause_count; ++clause_index) {
        const size_t field_index = db_find_field_index_or_throw(fields, field_count, clauses[clause_index].field);
        const RtdlDbScalar& candidate = db_row_value(row_values, row_index, field_count, field_index);
        if (!db_clause_matches_scalar(clauses[clause_index], candidate)) {
            return false;
        }
    }
    return true;
}

static std::vector<double> db_sorted_distinct_numeric_values(
        const RtdlDbScalar* row_values,
        size_t row_count,
        size_t field_count,
        size_t field_index)
{
    std::vector<double> values;
    values.reserve(row_count);
    for (size_t row_index = 0; row_index < row_count; ++row_index) {
        const RtdlDbScalar& value = db_row_value(row_values, row_index, field_count, field_index);
        if (!db_scalar_is_numeric(value)) {
            throw std::runtime_error("first-wave Vulkan DB lowering requires numeric primary scan clauses");
        }
        values.push_back(db_scalar_as_double(value));
    }
    std::sort(values.begin(), values.end());
    values.erase(std::unique(values.begin(), values.end()), values.end());
    return values;
}

static bool db_clause_matches_numeric_value(const RtdlDbClause& clause, double value)
{
    const double lo = db_scalar_as_double(clause.value);
    switch (clause.op) {
        case kDbOpEq:
            return value == lo;
        case kDbOpLt:
            return value < lo;
        case kDbOpLe:
            return value <= lo;
        case kDbOpGt:
            return value > lo;
        case kDbOpGe:
            return value >= lo;
        case kDbOpBetween:
            return value >= lo && value <= db_scalar_as_double(clause.value_hi);
        default:
            throw std::runtime_error("unsupported DB clause op");
    }
}

static DbPrimaryAxis db_make_primary_axis(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const RtdlDbClause& clause)
{
    const size_t field_index = db_find_field_index_or_throw(fields, field_count, clause.field);
    const std::vector<double> sorted_values =
        db_sorted_distinct_numeric_values(row_values, row_count, field_count, field_index);
    int64_t encoded_lo = -1;
    int64_t encoded_hi = -1;
    for (size_t index = 0; index < sorted_values.size(); ++index) {
        if (!db_clause_matches_numeric_value(clause, sorted_values[index])) {
            continue;
        }
        const int64_t encoded = static_cast<int64_t>(index + 1);
        if (encoded_lo < 0) {
            encoded_lo = encoded;
        }
        encoded_hi = encoded;
    }
    if (encoded_lo < 0 || encoded_hi < 0) {
        return {field_index, sorted_values, 1, 0};
    }
    return {field_index, sorted_values, encoded_lo, encoded_hi};
}

static DbPrimaryAxis db_make_full_primary_axis(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const char* field_name)
{
    const size_t field_index = db_find_field_index_or_throw(fields, field_count, field_name);
    if (!db_field_kind_is_numeric(fields[field_index].kind)) {
        throw std::runtime_error("first-wave Vulkan prepared DB datasets require numeric primary RT axes");
    }
    const std::vector<double> sorted_values =
        db_sorted_distinct_numeric_values(row_values, row_count, field_count, field_index);
    return {
        field_index,
        sorted_values,
        1,
        sorted_values.empty() ? 0 : static_cast<int64_t>(sorted_values.size())};
}

static DbPrimaryAxis db_axis_with_clause_range(const DbPrimaryAxis& axis, const RtdlDbClause& clause)
{
    DbPrimaryAxis ranged = axis;
    int64_t encoded_lo = -1;
    int64_t encoded_hi = -1;
    for (size_t index = 0; index < axis.sorted_values.size(); ++index) {
        if (!db_clause_matches_numeric_value(clause, axis.sorted_values[index])) {
            continue;
        }
        const int64_t encoded = static_cast<int64_t>(index + 1);
        if (encoded_lo < 0) {
            encoded_lo = encoded;
        }
        encoded_hi = encoded;
    }
    ranged.encoded_lo = encoded_lo < 0 ? 1 : encoded_lo;
    ranged.encoded_hi = encoded_hi < 0 ? 0 : encoded_hi;
    return ranged;
}

static int64_t db_encode_axis_value(const DbPrimaryAxis& axis, const RtdlDbScalar& value)
{
    const double needle = db_scalar_as_double(value);
    const auto it = std::lower_bound(axis.sorted_values.begin(), axis.sorted_values.end(), needle);
    if (it == axis.sorted_values.end() || *it != needle) {
        throw std::runtime_error("failed to encode Vulkan DB primary-axis value");
    }
    return static_cast<int64_t>(std::distance(axis.sorted_values.begin(), it) + 1);
}

static std::vector<DbRowMeta> db_build_row_metas(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count)
{
    const size_t row_id_index = db_find_field_index_or_throw(fields, field_count, "row_id");
    std::vector<DbRowMeta> metas;
    metas.reserve(row_count);
    for (size_t row_index = 0; row_index < row_count; ++row_index) {
        const RtdlDbScalar& row_id_value = db_row_value(row_values, row_index, field_count, row_id_index);
        metas.push_back({row_index, static_cast<uint32_t>(row_id_value.int_value)});
    }
    return metas;
}

static std::vector<GpuAabb> db_build_row_aabbs(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const std::vector<DbPrimaryAxis>& axes)
{
    std::vector<GpuAabb> aabbs;
    aabbs.reserve(row_count);
    for (size_t row_index = 0; row_index < row_count; ++row_index) {
        const float x = axes.size() >= 1
            ? static_cast<float>(db_encode_axis_value(axes[0], db_row_value(row_values, row_index, field_count, axes[0].field_index)))
            : 1.0f;
        const float y = axes.size() >= 2
            ? static_cast<float>(db_encode_axis_value(axes[1], db_row_value(row_values, row_index, field_count, axes[1].field_index)))
            : 1.0f;
        const float z = axes.size() >= 3
            ? static_cast<float>(db_encode_axis_value(axes[2], db_row_value(row_values, row_index, field_count, axes[2].field_index)))
            : 1.0f;
        aabbs.push_back({x - kDbBoxPad, y - kDbBoxPad, z - kDbBoxPad, x + kDbBoxPad, y + kDbBoxPad, z + kDbBoxPad});
    }
    return aabbs;
}

static std::vector<DbPrimaryAxis> db_dataset_query_axes(
        const VulkanDbDatasetImpl& dataset,
        const RtdlDbClause* clauses,
        size_t clause_count)
{
    std::vector<DbPrimaryAxis> axes = dataset.primary_axes;
    for (DbPrimaryAxis& axis : axes) {
        const char* axis_field = dataset.fields[axis.field_index].name;
        for (size_t clause_index = 0; clause_index < clause_count; ++clause_index) {
            if (std::strcmp(axis_field, clauses[clause_index].field) != 0) {
                continue;
            }
            axis = db_axis_with_clause_range(axis, clauses[clause_index]);
            break;
        }
    }
    return axes;
}

static std::vector<const char*> db_default_primary_fields(const RtdlDbField* fields, size_t field_count)
{
    std::vector<const char*> names;
    for (size_t index = 0; index < field_count && names.size() < 3; ++index) {
        if (std::strcmp(fields[index].name, "row_id") == 0) {
            continue;
        }
        if (db_field_kind_is_numeric(fields[index].kind)) {
            names.push_back(fields[index].name);
        }
    }
    return names;
}

static size_t db_count_scalar_strings(const RtdlDbScalar* row_values, size_t scalar_count)
{
    size_t count = 0;
    for (size_t index = 0; index < scalar_count; ++index) {
        if (row_values[index].kind == kDbKindText && row_values[index].string_value) {
            ++count;
        }
    }
    return count;
}

static void db_copy_dataset_payload(
        VulkanDbDatasetImpl& dataset,
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count)
{
    dataset.field_names.reserve(field_count);
    for (size_t index = 0; index < field_count; ++index) {
        dataset.field_names.emplace_back(fields[index].name ? fields[index].name : "");
    }
    dataset.fields.reserve(field_count);
    for (size_t index = 0; index < field_count; ++index) {
        dataset.fields.push_back({dataset.field_names[index].c_str(), fields[index].kind});
    }

    const size_t scalar_count = row_count * field_count;
    dataset.scalar_strings.reserve(db_count_scalar_strings(row_values, scalar_count));
    dataset.row_values.reserve(scalar_count);
    for (size_t index = 0; index < scalar_count; ++index) {
        RtdlDbScalar copied = row_values[index];
        if (copied.kind == kDbKindText && copied.string_value) {
            dataset.scalar_strings.emplace_back(copied.string_value);
            copied.string_value = dataset.scalar_strings.back().c_str();
        }
        dataset.row_values.push_back(copied);
    }
    dataset.row_count = row_count;
}

static void db_validate_columnar_inputs(
        const RtdlPayloadField* fields,
        size_t field_count,
        size_t row_count)
{
    if (!fields || field_count == 0) {
        throw std::runtime_error("payload fields must not be null");
    }
    if (row_count > kDbMaxRowsPerJob) {
        throw std::runtime_error("first-wave Vulkan DB lowering supports at most 1000000 rows per RT job");
    }
    for (size_t field_index = 0; field_index < field_count; ++field_index) {
        const RtdlPayloadField& field = fields[field_index];
        if (!field.name) {
            throw std::runtime_error("field name must not be null");
        }
        if (field.kind == kDbKindText) {
            if (!field.string_values) {
                throw std::runtime_error("field text values must not be null");
            }
        } else if (db_field_kind_is_numeric(field.kind)) {
            if (!field.int_values && !field.double_values) {
                throw std::runtime_error("field numeric values must not be null");
            }
        } else {
            throw std::runtime_error("unsupported field kind");
        }
    }
}

static void db_copy_dataset_columnar_payload(
        VulkanDbDatasetImpl& dataset,
        const RtdlPayloadField* fields,
        size_t field_count,
        size_t row_count)
{
    dataset.field_names.reserve(field_count);
    for (size_t index = 0; index < field_count; ++index) {
        dataset.field_names.emplace_back(fields[index].name ? fields[index].name : "");
    }
    dataset.fields.reserve(field_count);
    for (size_t index = 0; index < field_count; ++index) {
        dataset.fields.push_back({dataset.field_names[index].c_str(), fields[index].kind});
    }

    dataset.row_values.reserve(row_count * field_count);
    for (size_t row_index = 0; row_index < row_count; ++row_index) {
        for (size_t field_index = 0; field_index < field_count; ++field_index) {
            const RtdlPayloadField& field = fields[field_index];
            RtdlDbScalar copied{};
            copied.kind = field.kind;
            if (field.kind == kDbKindText) {
                const char* value = field.string_values[row_index];
                if (value) {
                    dataset.scalar_strings.emplace_back(value);
                    copied.string_value = dataset.scalar_strings.back().c_str();
                }
            } else if (field.double_values) {
                copied.double_value = field.double_values[row_index];
                copied.int_value = static_cast<int64_t>(copied.double_value);
            } else {
                copied.int_value = field.int_values[row_index];
                copied.double_value = static_cast<double>(copied.int_value);
            }
            dataset.row_values.push_back(copied);
        }
    }
    dataset.row_count = row_count;
}

static void db_validate_db_inputs(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const RtdlDbClause* clauses,
        size_t clause_count)
{
    if (!fields || field_count == 0 || !row_values) {
        throw std::runtime_error("dataset inputs must not be null");
    }
    if (clause_count > 0 && !clauses) {
        throw std::runtime_error("DB clause pointer must not be null when clause_count > 0");
    }
    if (row_count > kDbMaxRowsPerJob) {
        throw std::runtime_error("first-wave Vulkan DB lowering supports at most 1000000 rows per RT job");
    }
}

static std::vector<size_t> db_collect_candidate_row_indices_vulkan(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const RtdlDbClause* clauses,
        size_t clause_count)
{
    VkContext* ctx = get_context();
    std::vector<DbPrimaryAxis> axes;
    axes.reserve(std::min<size_t>(clause_count, 3));
    for (size_t i = 0; i < clause_count && i < 3; ++i) {
        axes.push_back(db_make_primary_axis(fields, field_count, row_values, row_count, clauses[i]));
    }
    const std::vector<GpuAabb> aabbs = db_build_row_aabbs(fields, field_count, row_values, row_count, axes);

    const uint32_t x_lo = axes.size() >= 1 ? static_cast<uint32_t>(axes[0].encoded_lo) : 1u;
    const uint32_t x_hi = axes.size() >= 1 ? static_cast<uint32_t>(axes[0].encoded_hi) : 1u;
    const uint32_t y_lo = axes.size() >= 2 ? static_cast<uint32_t>(axes[1].encoded_lo) : 1u;
    const uint32_t y_hi = axes.size() >= 2 ? static_cast<uint32_t>(axes[1].encoded_hi) : 1u;
    const uint32_t z_lo = axes.size() >= 3 ? static_cast<uint32_t>(axes[2].encoded_lo) : 1u;
    const uint32_t z_hi = axes.size() >= 3 ? static_cast<uint32_t>(axes[2].encoded_hi) : 1u;
    if (x_lo > x_hi || y_lo > y_hi || z_lo > z_hi) {
        return {};
    }

    std::call_once(g_dbscan_init, [ctx]() {
        g_dbscan_pipe = new RtPipeline(build_rt_pipeline(
            ctx,
            kDbScanRgen, kDbScanRmiss, kDbScanRint, kDbScanRahit,
            "dbscan.rgen", "dbscan.rmiss", "dbscan.rint", "dbscan.rahit", 4));
    });

    AccelResult blas = build_aabb_blas(ctx, aabbs);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    const uint32_t hit_word_count = static_cast<uint32_t>((row_count + 31u) / 32u);
    const VkDeviceSize hit_words_bytes = sizeof(uint32_t) * hit_word_count;
    BufMem d_hit_words = alloc_buffer(ctx, hit_words_bytes,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_hit_words);

    DbScanParams params{
        hit_word_count,
        x_lo,
        y_lo,
        z_lo,
        z_hi,
        x_hi - x_lo + 1u,
        y_hi - y_lo + 1u,
        0u,
    };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mapped = nullptr;
    vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mapped);
    std::memcpy(mapped, &params, sizeof(params));
    vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_dbscan_pipe->dset_layout, 4, true);
    bind_tlas(ctx, ds.set, tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_hit_words.buffer, hit_words_bytes, 1);
    BufMem d_dummy = alloc_buffer(ctx, 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
    bind_ubo(ctx->device, ds.set, d_params.buffer, sizeof(params), 3);

    dispatch_rt(ctx, *g_dbscan_pipe, ds.set, params.x_count, params.y_count);

    std::vector<uint32_t> hit_words(hit_word_count, 0u);
    if (hit_word_count > 0) {
        download_from_buf(ctx, hit_words.data(), d_hit_words, hit_words_bytes);
    }

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_hit_words);
    free_buf(ctx, d_params);
    free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas);
    destroy_accel(ctx, blas);

    std::vector<size_t> row_indices;
    row_indices.reserve(std::min(row_count, kDbMaxCandidateRowsPerJob));
    for (size_t row_index = 0; row_index < row_count; ++row_index) {
        const uint32_t word = static_cast<uint32_t>(row_index >> 5);
        const uint32_t bit = 1u << (row_index & 31u);
        if ((hit_words[word] & bit) == 0u) {
            continue;
        }
        if (row_indices.size() >= kDbMaxCandidateRowsPerJob) {
            throw std::runtime_error("first-wave Vulkan DB lowering exceeded the 250000-candidate ceiling");
        }
        if (!db_row_matches_all_clauses(fields, field_count, row_values, row_index, clauses, clause_count)) {
            continue;
        }
        row_indices.push_back(row_index);
    }
    return row_indices;
}

static std::vector<size_t> db_collect_candidate_row_indices_vulkan_prepared(
        const VulkanDbDatasetImpl& dataset,
        const RtdlDbClause* clauses,
        size_t clause_count)
{
    VkContext* ctx = get_context();
    const std::vector<DbPrimaryAxis> axes = db_dataset_query_axes(dataset, clauses, clause_count);
    const uint32_t x_lo = axes.size() >= 1 ? static_cast<uint32_t>(axes[0].encoded_lo) : 1u;
    const uint32_t x_hi = axes.size() >= 1 ? static_cast<uint32_t>(axes[0].encoded_hi) : 1u;
    const uint32_t y_lo = axes.size() >= 2 ? static_cast<uint32_t>(axes[1].encoded_lo) : 1u;
    const uint32_t y_hi = axes.size() >= 2 ? static_cast<uint32_t>(axes[1].encoded_hi) : 1u;
    const uint32_t z_lo = axes.size() >= 3 ? static_cast<uint32_t>(axes[2].encoded_lo) : 1u;
    const uint32_t z_hi = axes.size() >= 3 ? static_cast<uint32_t>(axes[2].encoded_hi) : 1u;
    if (x_lo > x_hi || y_lo > y_hi || z_lo > z_hi) {
        return {};
    }

    std::call_once(g_dbscan_init, [ctx]() {
        g_dbscan_pipe = new RtPipeline(build_rt_pipeline(
            ctx,
            kDbScanRgen, kDbScanRmiss, kDbScanRint, kDbScanRahit,
            "dbscan.rgen", "dbscan.rmiss", "dbscan.rint", "dbscan.rahit", 4));
    });

    const uint32_t hit_word_count = static_cast<uint32_t>((dataset.row_count + 31u) / 32u);
    const VkDeviceSize hit_words_bytes = sizeof(uint32_t) * hit_word_count;
    BufMem d_hit_words = alloc_buffer(ctx, hit_words_bytes,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_hit_words);

    DbScanParams params{
        hit_word_count,
        x_lo,
        y_lo,
        z_lo,
        z_hi,
        x_hi - x_lo + 1u,
        y_hi - y_lo + 1u,
        0u,
    };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mapped = nullptr;
    vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mapped);
    std::memcpy(mapped, &params, sizeof(params));
    vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_dbscan_pipe->dset_layout, 4, true);
    bind_tlas(ctx, ds.set, dataset.tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_hit_words.buffer, hit_words_bytes, 1);
    BufMem d_dummy = alloc_buffer(ctx, 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
    bind_ubo(ctx->device, ds.set, d_params.buffer, sizeof(params), 3);

    dispatch_rt(ctx, *g_dbscan_pipe, ds.set, params.x_count, params.y_count);

    std::vector<uint32_t> hit_words(hit_word_count, 0u);
    if (hit_word_count > 0) {
        download_from_buf(ctx, hit_words.data(), d_hit_words, hit_words_bytes);
    }

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_hit_words);
    free_buf(ctx, d_params);
    free_buf(ctx, d_dummy);

    std::vector<size_t> row_indices;
    row_indices.reserve(std::min(dataset.row_count, kDbMaxCandidateRowsPerJob));
    for (size_t row_index = 0; row_index < dataset.row_count; ++row_index) {
        const uint32_t word = static_cast<uint32_t>(row_index >> 5);
        const uint32_t bit = 1u << (row_index & 31u);
        if ((hit_words[word] & bit) == 0u) {
            continue;
        }
        if (row_indices.size() >= kDbMaxCandidateRowsPerJob) {
            throw std::runtime_error("first-wave Vulkan DB lowering exceeded the 250000-candidate ceiling");
        }
        if (!db_row_matches_all_clauses(
                dataset.fields.data(),
                dataset.fields.size(),
                dataset.row_values.data(),
                row_index,
                clauses,
                clause_count)) {
            continue;
        }
        row_indices.push_back(row_index);
    }
    return row_indices;
}

// ---------- segment-pair intersection ---------------------------------------------------------------

static void run_segment_pair_intersection_vulkan(
        const RtdlSegment* left,  size_t left_count,
        const RtdlSegment* right, size_t right_count,
        RtdlSegmentPairIntersectionRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();

    std::call_once(g_segment_pair_intersection_init, [ctx]() {
        g_segment_pair_intersection_pipe = new RtPipeline(build_rt_pipeline(
            ctx, kSegmentPairIntersectionRgen, kSegmentPairIntersectionRmiss, kSegmentPairIntersectionRint, kSegmentPairIntersectionRahit,
            "segment_pair_intersection.rgen", "segment_pair_intersection.rmiss", "segment_pair_intersection.rint", "segment_pair_intersection.rahit", 6));
    });

    // Upload segments (double -> float)
    std::vector<GpuSegment> gpu_left(left_count), gpu_right(right_count);
    for (size_t i = 0; i < left_count;  ++i)
        gpu_left[i]  = {(float)left[i].x0,  (float)left[i].y0,
                         (float)left[i].x1,  (float)left[i].y1,  left[i].id};
    for (size_t i = 0; i < right_count; ++i)
        gpu_right[i] = {(float)right[i].x0, (float)right[i].y0,
                         (float)right[i].x1, (float)right[i].y1, right[i].id};

    VkDeviceSize left_sz  = sizeof(GpuSegment) * left_count;
    VkDeviceSize right_sz = sizeof(GpuSegment) * right_count;
    BufMem d_left  = alloc_buffer(ctx, left_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_right = alloc_buffer(ctx, right_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_left,  gpu_left.data(),  left_sz);
    upload_to_buf(ctx, d_right, gpu_right.data(), right_sz);

    // Build BLAS over right (build) segments
    std::vector<GpuAabb> aabbs(right_count);
    for (size_t i = 0; i < right_count; ++i)
        aabbs[i] = aabb_for_segment(gpu_right[i].x0, gpu_right[i].y0,
                                     gpu_right[i].x1, gpu_right[i].y1);
    AccelResult blas = build_aabb_blas(ctx, aabbs);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    // Output buffer + counter
    uint32_t capacity = checked_output_capacity_u32(
        left_count, right_count, sizeof(GpuSegmentPairIntersectionRecord), "Vulkan segment-pair intersection");
    VkDeviceSize output_sz = checked_output_bytes(capacity, sizeof(GpuSegmentPairIntersectionRecord), "Vulkan segment-pair intersection");
    BufMem d_output  = alloc_buffer(ctx, output_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_counter = alloc_buffer(ctx, sizeof(uint32_t),
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_counter);

    // Params UBO: nprobes, capacity
    struct { uint32_t nprobes, capacity; } params{ (uint32_t)left_count, capacity };
    BufMem d_params = alloc_buffer(ctx, sizeof(params),
        VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    // Descriptor set
    DescriptorSet ds = alloc_descriptor_set(ctx, g_segment_pair_intersection_pipe->dset_layout, 6, true);
    bind_tlas(ctx,       ds.set, tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_output.buffer, output_sz, 1);
    bind_ssbo(ctx->device, ds.set, d_counter.buffer, sizeof(uint32_t), 2);
    bind_ubo (ctx->device, ds.set, d_params.buffer,  sizeof(params), 3);
    bind_ssbo(ctx->device, ds.set, d_left.buffer,    left_sz,  4);
    bind_ssbo(ctx->device, ds.set, d_right.buffer,   right_sz, 5);

    dispatch_rt(ctx, *g_segment_pair_intersection_pipe, ds.set, (uint32_t)left_count);

    // Read back
    uint32_t gpu_count = 0;
    download_from_buf(ctx, &gpu_count, d_counter, sizeof(uint32_t));
    if (gpu_count > capacity) gpu_count = capacity;

    std::vector<GpuSegmentPairIntersectionRecord> gpu_rows(gpu_count);
    if (gpu_count > 0) {
        VkDeviceSize sub_sz = checked_output_bytes(gpu_count, sizeof(GpuSegmentPairIntersectionRecord), "Vulkan segment-pair intersection");
        BufMem d_sub = alloc_buffer(ctx, sub_sz,
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        // Copy just the valid rows
        VkCommandBuffer cmd;
        VkCommandBufferAllocateInfo ci{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
        ci.commandPool = ctx->cmd_pool; ci.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        ci.commandBufferCount = 1;
        vkAllocateCommandBuffers(ctx->device, &ci, &cmd);
        VkCommandBufferBeginInfo beg{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
        beg.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        vkBeginCommandBuffer(cmd, &beg);
        VkBufferCopy copy{ 0, 0, sub_sz };
        vkCmdCopyBuffer(cmd, d_output.buffer, d_sub.buffer, 1, &copy);
        vkEndCommandBuffer(cmd);
        VkSubmitInfo sub{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
        sub.commandBufferCount = 1; sub.pCommandBuffers = &cmd;
        vkQueueSubmit(ctx->queue, 1, &sub, VK_NULL_HANDLE);
        vkQueueWaitIdle(ctx->queue);
        vkFreeCommandBuffers(ctx->device, ctx->cmd_pool, 1, &cmd);
        download_from_buf(ctx, gpu_rows.data(), d_sub, sub_sz);
        free_buf(ctx, d_sub);
    }

    // Cleanup GPU objects before host refine.
    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_left); free_buf(ctx, d_right);
    free_buf(ctx, d_output); free_buf(ctx, d_counter); free_buf(ctx, d_params);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    (void)gpu_rows;
    std::vector<RtdlSegmentPairIntersectionRow> refined = exact_segment_pair_intersection_rows(left, left_count, right, right_count);

    auto* out = static_cast<RtdlSegmentPairIntersectionRow*>(std::malloc(sizeof(RtdlSegmentPairIntersectionRow) * refined.size()));
    if (!out && !refined.empty()) throw std::bad_alloc();
    for (size_t i = 0; i < refined.size(); ++i) {
        out[i] = refined[i];
    }
    *rows_out      = out;
    *row_count_out = refined.size();
}

// ---------- PIP ---------------------------------------------------------------

static void run_pip_vulkan(
        const RtdlPoint*     points,    size_t point_count,
        const RtdlPolygonRef* polys,    size_t poly_count,
        const double* vertices_xy,      size_t vertex_xy_count,
        uint32_t positive_only,
        RtdlPipRow** rows_out, size_t* row_count_out)
{
    if (positive_only != 0u) {
        // Two-stage sparse positive-hit path (Goal 78):
        //   Stage 1 - GPU generates sparse candidate (point_index, poly_index)
        //             pairs via ray tracing over polygon AABBs + exact GLSL PIP
        //             in the intersection shader.
        //   Stage 2 - host exact-finalizes only those candidates (GEOS or CPU
        //             fallback), preserving full parity with the oracle path.
        // The dense host full-scan (O(PxQ) on CPU) is replaced by GPU candidate
        // generation followed by host exact-finalize on the candidate subset.

        VkContext* ctx = get_context();
        std::call_once(g_pip_pos_count_init, [ctx]() {
            g_pip_pos_count_pipe = new RtPipeline(build_rt_pipeline(
                ctx, kPipRgen, kPipRmiss, kPipRint, kPipPosCountRahit,
                "pip_pos_count.rgen", "pip_pos_count.rmiss", "pip_pos_count.rint", "pip_pos_count.rahit", 7));
        });
        std::call_once(g_pip_pos_init, [ctx]() {
            // Reuse rgen/rmiss/rint from the dense PIP pipeline; only the
            // anyhit shader differs (sparse atomic candidate output).
            g_pip_pos_pipe = new RtPipeline(build_rt_pipeline(
                ctx, kPipRgen, kPipRmiss, kPipRint, kPipPosRahit,
                "pip_pos.rgen", "pip_pos.rmiss", "pip_pos.rint", "pip_pos.rahit", 7));
        });

        std::vector<GpuPoint> gpu_pts(point_count);
        for (size_t i = 0; i < point_count; ++i)
            gpu_pts[i] = {(float)points[i].x, (float)points[i].y, points[i].id};

        std::vector<GpuPolygonRef> gpu_polys(poly_count);
        for (size_t i = 0; i < poly_count; ++i)
            gpu_polys[i] = {polys[i].id, polys[i].vertex_offset, polys[i].vertex_count};

        std::vector<float> gpu_verts(vertex_xy_count);
        for (size_t i = 0; i < vertex_xy_count; ++i)
            gpu_verts[i] = (float)vertices_xy[i];

        VkDeviceSize pts_sz  = sizeof(GpuPoint)      * point_count;
        VkDeviceSize poly_sz = sizeof(GpuPolygonRef) * poly_count;
        VkDeviceSize vert_sz = sizeof(float)         * vertex_xy_count;

        BufMem d_pts  = alloc_buffer(ctx, pts_sz,
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        BufMem d_poly = alloc_buffer(ctx, poly_sz,
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        BufMem d_vert = alloc_buffer(ctx, vert_sz,
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        upload_to_buf(ctx, d_pts,  gpu_pts.data(),   pts_sz);
        upload_to_buf(ctx, d_poly, gpu_polys.data(), poly_sz);
        upload_to_buf(ctx, d_vert, gpu_verts.data(), vert_sz);

        // Build BLAS over polygon bounding boxes
        std::vector<GpuAabb> aabbs(poly_count);
        for (size_t i = 0; i < poly_count; ++i)
            aabbs[i] = aabb_for_polygon(gpu_verts.data(),
                                        polys[i].vertex_offset, polys[i].vertex_count);
        AccelResult blas = build_aabb_blas(ctx, aabbs);
        AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

        // Atomic counter buffer: first pass counts the true sparse candidate set.
        BufMem d_counter = alloc_buffer(ctx, sizeof(uint32_t),
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT |
            VK_BUFFER_USAGE_TRANSFER_DST_BIT   |
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        zero_buf(ctx, d_counter);

        struct { uint32_t npoints, capacity; } count_params{
            (uint32_t)point_count, 0u };
        BufMem d_count_params = alloc_buffer(ctx, sizeof(count_params),
            VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        void* mp; vkMapMemory(ctx->device, d_count_params.memory, 0, sizeof(count_params), 0, &mp);
        std::memcpy(mp, &count_params, sizeof(count_params)); vkUnmapMemory(ctx->device, d_count_params.memory);

        BufMem d_dummy = alloc_buffer(ctx, 4,
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

        DescriptorSet count_ds = alloc_descriptor_set(ctx, g_pip_pos_count_pipe->dset_layout, 7, true);
        bind_tlas(ctx,         count_ds.set, tlas.handle,          0);
        bind_ssbo(ctx->device, count_ds.set, d_dummy.buffer,       4,               1);
        bind_ssbo(ctx->device, count_ds.set, d_counter.buffer,     sizeof(uint32_t),2);
        bind_ubo (ctx->device, count_ds.set, d_count_params.buffer,sizeof(count_params),3);
        bind_ssbo(ctx->device, count_ds.set, d_pts.buffer,         pts_sz,          4);
        bind_ssbo(ctx->device, count_ds.set, d_poly.buffer,        poly_sz,         5);
        bind_ssbo(ctx->device, count_ds.set, d_vert.buffer,        vert_sz,         6);

        dispatch_rt(ctx, *g_pip_pos_count_pipe, count_ds.set, (uint32_t)point_count);

        uint32_t n_cands = 0;
        download_from_buf(ctx, &n_cands, d_counter, sizeof(uint32_t));
        vkDestroyDescriptorPool(ctx->device, count_ds.pool, nullptr);
        free_buf(ctx, d_count_params);

        std::vector<GpuPipCandidate> candidates(n_cands);
        if (n_cands > 0) {
            zero_buf(ctx, d_counter);

            VkDeviceSize cand_sz = checked_output_bytes(
                n_cands, sizeof(GpuPipCandidate), "Vulkan PIP positive-hit");
            BufMem d_cands = alloc_buffer(ctx, cand_sz,
                VK_BUFFER_USAGE_STORAGE_BUFFER_BIT |
                VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

            struct { uint32_t npoints, capacity; } params{
                (uint32_t)point_count, n_cands };
            BufMem d_params = alloc_buffer(ctx, sizeof(params),
                VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
                VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
            vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
            std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

            DescriptorSet ds = alloc_descriptor_set(ctx, g_pip_pos_pipe->dset_layout, 7, true);
            bind_tlas(ctx,         ds.set, tlas.handle,       0);
            bind_ssbo(ctx->device, ds.set, d_cands.buffer,    cand_sz,          1);
            bind_ssbo(ctx->device, ds.set, d_counter.buffer,  sizeof(uint32_t), 2);
            bind_ubo (ctx->device, ds.set, d_params.buffer,   sizeof(params),   3);
            bind_ssbo(ctx->device, ds.set, d_pts.buffer,      pts_sz,           4);
            bind_ssbo(ctx->device, ds.set, d_poly.buffer,     poly_sz,          5);
            bind_ssbo(ctx->device, ds.set, d_vert.buffer,     vert_sz,          6);

            dispatch_rt(ctx, *g_pip_pos_pipe, ds.set, (uint32_t)point_count);

            uint32_t n_written = 0;
            download_from_buf(ctx, &n_written, d_counter, sizeof(uint32_t));
            if (n_written < n_cands) {
                n_cands = n_written;
                candidates.resize(n_cands);
            }

            if (n_cands > 0) {
                download_from_buf(ctx, candidates.data(), d_cands,
                    checked_output_bytes(n_cands, sizeof(GpuPipCandidate), "Vulkan PIP positive-hit"));
            }

            vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
            free_buf(ctx, d_cands);
            free_buf(ctx, d_params);
        }

        free_buf(ctx, d_dummy);
        free_buf(ctx, d_pts); free_buf(ctx, d_poly); free_buf(ctx, d_vert);
        free_buf(ctx, d_counter);
        destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

        // Stage 2: host exact-finalize on candidates only
        std::vector<RtdlPipRow> rows;
        rows.reserve(n_cands);
#if RTDL_VULKAN_HAS_GEOS
        GeosPreparedPolygonRefs geos(polys, poly_count, vertices_xy);
        for (uint32_t ci = 0; ci < n_cands; ++ci) {
            size_t pi = candidates[ci].point_index;
            size_t qi = candidates[ci].poly_index;
            if (pi >= point_count || qi >= poly_count) continue;
            if (!geos.covers(qi, points[pi].x, points[pi].y)) continue;
            rows.push_back({points[pi].id, polys[qi].id, 1u});
        }
#else
        for (uint32_t ci = 0; ci < n_cands; ++ci) {
            size_t pi = candidates[ci].point_index;
            size_t qi = candidates[ci].poly_index;
            if (pi >= point_count || qi >= poly_count) continue;
            if (!exact_point_in_polygon(points[pi].x, points[pi].y, polys[qi], vertices_xy)) continue;
            rows.push_back({points[pi].id, polys[qi].id, 1u});
        }
#endif
        auto* out = static_cast<RtdlPipRow*>(std::malloc(sizeof(RtdlPipRow) * rows.size()));
        if (!out && !rows.empty()) throw std::bad_alloc();
        for (size_t i = 0; i < rows.size(); ++i) out[i] = rows[i];
        *rows_out      = out;
        *row_count_out = rows.size();
        return;
    }

    VkContext* ctx = get_context();
    std::call_once(g_pip_init, [ctx]() {
        g_pip_pipe = new RtPipeline(build_rt_pipeline(
            ctx, kPipRgen, kPipRmiss, kPipRint, kPipRahit,
            "pip.rgen", "pip.rmiss", "pip.rint", "pip.rahit", 7));
    });

    std::vector<GpuPoint> gpu_pts(point_count);
    for (size_t i = 0; i < point_count; ++i)
        gpu_pts[i] = {(float)points[i].x, (float)points[i].y, points[i].id};

    std::vector<GpuPolygonRef> gpu_polys(poly_count);
    for (size_t i = 0; i < poly_count; ++i)
        gpu_polys[i] = {polys[i].id, polys[i].vertex_offset, polys[i].vertex_count};

    std::vector<float> gpu_verts(vertex_xy_count);
    for (size_t i = 0; i < vertex_xy_count; ++i)
        gpu_verts[i] = (float)vertices_xy[i];

    VkDeviceSize pts_sz   = sizeof(GpuPoint)      * point_count;
    VkDeviceSize poly_sz  = sizeof(GpuPolygonRef) * poly_count;
    VkDeviceSize vert_sz  = sizeof(float)         * vertex_xy_count;

    BufMem d_pts  = alloc_buffer(ctx, pts_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_poly = alloc_buffer(ctx, poly_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_vert = alloc_buffer(ctx, vert_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_pts,  gpu_pts.data(),   pts_sz);
    upload_to_buf(ctx, d_poly, gpu_polys.data(), poly_sz);
    upload_to_buf(ctx, d_vert, gpu_verts.data(), vert_sz);

    // Build BLAS over polygon bounding boxes
    uint32_t n_verts = (uint32_t)(vertex_xy_count / 2);
    std::vector<GpuAabb> aabbs(poly_count);
    for (size_t i = 0; i < poly_count; ++i) {
        uint32_t off = polys[i].vertex_offset;
        uint32_t cnt = polys[i].vertex_count;
        aabbs[i] = aabb_for_polygon(gpu_verts.data(), off, cnt);
    }
    AccelResult blas = build_aabb_blas(ctx, aabbs);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    // Pre-allocate output: npoints x npoly GpuPipRecord, initialized to 0
    size_t out_count = checked_mul_size_t(point_count, poly_count, "Vulkan PIP");
    VkDeviceSize output_sz = checked_output_bytes(out_count, sizeof(GpuPipRecord), "Vulkan PIP");
    BufMem d_output = alloc_buffer(ctx, output_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_output);

    // Initialize output: fill point_id and polygon_id fields
    std::vector<GpuPipRecord> init_rows(out_count);
    for (size_t i = 0; i < point_count; ++i)
        for (size_t j = 0; j < poly_count; ++j)
            init_rows[i * poly_count + j] = { points[i].id, polys[j].id, 0u };
    upload_to_buf(ctx, d_output, init_rows.data(), output_sz);

    struct { uint32_t npoints, npolygons; } params{ (uint32_t)point_count, (uint32_t)poly_count };
    BufMem d_params = alloc_buffer(ctx, sizeof(params),
        VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_pip_pipe->dset_layout, 7, true);
    bind_tlas(ctx,       ds.set, tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_output.buffer, output_sz, 1);
    // binding 2 unused for PIP (no counter) - bind a dummy 4-byte buffer
    BufMem d_dummy = alloc_buffer(ctx, 4,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
    bind_ubo (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
    bind_ssbo(ctx->device, ds.set, d_pts.buffer,  pts_sz,  4);
    bind_ssbo(ctx->device, ds.set, d_poly.buffer, poly_sz, 5);
    bind_ssbo(ctx->device, ds.set, d_vert.buffer, vert_sz, 6);

    dispatch_rt(ctx, *g_pip_pipe, ds.set, (uint32_t)point_count);

    std::vector<GpuPipRecord> gpu_rows(out_count);
    download_from_buf(ctx, gpu_rows.data(), d_output, output_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_pts); free_buf(ctx, d_poly); free_buf(ctx, d_vert);
    free_buf(ctx, d_output); free_buf(ctx, d_params); free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    auto* out = static_cast<RtdlPipRow*>(std::malloc(sizeof(RtdlPipRow) * out_count));
    if (!out && out_count > 0) throw std::bad_alloc();
    for (size_t i = 0; i < out_count; ++i) {
        out[i] = { gpu_rows[i].point_id, gpu_rows[i].polygon_id, gpu_rows[i].contains };
    }

#if RTDL_VULKAN_HAS_GEOS
    GeosPreparedPolygonRefs geos(polys, poly_count, vertices_xy);
    for (size_t pi = 0; pi < point_count; ++pi) {
        for (size_t qi = 0; qi < poly_count; ++qi) {
            const size_t out_index = pi * poly_count + qi;
            out[out_index].point_id = points[pi].id;
            out[out_index].polygon_id = polys[qi].id;
            out[out_index].contains = geos.covers(qi, points[pi].x, points[pi].y) ? 1u : 0u;
        }
    }
#else
    std::unordered_map<uint32_t, const RtdlPoint*> point_by_id;
    std::unordered_map<uint32_t, const RtdlPolygonRef*> poly_by_id;
    point_by_id.reserve(point_count);
    poly_by_id.reserve(poly_count);
    for (size_t i = 0; i < point_count; ++i) {
        point_by_id.emplace(points[i].id, &points[i]);
    }
    for (size_t i = 0; i < poly_count; ++i) {
        poly_by_id.emplace(polys[i].id, &polys[i]);
    }
    for (size_t i = 0; i < out_count; ++i) {
        const auto point_it = point_by_id.find(out[i].point_id);
        const auto poly_it = poly_by_id.find(out[i].polygon_id);
        if (point_it == point_by_id.end() || poly_it == poly_by_id.end()) {
            out[i].contains = 0;
            continue;
        }
        out[i].contains = exact_point_in_polygon(
            point_it->second->x,
            point_it->second->y,
            *poly_it->second,
            vertices_xy)
            ? 1u
            : 0u;
    }
#endif
    *rows_out      = out;
    *row_count_out = out_count;
}

// ---------- shape-pair relation -----------------------------------------------------------

static void run_shape_pair_relation_flags_vulkan(
        const RtdlPolygonRef* left_polys,  size_t left_count,
        const double* left_verts_xy,       size_t left_vert_xy_count,
        const RtdlPolygonRef* right_polys, size_t right_count,
        const double* right_verts_xy,      size_t right_vert_xy_count,
        RtdlShapePairRelationRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    std::call_once(g_shape_pair_relation_init, [ctx]() {
        g_shape_pair_relation_pipe = new RtPipeline(build_rt_pipeline(
            ctx, kShapePairRelationRgen, kShapePairRelationRmiss, kShapePairRelationRint, kShapePairRelationRahit,
            "shape_pair_relation.rgen", "shape_pair_relation.rmiss", "shape_pair_relation.rint", "shape_pair_relation.rahit", 8));
    });

    std::vector<GpuPolygonRef> gpu_lpolys(left_count), gpu_rpolys(right_count);
    for (size_t i = 0; i < left_count;  ++i)
        gpu_lpolys[i] = {left_polys[i].id,  left_polys[i].vertex_offset,  left_polys[i].vertex_count};
    for (size_t i = 0; i < right_count; ++i)
        gpu_rpolys[i] = {right_polys[i].id, right_polys[i].vertex_offset, right_polys[i].vertex_count};

    std::vector<float> gpu_lv(left_vert_xy_count), gpu_rv(right_vert_xy_count);
    for (size_t i = 0; i < left_vert_xy_count;  ++i) gpu_lv[i] = (float)left_verts_xy[i];
    for (size_t i = 0; i < right_vert_xy_count; ++i) gpu_rv[i] = (float)right_verts_xy[i];

    VkDeviceSize lpoly_sz = sizeof(GpuPolygonRef) * left_count;
    VkDeviceSize rpoly_sz = sizeof(GpuPolygonRef) * right_count;
    VkDeviceSize lvert_sz = sizeof(float) * left_vert_xy_count;
    VkDeviceSize rvert_sz = sizeof(float) * right_vert_xy_count;

    BufMem d_lp = alloc_buffer(ctx, lpoly_sz, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_lv = alloc_buffer(ctx, lvert_sz, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_rp = alloc_buffer(ctx, rpoly_sz, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_rv = alloc_buffer(ctx, rvert_sz, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_lp, gpu_lpolys.data(), lpoly_sz);
    upload_to_buf(ctx, d_lv, gpu_lv.data(),     lvert_sz);
    upload_to_buf(ctx, d_rp, gpu_rpolys.data(), rpoly_sz);
    upload_to_buf(ctx, d_rv, gpu_rv.data(),     rvert_sz);

    // Build BLAS over right polygon bounding boxes
    std::vector<GpuAabb> aabbs(right_count);
    for (size_t i = 0; i < right_count; ++i) {
        uint32_t off = right_polys[i].vertex_offset;
        uint32_t cnt = right_polys[i].vertex_count;
        aabbs[i] = aabb_for_polygon(gpu_rv.data(), off, cnt);
    }
    AccelResult blas = build_aabb_blas(ctx, aabbs);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    // Pre-allocated output: left_count x right_count GpuShapePairRelationFlags, zeroed
    size_t out_count = checked_mul_size_t(left_count, right_count, "Vulkan shape-pair relation");
    VkDeviceSize output_sz = checked_output_bytes(out_count, sizeof(GpuShapePairRelationFlags), "Vulkan shape-pair relation");
    BufMem d_output = alloc_buffer(ctx, output_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_output);

    // max_edges per polygon
    uint32_t max_edges = 0;
    for (size_t i = 0; i < left_count; ++i)
        max_edges = std::max(max_edges, left_polys[i].vertex_count);
    uint32_t launch_count = (uint32_t)(left_count * max_edges);

    struct { uint32_t left_count, right_count, max_edges, launch_count; }
        params{ (uint32_t)left_count, (uint32_t)right_count, max_edges, launch_count };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_shape_pair_relation_pipe->dset_layout, 8, true);
    bind_tlas(ctx,       ds.set, tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_output.buffer, output_sz, 1);
    BufMem d_dummy = alloc_buffer(ctx, 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
    bind_ubo (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
    bind_ssbo(ctx->device, ds.set, d_lp.buffer, lpoly_sz, 4);
    bind_ssbo(ctx->device, ds.set, d_lv.buffer, lvert_sz, 5);
    bind_ssbo(ctx->device, ds.set, d_rp.buffer, rpoly_sz, 6);
    bind_ssbo(ctx->device, ds.set, d_rv.buffer, rvert_sz, 7);

    dispatch_rt(ctx, *g_shape_pair_relation_pipe, ds.set, launch_count);

    std::vector<GpuShapePairRelationFlags> gpu_flags(out_count);
    download_from_buf(ctx, gpu_flags.data(), d_output, output_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_lp); free_buf(ctx, d_lv);
    free_buf(ctx, d_rp); free_buf(ctx, d_rv);
    free_buf(ctx, d_output); free_buf(ctx, d_params); free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    std::vector<RtdlSegment> left_segments = polygon_edge_segments(left_polys, left_count, left_verts_xy);
    std::vector<RtdlSegment> right_segments = polygon_edge_segments(right_polys, right_count, right_verts_xy);
    std::vector<RtdlSegmentPairIntersectionRow> exact_shape_pair_hits = exact_segment_pair_intersection_rows(
        left_segments.data(),
        left_segments.size(),
        right_segments.data(),
        right_segments.size());
    std::unordered_set<uint64_t> exact_segment_intersection_pairs;
    exact_segment_intersection_pairs.reserve(exact_shape_pair_hits.size() * 2 + 1);
    for (const RtdlSegmentPairIntersectionRow& hit : exact_shape_pair_hits) {
        const uint64_t pair_key =
            (static_cast<uint64_t>(hit.left_id) << 32) |
            static_cast<uint64_t>(hit.right_id);
        exact_segment_intersection_pairs.insert(pair_key);
    }
    for (size_t li = 0; li < left_count; ++li) {
        for (size_t ri = 0; ri < right_count; ++ri) {
            const size_t slot = li * right_count + ri;
            const uint64_t pair_key =
                (static_cast<uint64_t>(left_polys[li].id) << 32) |
                static_cast<uint64_t>(right_polys[ri].id);
            gpu_flags[slot].requires_segment_intersection = exact_segment_intersection_pairs.count(pair_key) ? 1u : 0u;
        }
    }

    // CPU PIP supplement: match the oracle and accepted OptiX semantics.
#if RTDL_VULKAN_HAS_GEOS
    GeosPreparedPolygonRefs left_geos(left_polys, left_count, left_verts_xy);
    GeosPreparedPolygonRefs right_geos(right_polys, right_count, right_verts_xy);
#endif
    for (size_t li = 0; li < left_count; ++li) {
        for (size_t ri = 0; ri < right_count; ++ri) {
            const size_t slot = li * right_count + ri;
            if (gpu_flags[slot].requires_point_containment) continue;
            bool found = false;
            if (left_polys[li].vertex_count > 0) {
                const double lxv = left_verts_xy[left_polys[li].vertex_offset * 2];
                const double lyv = left_verts_xy[left_polys[li].vertex_offset * 2 + 1];
#if RTDL_VULKAN_HAS_GEOS
                if (right_geos.covers(ri, lxv, lyv))
#else
                if (exact_point_in_polygon(lxv, lyv, right_polys[ri], right_verts_xy))
#endif
                    found = true;
            }
            if (!found && right_polys[ri].vertex_count > 0) {
                const double rxv = right_verts_xy[right_polys[ri].vertex_offset * 2];
                const double ryv = right_verts_xy[right_polys[ri].vertex_offset * 2 + 1];
#if RTDL_VULKAN_HAS_GEOS
                if (left_geos.covers(li, rxv, ryv))
#else
                if (exact_point_in_polygon(rxv, ryv, left_polys[li], left_verts_xy))
#endif
                    found = true;
            }
            if (found) {
                gpu_flags[slot].requires_point_containment = 1;
            }
        }
    }

    auto* out = static_cast<RtdlShapePairRelationRow*>(std::malloc(sizeof(RtdlShapePairRelationRow) * out_count));
    if (!out && out_count > 0) throw std::bad_alloc();
    for (size_t i = 0; i < left_count; ++i)
        for (size_t j = 0; j < right_count; ++j) {
            size_t slot = i * right_count + j;
            out[slot] = { left_polys[i].id, right_polys[j].id,
                          gpu_flags[slot].requires_segment_intersection, gpu_flags[slot].requires_point_containment };
        }
    *rows_out      = out;
    *row_count_out = out_count;
}

// ---------- RayHitCount -------------------------------------------------------

static void run_ray_hitcount_vulkan(
        const RtdlRay2D*    rays,      size_t ray_count,
        const RtdlTriangle* triangles, size_t triangle_count,
        RtdlRayHitCountRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    std::call_once(g_rhc_init, [ctx]() {
        g_rhc_pipe = new RtPipeline(build_rt_pipeline(
            ctx, kRhcRgen, kRhcRmiss, kRhcRint, kRhcRahit,
            "rhc.rgen", "rhc.rmiss", "rhc.rint", "rhc.rahit", 6));
    });

    std::vector<GpuRay>      gpu_rays(ray_count);
    std::vector<GpuTriangle> gpu_tris(triangle_count);
    for (size_t i = 0; i < ray_count; ++i)
        gpu_rays[i] = {(float)rays[i].ox,(float)rays[i].oy,
                       (float)rays[i].dx,(float)rays[i].dy,
                       (float)rays[i].tmax, rays[i].id};
    for (size_t i = 0; i < triangle_count; ++i)
        gpu_tris[i] = {(float)triangles[i].x0,(float)triangles[i].y0,
                       (float)triangles[i].x1,(float)triangles[i].y1,
                       (float)triangles[i].x2,(float)triangles[i].y2,
                       triangles[i].id};

    VkDeviceSize ray_sz = sizeof(GpuRay)      * ray_count;
    VkDeviceSize tri_sz = sizeof(GpuTriangle) * triangle_count;
    BufMem d_rays = alloc_buffer(ctx, ray_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_tris = alloc_buffer(ctx, tri_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_rays, gpu_rays.data(), ray_sz);
    upload_to_buf(ctx, d_tris, gpu_tris.data(), tri_sz);

    // Build BLAS over triangle bounding boxes (custom AABB geometry)
    std::vector<GpuAabb> aabbs(triangle_count);
    for (size_t i = 0; i < triangle_count; ++i) {
        float xmin = std::min({gpu_tris[i].x0, gpu_tris[i].x1, gpu_tris[i].x2});
        float ymin = std::min({gpu_tris[i].y0, gpu_tris[i].y1, gpu_tris[i].y2});
        float xmax = std::max({gpu_tris[i].x0, gpu_tris[i].x1, gpu_tris[i].x2});
        float ymax = std::max({gpu_tris[i].y0, gpu_tris[i].y1, gpu_tris[i].y2});
        aabbs[i] = { xmin-kAabbEps, ymin-kAabbEps, -0.5f, xmax+kAabbEps, ymax+kAabbEps, 0.5f };
    }
    AccelResult blas = build_aabb_blas(ctx, aabbs);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    // Output: one GpuRayHitRecord per ray
    BufMem d_output = alloc_buffer(ctx, sizeof(GpuRayHitRecord) * ray_count,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_output);

    struct { uint32_t nrays, pad0; } params{ (uint32_t)ray_count, 0 };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_rhc_pipe->dset_layout, 6, true);
    bind_tlas(ctx,       ds.set, tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_output.buffer, sizeof(GpuRayHitRecord) * ray_count, 1);
    BufMem d_dummy = alloc_buffer(ctx, 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
    bind_ubo (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
    bind_ssbo(ctx->device, ds.set, d_rays.buffer, ray_sz, 4);
    bind_ssbo(ctx->device, ds.set, d_tris.buffer, tri_sz, 5);

    dispatch_rt(ctx, *g_rhc_pipe, ds.set, (uint32_t)ray_count);

    std::vector<GpuRayHitRecord> gpu_rows(ray_count);
    download_from_buf(ctx, gpu_rows.data(), d_output, sizeof(GpuRayHitRecord) * ray_count);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_rays); free_buf(ctx, d_tris);
    free_buf(ctx, d_output); free_buf(ctx, d_params); free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    auto* out = static_cast<RtdlRayHitCountRow*>(std::malloc(sizeof(RtdlRayHitCountRow) * ray_count));
    if (!out && ray_count > 0) throw std::bad_alloc();
    for (size_t i = 0; i < ray_count; ++i)
        out[i] = { gpu_rows[i].ray_id, gpu_rows[i].hit_count };
    *rows_out      = out;
    *row_count_out = ray_count;
}

static void run_ray_anyhit_vulkan(
        const RtdlRay2D*    rays,      size_t ray_count,
        const RtdlTriangle* triangles, size_t triangle_count,
        RtdlRayAnyHitRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    std::call_once(g_rah_init, [ctx]() {
        g_rah_pipe = new RtPipeline(build_rt_pipeline(
            ctx, kRahRgen, kRahRmiss, kRhcRint, kRahRahit,
            "rah.rgen", "rah.rmiss", "rah.rint", "rah.rahit", 6));
    });

    std::vector<GpuRay>      gpu_rays(ray_count);
    std::vector<GpuTriangle> gpu_tris(triangle_count);
    for (size_t i = 0; i < ray_count; ++i)
        gpu_rays[i] = {(float)rays[i].ox,(float)rays[i].oy,
                       (float)rays[i].dx,(float)rays[i].dy,
                       (float)rays[i].tmax, rays[i].id};
    for (size_t i = 0; i < triangle_count; ++i)
        gpu_tris[i] = {(float)triangles[i].x0,(float)triangles[i].y0,
                       (float)triangles[i].x1,(float)triangles[i].y1,
                       (float)triangles[i].x2,(float)triangles[i].y2,
                       triangles[i].id};

    VkDeviceSize ray_sz = sizeof(GpuRay)      * ray_count;
    VkDeviceSize tri_sz = sizeof(GpuTriangle) * triangle_count;
    BufMem d_rays = alloc_buffer(ctx, ray_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_tris = alloc_buffer(ctx, tri_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_rays, gpu_rays.data(), ray_sz);
    upload_to_buf(ctx, d_tris, gpu_tris.data(), tri_sz);

    std::vector<GpuAabb> aabbs(triangle_count);
    for (size_t i = 0; i < triangle_count; ++i) {
        float xmin = std::min({gpu_tris[i].x0, gpu_tris[i].x1, gpu_tris[i].x2});
        float ymin = std::min({gpu_tris[i].y0, gpu_tris[i].y1, gpu_tris[i].y2});
        float xmax = std::max({gpu_tris[i].x0, gpu_tris[i].x1, gpu_tris[i].x2});
        float ymax = std::max({gpu_tris[i].y0, gpu_tris[i].y1, gpu_tris[i].y2});
        aabbs[i] = { xmin-kAabbEps, ymin-kAabbEps, -0.5f, xmax+kAabbEps, ymax+kAabbEps, 0.5f };
    }
    AccelResult blas = build_aabb_blas(ctx, aabbs);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    BufMem d_output = alloc_buffer(ctx, sizeof(GpuRayHitRecord) * ray_count,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_output);

    struct { uint32_t nrays, pad0; } params{ (uint32_t)ray_count, 0 };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_rah_pipe->dset_layout, 6, true);
    bind_tlas(ctx,       ds.set, tlas.handle, 0);
    bind_ssbo(ctx->device, ds.set, d_output.buffer, sizeof(GpuRayHitRecord) * ray_count, 1);
    BufMem d_dummy = alloc_buffer(ctx, 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
    bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
    bind_ubo (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
    bind_ssbo(ctx->device, ds.set, d_rays.buffer, ray_sz, 4);
    bind_ssbo(ctx->device, ds.set, d_tris.buffer, tri_sz, 5);

    dispatch_rt(ctx, *g_rah_pipe, ds.set, (uint32_t)ray_count);

    std::vector<GpuRayHitRecord> gpu_rows(ray_count);
    download_from_buf(ctx, gpu_rows.data(), d_output, sizeof(GpuRayHitRecord) * ray_count);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_rays); free_buf(ctx, d_tris);
    free_buf(ctx, d_output); free_buf(ctx, d_params); free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    auto* out = static_cast<RtdlRayAnyHitRow*>(std::malloc(sizeof(RtdlRayAnyHitRow) * ray_count));
    if (!out && ray_count > 0) throw std::bad_alloc();
    for (size_t i = 0; i < ray_count; ++i)
        out[i] = { gpu_rows[i].ray_id, gpu_rows[i].hit_count ? 1u : 0u };
    *rows_out      = out;
    *row_count_out = ray_count;
}

static VulkanPreparedRayAnyhit2D* prepare_ray_anyhit_2d_vulkan(
        const RtdlTriangle* triangles, size_t triangle_count)
{
    if (triangle_count > static_cast<size_t>(std::numeric_limits<uint32_t>::max())) {
        throw std::runtime_error("Vulkan prepared 2D ray_triangle_any_hit supports at most 2^32-1 triangles");
    }
    if (triangle_count > 0 && triangles == nullptr) {
        throw std::runtime_error("triangle pointer must not be null when triangle_count > 0");
    }

    auto prepared = std::make_unique<VulkanPreparedRayAnyhit2D>();
    prepared->ctx = get_context();
    std::call_once(g_rah_init, [ctx = prepared->ctx]() {
        g_rah_pipe = new RtPipeline(build_rt_pipeline(
            ctx, kRahRgen, kRahRmiss, kRhcRint, kRahRahit,
            "rah.rgen", "rah.rmiss", "rah.rint", "rah.rahit", 6));
    });
    if (triangle_count == 0) {
        prepared->empty_scene = true;
        return prepared.release();
    }

    std::vector<GpuTriangle> gpu_tris(triangle_count);
    for (size_t i = 0; i < triangle_count; ++i) {
        gpu_tris[i] = {
            (float)triangles[i].x0, (float)triangles[i].y0,
            (float)triangles[i].x1, (float)triangles[i].y1,
            (float)triangles[i].x2, (float)triangles[i].y2,
            triangles[i].id,
        };
    }
    const VkDeviceSize tri_sz = sizeof(GpuTriangle) * triangle_count;
    prepared->d_tris = alloc_buffer(prepared->ctx, tri_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(prepared->ctx, prepared->d_tris, gpu_tris.data(), tri_sz);

    std::vector<GpuAabb> aabbs(triangle_count);
    for (size_t i = 0; i < triangle_count; ++i) {
        float xmin = std::min({gpu_tris[i].x0, gpu_tris[i].x1, gpu_tris[i].x2});
        float ymin = std::min({gpu_tris[i].y0, gpu_tris[i].y1, gpu_tris[i].y2});
        float xmax = std::max({gpu_tris[i].x0, gpu_tris[i].x1, gpu_tris[i].x2});
        float ymax = std::max({gpu_tris[i].y0, gpu_tris[i].y1, gpu_tris[i].y2});
        aabbs[i] = { xmin-kAabbEps, ymin-kAabbEps, -0.5f, xmax+kAabbEps, ymax+kAabbEps, 0.5f };
    }
    prepared->blas = build_aabb_blas(prepared->ctx, aabbs);
    prepared->tlas = build_tlas(prepared->ctx, prepared->blas.handle, prepared->blas.device_addr);
    return prepared.release();
}

static void run_prepared_ray_anyhit_2d_vulkan(
        VulkanPreparedRayAnyhit2D* prepared,
        const RtdlRay2D* rays, size_t ray_count,
        RtdlRayAnyHitRow** rows_out, size_t* row_count_out)
{
    if (prepared == nullptr) {
        throw std::runtime_error("prepared Vulkan 2D ray_triangle_any_hit handle must not be null");
    }
    if (ray_count > static_cast<size_t>(std::numeric_limits<uint32_t>::max())) {
        throw std::runtime_error("Vulkan prepared 2D ray_triangle_any_hit supports at most 2^32-1 rays");
    }
    if (ray_count > 0 && rays == nullptr) {
        throw std::runtime_error("ray pointer must not be null when ray_count > 0");
    }
    if (ray_count == 0) {
        *rows_out = nullptr;
        *row_count_out = 0;
        return;
    }
    if (prepared->empty_scene) {
        auto* out = static_cast<RtdlRayAnyHitRow*>(std::malloc(sizeof(RtdlRayAnyHitRow) * ray_count));
        if (!out) throw std::bad_alloc();
        for (size_t i = 0; i < ray_count; ++i) {
            out[i] = { rays[i].id, 0u };
        }
        *rows_out = out;
        *row_count_out = ray_count;
        return;
    }

    VkContext* ctx = prepared->ctx;
    std::vector<GpuRay> gpu_rays(ray_count);
    for (size_t i = 0; i < ray_count; ++i) {
        gpu_rays[i] = {
            (float)rays[i].ox, (float)rays[i].oy,
            (float)rays[i].dx, (float)rays[i].dy,
            (float)rays[i].tmax,
            rays[i].id,
        };
    }
    const VkDeviceSize ray_sz = sizeof(GpuRay) * ray_count;
    BufMem d_rays = alloc_buffer(ctx, ray_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_output = alloc_buffer(ctx, sizeof(GpuRayHitRecord) * ray_count,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_params{};
    BufMem d_dummy{};
    DescriptorSet ds{};
    try {
        upload_to_buf(ctx, d_rays, gpu_rays.data(), ray_sz);
        zero_buf(ctx, d_output);

        struct { uint32_t nrays, pad0; } params{ (uint32_t)ray_count, 0 };
        d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        void* mp;
        VK_CHECK(vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp));
        std::memcpy(mp, &params, sizeof(params));
        vkUnmapMemory(ctx->device, d_params.memory);

        d_dummy = alloc_buffer(ctx, 4, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);
        ds = alloc_descriptor_set(ctx, g_rah_pipe->dset_layout, 6, true);
        bind_tlas(ctx, ds.set, prepared->tlas.handle, 0);
        bind_ssbo(ctx->device, ds.set, d_output.buffer, sizeof(GpuRayHitRecord) * ray_count, 1);
        bind_ssbo(ctx->device, ds.set, d_dummy.buffer, 4, 2);
        bind_ubo(ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
        bind_ssbo(ctx->device, ds.set, d_rays.buffer, ray_sz, 4);
        bind_ssbo(ctx->device, ds.set, prepared->d_tris.buffer, prepared->d_tris.size, 5);

        dispatch_rt(ctx, *g_rah_pipe, ds.set, (uint32_t)ray_count);

        std::vector<GpuRayHitRecord> gpu_rows(ray_count);
        download_from_buf(ctx, gpu_rows.data(), d_output, sizeof(GpuRayHitRecord) * ray_count);

        auto* out = static_cast<RtdlRayAnyHitRow*>(std::malloc(sizeof(RtdlRayAnyHitRow) * ray_count));
        if (!out) throw std::bad_alloc();
        for (size_t i = 0; i < ray_count; ++i) {
            out[i] = { gpu_rows[i].ray_id, gpu_rows[i].hit_count ? 1u : 0u };
        }
        *rows_out = out;
        *row_count_out = ray_count;
    } catch (...) {
        if (ds.pool != VK_NULL_HANDLE) {
            vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
        }
        free_buf(ctx, d_rays);
        free_buf(ctx, d_output);
        free_buf(ctx, d_params);
        free_buf(ctx, d_dummy);
        throw;
    }
    if (ds.pool != VK_NULL_HANDLE) {
        vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    }
    free_buf(ctx, d_rays);
    free_buf(ctx, d_output);
    free_buf(ctx, d_params);
    free_buf(ctx, d_dummy);
}

// ---------- SegmentPolygonHitcount -------------------------------------------

static void run_segment_polygon_hitcount_vulkan(
        const RtdlSegment*    segments,  size_t segment_count,
        const RtdlPolygonRef* polygons,  size_t polygon_count,
        const double* vertices_xy,       size_t vertex_xy_count,
        RtdlSegmentPolygonHitCountRow** rows_out, size_t* row_count_out)
{
    auto* out = static_cast<RtdlSegmentPolygonHitCountRow*>(
        std::malloc(sizeof(RtdlSegmentPolygonHitCountRow) * segment_count));
    if (!out && segment_count > 0) throw std::bad_alloc();
    std::vector<Bounds2D> polygon_bounds;
    polygon_bounds.reserve(polygon_count);
    for (size_t j = 0; j < polygon_count; ++j) {
        polygon_bounds.push_back(bounds_for_polygon(polygons[j], vertices_xy));
    }
    const PolygonBucketIndex bucket_index = build_polygon_bucket_index(polygon_bounds);
    std::vector<size_t> seen(polygon_count, 0);
    size_t stamp = 1;
    for (size_t i = 0; i < segment_count; ++i) {
        const Bounds2D seg_bounds = bounds_for_segment(segments[i]);
        const size_t bucket_count = bucket_index.buckets.size();
        size_t first = 0;
        size_t last = 0;
        if (bucket_count > 0) {
            first = static_cast<size_t>(std::clamp(
                static_cast<long long>(std::floor((seg_bounds.min_x - bucket_index.origin_x) / bucket_index.bucket_width)),
                0LL,
                static_cast<long long>(bucket_count - 1)));
            last = static_cast<size_t>(std::clamp(
                static_cast<long long>(std::floor((seg_bounds.max_x - bucket_index.origin_x) / bucket_index.bucket_width)),
                0LL,
                static_cast<long long>(bucket_count - 1)));
        }
        uint32_t hit_count = 0;
        for (size_t bucket_id = first; bucket_id <= last && bucket_count > 0; ++bucket_id) {
            for (size_t polygon_index : bucket_index.buckets[bucket_id]) {
                if (seen[polygon_index] == stamp) {
                    continue;
                }
                seen[polygon_index] = stamp;
                if (!bounds_overlap(seg_bounds, polygon_bounds[polygon_index])) {
                    continue;
                }
                if (exact_segment_hits_polygon(segments[i], polygons[polygon_index], vertices_xy)) {
                    hit_count += 1;
                }
            }
        }
        out[i] = { segments[i].id, hit_count };
        stamp += 1;
        if (stamp == 0) {
            std::fill(seen.begin(), seen.end(), 0);
            stamp = 1;
        }
    }
    *rows_out      = out;
    *row_count_out = segment_count;
}

static void run_segment_polygon_anyhit_rows_vulkan(
        const RtdlSegment* segments, size_t segment_count,
        const RtdlPolygonRef* polygons, size_t polygon_count,
        const double* vertices_xy, size_t vertex_xy_count,
        RtdlSegmentPolygonAnyHitRow** rows_out, size_t* row_count_out)
{
    (void)vertex_xy_count;
    std::vector<RtdlSegmentPolygonAnyHitRow> out_rows;
    std::vector<Bounds2D> polygon_bounds;
    polygon_bounds.reserve(polygon_count);
    for (size_t j = 0; j < polygon_count; ++j) {
        polygon_bounds.push_back(bounds_for_polygon(polygons[j], vertices_xy));
    }
    const PolygonBucketIndex bucket_index = build_polygon_bucket_index(polygon_bounds);
    std::vector<size_t> seen(polygon_count, 0);
    size_t stamp = 1;
    for (size_t i = 0; i < segment_count; ++i) {
        const Bounds2D seg_bounds = bounds_for_segment(segments[i]);
        const size_t bucket_count = bucket_index.buckets.size();
        size_t first = 0;
        size_t last = 0;
        if (bucket_count > 0) {
            first = static_cast<size_t>(std::clamp(
                static_cast<long long>(std::floor((seg_bounds.min_x - bucket_index.origin_x) / bucket_index.bucket_width)),
                0LL,
                static_cast<long long>(bucket_count - 1)));
            last = static_cast<size_t>(std::clamp(
                static_cast<long long>(std::floor((seg_bounds.max_x - bucket_index.origin_x) / bucket_index.bucket_width)),
                0LL,
                static_cast<long long>(bucket_count - 1)));
        }
        for (size_t bucket_id = first; bucket_id <= last && bucket_count > 0; ++bucket_id) {
            for (size_t polygon_index : bucket_index.buckets[bucket_id]) {
                if (seen[polygon_index] == stamp) {
                    continue;
                }
                seen[polygon_index] = stamp;
                if (!bounds_overlap(seg_bounds, polygon_bounds[polygon_index])) {
                    continue;
                }
                if (exact_segment_hits_polygon(segments[i], polygons[polygon_index], vertices_xy)) {
                    out_rows.push_back({segments[i].id, polygons[polygon_index].id});
                }
            }
        }
        stamp += 1;
        if (stamp == 0) {
            std::fill(seen.begin(), seen.end(), 0);
            stamp = 1;
        }
    }
    auto* out = static_cast<RtdlSegmentPolygonAnyHitRow*>(
        std::malloc(sizeof(RtdlSegmentPolygonAnyHitRow) * out_rows.size()));
    if (!out && !out_rows.empty()) throw std::bad_alloc();
    if (!out_rows.empty()) {
        std::memcpy(out, out_rows.data(), sizeof(RtdlSegmentPolygonAnyHitRow) * out_rows.size());
    }
    *rows_out = out;
    *row_count_out = out_rows.size();
}

static void run_db_conjunctive_scan_vulkan(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const RtdlDbClause* clauses,
        size_t clause_count,
        RtdlDbRowIdRow** rows_out,
        size_t* row_count_out)
{
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    *rows_out = nullptr;
    *row_count_out = 0;
    if (!fields || field_count == 0 || !row_values) {
        throw std::runtime_error("dataset inputs must not be null");
    }
    if (clause_count > 0 && !clauses) {
        throw std::runtime_error("DB clause pointer must not be null when clause_count > 0");
    }
    if (row_count > kDbMaxRowsPerJob) {
        throw std::runtime_error("first-wave Vulkan DB lowering supports at most 1000000 rows per RT job");
    }
    const std::vector<DbRowMeta> row_metas = db_build_row_metas(fields, field_count, row_values, row_count);
    const std::vector<size_t> candidate_row_indices =
        db_collect_candidate_row_indices_vulkan(fields, field_count, row_values, row_count, clauses, clause_count);
    std::vector<RtdlDbRowIdRow> rows;
    rows.reserve(candidate_row_indices.size());
    for (size_t row_index : candidate_row_indices) {
        rows.push_back({row_metas[row_index].row_id});
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlDbRowIdRow& left, const RtdlDbRowIdRow& right) {
        return left.row_id < right.row_id;
    });
    auto* out = static_cast<RtdlDbRowIdRow*>(std::malloc(sizeof(RtdlDbRowIdRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlDbRowIdRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_db_grouped_count_vulkan(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const RtdlDbClause* clauses,
        size_t clause_count,
        const char* group_key_field,
        RtdlDbGroupedCountRow** rows_out,
        size_t* row_count_out)
{
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    *rows_out = nullptr;
    *row_count_out = 0;
    if (!fields || field_count == 0 || !row_values || !group_key_field) {
        throw std::runtime_error("DB grouped_count inputs must not be null");
    }
    if (row_count > kDbMaxRowsPerJob) {
        throw std::runtime_error("first-wave Vulkan DB lowering supports at most 1000000 rows per RT job");
    }
    const size_t group_field_index = db_find_field_index_or_throw(fields, field_count, group_key_field);
    const std::vector<size_t> candidate_row_indices =
        db_collect_candidate_row_indices_vulkan(fields, field_count, row_values, row_count, clauses, clause_count);
    std::unordered_map<int64_t, int64_t> counts;
    for (size_t row_index : candidate_row_indices) {
        const RtdlDbScalar& group_value = db_row_value(row_values, row_index, field_count, group_field_index);
        counts[group_value.int_value] += 1;
        if (counts.size() > kDbMaxGroupsPerJob) {
            throw std::runtime_error("first-wave Vulkan DB grouped kernels exceeded the 65536-group ceiling");
        }
    }
    std::vector<RtdlDbGroupedCountRow> rows;
    rows.reserve(counts.size());
    for (const auto& entry : counts) {
        rows.push_back({entry.first, entry.second});
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlDbGroupedCountRow& left, const RtdlDbGroupedCountRow& right) {
        return left.group_key < right.group_key;
    });
    auto* out = static_cast<RtdlDbGroupedCountRow*>(std::malloc(sizeof(RtdlDbGroupedCountRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlDbGroupedCountRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_db_grouped_sum_vulkan(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const RtdlDbClause* clauses,
        size_t clause_count,
        const char* group_key_field,
        const char* value_field,
        RtdlDbGroupedSumRow** rows_out,
        size_t* row_count_out)
{
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    *rows_out = nullptr;
    *row_count_out = 0;
    if (!fields || field_count == 0 || !row_values || !group_key_field || !value_field) {
        throw std::runtime_error("DB grouped_sum inputs must not be null");
    }
    if (row_count > kDbMaxRowsPerJob) {
        throw std::runtime_error("first-wave Vulkan DB lowering supports at most 1000000 rows per RT job");
    }
    const size_t group_field_index = db_find_field_index_or_throw(fields, field_count, group_key_field);
    const size_t value_field_index = db_find_field_index_or_throw(fields, field_count, value_field);
    if (fields[value_field_index].kind != kDbKindInt64 && fields[value_field_index].kind != kDbKindBool) {
        throw std::runtime_error("first-wave Vulkan grouped_sum supports integer-compatible value fields only");
    }
    const std::vector<size_t> candidate_row_indices =
        db_collect_candidate_row_indices_vulkan(fields, field_count, row_values, row_count, clauses, clause_count);
    std::unordered_map<int64_t, int64_t> sums;
    for (size_t row_index : candidate_row_indices) {
        const RtdlDbScalar& group_value = db_row_value(row_values, row_index, field_count, group_field_index);
        const RtdlDbScalar& sum_value = db_row_value(row_values, row_index, field_count, value_field_index);
        sums[group_value.int_value] += sum_value.int_value;
        if (sums.size() > kDbMaxGroupsPerJob) {
            throw std::runtime_error("first-wave Vulkan DB grouped kernels exceeded the 65536-group ceiling");
        }
    }
    std::vector<RtdlDbGroupedSumRow> rows;
    rows.reserve(sums.size());
    for (const auto& entry : sums) {
        rows.push_back({entry.first, entry.second});
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlDbGroupedSumRow& left, const RtdlDbGroupedSumRow& right) {
        return left.group_key < right.group_key;
    });
    auto* out = static_cast<RtdlDbGroupedSumRow*>(std::malloc(sizeof(RtdlDbGroupedSumRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlDbGroupedSumRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static VulkanDbDatasetImpl* create_db_dataset_vulkan(
        const RtdlDbField* fields,
        size_t field_count,
        const RtdlDbScalar* row_values,
        size_t row_count,
        const char* const* primary_fields,
        size_t primary_field_count)
{
    db_validate_db_inputs(fields, field_count, row_values, row_count, nullptr, 0);
    VkContext* ctx = get_context();
    std::unique_ptr<VulkanDbDatasetImpl> dataset(new VulkanDbDatasetImpl());
    db_copy_dataset_payload(*dataset, fields, field_count, row_values, row_count);

    std::vector<const char*> primary_names;
    if (primary_field_count > 0) {
        if (!primary_fields) {
            throw std::runtime_error("primary_fields pointer must not be null when primary_field_count > 0");
        }
        primary_names.reserve(std::min<size_t>(primary_field_count, 3));
        for (size_t index = 0; index < primary_field_count && index < 3; ++index) {
            primary_names.push_back(primary_fields[index]);
        }
    } else {
        primary_names = db_default_primary_fields(dataset->fields.data(), dataset->fields.size());
    }
    if (primary_names.empty()) {
        throw std::runtime_error("Vulkan prepared DB dataset requires at least one numeric primary RT axis");
    }

    dataset->primary_axes.reserve(primary_names.size());
    for (const char* field_name : primary_names) {
        dataset->primary_axes.push_back(
            db_make_full_primary_axis(
                dataset->fields.data(),
                dataset->fields.size(),
                dataset->row_values.data(),
                dataset->row_count,
                field_name));
    }
    dataset->row_metas = db_build_row_metas(
        dataset->fields.data(),
        dataset->fields.size(),
        dataset->row_values.data(),
        dataset->row_count);
    dataset->aabbs = db_build_row_aabbs(
        dataset->fields.data(),
        dataset->fields.size(),
        dataset->row_values.data(),
        dataset->row_count,
        dataset->primary_axes);
    dataset->blas = build_aabb_blas(ctx, dataset->aabbs);
    dataset->tlas = build_tlas(ctx, dataset->blas.handle, dataset->blas.device_addr);
    return dataset.release();
}

static VulkanDbDatasetImpl* create_db_dataset_vulkan_columnar(
        const RtdlPayloadField* fields,
        size_t field_count,
        size_t row_count,
        const char* const* primary_fields,
        size_t primary_field_count)
{
    db_validate_columnar_inputs(columns, field_count, row_count);
    VkContext* ctx = get_context();
    std::unique_ptr<VulkanDbDatasetImpl> dataset(new VulkanDbDatasetImpl());
    db_copy_dataset_columnar_payload(*dataset, columns, field_count, row_count);

    std::vector<const char*> primary_names;
    if (primary_field_count > 0) {
        if (!primary_fields) {
            throw std::runtime_error("primary_fields pointer must not be null when primary_field_count > 0");
        }
        primary_names.reserve(std::min<size_t>(primary_field_count, 3));
        for (size_t index = 0; index < primary_field_count && index < 3; ++index) {
            primary_names.push_back(primary_fields[index]);
        }
    } else {
        primary_names = db_default_primary_fields(dataset->fields.data(), dataset->fields.size());
    }
    if (primary_names.empty()) {
        throw std::runtime_error("Vulkan prepared DB dataset requires at least one numeric primary RT axis");
    }

    dataset->primary_axes.reserve(primary_names.size());
    for (const char* field_name : primary_names) {
        dataset->primary_axes.push_back(
            db_make_full_primary_axis(
                dataset->fields.data(),
                dataset->fields.size(),
                dataset->row_values.data(),
                dataset->row_count,
                field_name));
    }
    dataset->row_metas = db_build_row_metas(
        dataset->fields.data(),
        dataset->fields.size(),
        dataset->row_values.data(),
        dataset->row_count);
    dataset->aabbs = db_build_row_aabbs(
        dataset->fields.data(),
        dataset->fields.size(),
        dataset->row_values.data(),
        dataset->row_count,
        dataset->primary_axes);
    dataset->blas = build_aabb_blas(ctx, dataset->aabbs);
    dataset->tlas = build_tlas(ctx, dataset->blas.handle, dataset->blas.device_addr);
    return dataset.release();
}

static void destroy_db_dataset_vulkan(VulkanDbDatasetImpl* dataset)
{
    if (!dataset) {
        return;
    }
    VkContext* ctx = get_context();
    destroy_accel(ctx, dataset->tlas);
    destroy_accel(ctx, dataset->blas);
    delete dataset;
}

static void run_db_conjunctive_scan_vulkan_prepared(
        VulkanDbDatasetImpl* dataset,
        const RtdlDbClause* clauses,
        size_t clause_count,
        RtdlDbRowIdRow** rows_out,
        size_t* row_count_out)
{
    if (!dataset) {
        throw std::runtime_error("Vulkan prepared DB dataset must not be null");
    }
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    if (clause_count > 0 && !clauses) {
        throw std::runtime_error("DB clause pointer must not be null when clause_count > 0");
    }
    *rows_out = nullptr;
    *row_count_out = 0;

    const std::vector<size_t> candidate_row_indices =
        db_collect_candidate_row_indices_vulkan_prepared(*dataset, clauses, clause_count);
    std::vector<RtdlDbRowIdRow> rows;
    rows.reserve(candidate_row_indices.size());
    for (size_t row_index : candidate_row_indices) {
        rows.push_back({dataset->row_metas[row_index].row_id});
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlDbRowIdRow& left, const RtdlDbRowIdRow& right) {
        return left.row_id < right.row_id;
    });
    auto* out = static_cast<RtdlDbRowIdRow*>(std::malloc(sizeof(RtdlDbRowIdRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlDbRowIdRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_db_grouped_count_vulkan_prepared(
        VulkanDbDatasetImpl* dataset,
        const RtdlDbClause* clauses,
        size_t clause_count,
        const char* group_key_field,
        RtdlDbGroupedCountRow** rows_out,
        size_t* row_count_out)
{
    if (!dataset) {
        throw std::runtime_error("Vulkan prepared DB dataset must not be null");
    }
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    if (!group_key_field) {
        throw std::runtime_error("group_key_field must not be null");
    }
    if (clause_count > 0 && !clauses) {
        throw std::runtime_error("DB clause pointer must not be null when clause_count > 0");
    }
    *rows_out = nullptr;
    *row_count_out = 0;

    const size_t group_field_index =
        db_find_field_index_or_throw(dataset->fields.data(), dataset->fields.size(), group_key_field);
    const std::vector<size_t> candidate_row_indices =
        db_collect_candidate_row_indices_vulkan_prepared(*dataset, clauses, clause_count);
    std::unordered_map<int64_t, int64_t> counts;
    for (size_t row_index : candidate_row_indices) {
        const RtdlDbScalar& group_value =
            db_row_value(dataset->row_values.data(), row_index, dataset->fields.size(), group_field_index);
        counts[group_value.int_value] += 1;
        if (counts.size() > kDbMaxGroupsPerJob) {
            throw std::runtime_error("first-wave Vulkan DB grouped kernels exceeded the 65536-group ceiling");
        }
    }
    std::vector<RtdlDbGroupedCountRow> rows;
    rows.reserve(counts.size());
    for (const auto& entry : counts) {
        rows.push_back({entry.first, entry.second});
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlDbGroupedCountRow& left, const RtdlDbGroupedCountRow& right) {
        return left.group_key < right.group_key;
    });
    auto* out = static_cast<RtdlDbGroupedCountRow*>(std::malloc(sizeof(RtdlDbGroupedCountRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlDbGroupedCountRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_db_grouped_sum_vulkan_prepared(
        VulkanDbDatasetImpl* dataset,
        const RtdlDbClause* clauses,
        size_t clause_count,
        const char* group_key_field,
        const char* value_field,
        RtdlDbGroupedSumRow** rows_out,
        size_t* row_count_out)
{
    if (!dataset) {
        throw std::runtime_error("Vulkan prepared DB dataset must not be null");
    }
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    if (!group_key_field || !value_field) {
        throw std::runtime_error("group_key_field and value_field must not be null");
    }
    if (clause_count > 0 && !clauses) {
        throw std::runtime_error("DB clause pointer must not be null when clause_count > 0");
    }
    *rows_out = nullptr;
    *row_count_out = 0;

    const size_t group_field_index =
        db_find_field_index_or_throw(dataset->fields.data(), dataset->fields.size(), group_key_field);
    const size_t value_field_index =
        db_find_field_index_or_throw(dataset->fields.data(), dataset->fields.size(), value_field);
    if (dataset->fields[value_field_index].kind != kDbKindInt64 && dataset->fields[value_field_index].kind != kDbKindBool) {
        throw std::runtime_error("first-wave Vulkan grouped_sum supports integer-compatible value fields only");
    }
    const std::vector<size_t> candidate_row_indices =
        db_collect_candidate_row_indices_vulkan_prepared(*dataset, clauses, clause_count);
    std::unordered_map<int64_t, int64_t> sums;
    for (size_t row_index : candidate_row_indices) {
        const RtdlDbScalar& group_value =
            db_row_value(dataset->row_values.data(), row_index, dataset->fields.size(), group_field_index);
        const RtdlDbScalar& sum_value =
            db_row_value(dataset->row_values.data(), row_index, dataset->fields.size(), value_field_index);
        sums[group_value.int_value] += sum_value.int_value;
        if (sums.size() > kDbMaxGroupsPerJob) {
            throw std::runtime_error("first-wave Vulkan DB grouped kernels exceeded the 65536-group ceiling");
        }
    }
    std::vector<RtdlDbGroupedSumRow> rows;
    rows.reserve(sums.size());
    for (const auto& entry : sums) {
        rows.push_back({entry.first, entry.second});
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlDbGroupedSumRow& left, const RtdlDbGroupedSumRow& right) {
        return left.group_key < right.group_key;
    });
    auto* out = static_cast<RtdlDbGroupedSumRow*>(std::malloc(sizeof(RtdlDbGroupedSumRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlDbGroupedSumRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_bfs_expand_vulkan_host_indexed(
        const uint32_t* row_offsets, size_t row_offset_count,
        const uint32_t* column_indices, size_t edge_index_count,
        const RtdlFrontierVertex* frontier, size_t frontier_count,
        const uint32_t* visited_vertices, size_t visited_count,
        uint32_t dedupe,
        RtdlBfsExpandRow** rows_out, size_t* row_count_out)
{
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    *rows_out = nullptr;
    *row_count_out = 0;
    if (!row_offsets || row_offset_count == 0) {
        throw std::runtime_error("graph row_offsets must not be empty");
    }
    const uint64_t vertex_count = static_cast<uint64_t>(row_offset_count - 1);
    if (vertex_count > static_cast<uint64_t>(UINT32_MAX) + 1ULL) {
        throw std::runtime_error("graph vertex count exceeds uint32 limit");
    }
    if (frontier_count == 0) {
        return;
    }
    if (!column_indices && edge_index_count != 0) {
        throw std::runtime_error("graph column_indices pointer must not be null when edge count is non-zero");
    }
    for (size_t vertex = 0; vertex + 1 < row_offset_count; ++vertex) {
        const uint32_t start = row_offsets[vertex];
        const uint32_t end = row_offsets[vertex + 1];
        if (start > end) {
            throw std::runtime_error("graph row_offsets must be non-decreasing");
        }
        if (end > edge_index_count) {
            throw std::runtime_error("graph row_offsets exceed column_indices length");
        }
    }
    for (size_t edge_index = 0; edge_index < edge_index_count; ++edge_index) {
        if (column_indices[edge_index] >= vertex_count) {
            throw std::runtime_error("graph column_indices must reference valid graph vertices");
        }
    }

    std::vector<uint8_t> visited_flags(static_cast<size_t>(vertex_count), 0);
    for (size_t i = 0; i < visited_count; ++i) {
        if (visited_vertices[i] >= vertex_count) {
            throw std::runtime_error("visited vertex_id must be a valid graph vertex");
        }
        visited_flags[visited_vertices[i]] = 1;
    }

    std::vector<uint8_t> discovered_flags(static_cast<size_t>(vertex_count), 0);
    std::vector<RtdlBfsExpandRow> rows;
    rows.reserve(edge_index_count);
    for (size_t i = 0; i < frontier_count; ++i) {
        const uint32_t src = frontier[i].vertex_id;
        if (src >= vertex_count) {
            throw std::runtime_error("frontier vertex_id must be a valid graph vertex");
        }
        const uint32_t start = row_offsets[src];
        const uint32_t end = row_offsets[src + 1];
        for (uint32_t edge_index = start; edge_index < end; ++edge_index) {
            const uint32_t dst = column_indices[edge_index];
            if (visited_flags[dst]) {
                continue;
            }
            if (dedupe && discovered_flags[dst]) {
                continue;
            }
            if (dedupe) {
                discovered_flags[dst] = 1;
            }
            rows.push_back(RtdlBfsExpandRow{src, dst, frontier[i].level + 1U});
        }
    }
    std::sort(rows.begin(), rows.end(), [](const RtdlBfsExpandRow& left, const RtdlBfsExpandRow& right) {
        if (left.level != right.level) {
            return left.level < right.level;
        }
        if (left.dst_vertex != right.dst_vertex) {
            return left.dst_vertex < right.dst_vertex;
        }
        return left.src_vertex < right.src_vertex;
    });

    auto* out = static_cast<RtdlBfsExpandRow*>(std::malloc(sizeof(RtdlBfsExpandRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlBfsExpandRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_triangle_cycle_candidates_vulkan_host_indexed(
        const uint32_t* row_offsets, size_t row_offset_count,
        const uint32_t* column_indices, size_t edge_index_count,
        const RtdlEdgeSeed* seeds, size_t seed_count,
        uint32_t enforce_id_ascending,
        uint32_t unique,
        RtdlTriangleRow** rows_out, size_t* row_count_out)
{
    if (!rows_out || !row_count_out) {
        throw std::runtime_error("output pointers must not be null");
    }
    *rows_out = nullptr;
    *row_count_out = 0;
    if (!row_offsets || row_offset_count == 0) {
        throw std::runtime_error("CSR graph row_offsets must not be empty");
    }
    if (edge_index_count > 0 && !column_indices) {
        throw std::runtime_error("CSR graph column_indices pointer must not be null");
    }
    if (seed_count > 0 && !seeds) {
        throw std::runtime_error("edge seed pointer must not be null when seed_count > 0");
    }
    if (row_offsets[0] != 0u) {
        throw std::runtime_error("CSR graph row_offsets must start at 0");
    }
    if (row_offsets[row_offset_count - 1] != edge_index_count) {
        throw std::runtime_error("CSR graph final row_offset must equal edge_count");
    }

    const uint32_t vertex_count = static_cast<uint32_t>(row_offset_count - 1);
    for (size_t index = 1; index < row_offset_count; ++index) {
        if (row_offsets[index] < row_offsets[index - 1]) {
            throw std::runtime_error("CSR graph row_offsets must be non-decreasing");
        }
    }
    for (size_t index = 0; index < edge_index_count; ++index) {
        if (column_indices[index] >= vertex_count) {
            throw std::runtime_error("CSR graph column_indices must be valid vertex IDs");
        }
    }

    std::vector<uint32_t> neighbor_marks(vertex_count, 0u);
    uint32_t stamp = 1u;
    std::vector<RtdlTriangleRow> rows;

    for (size_t seed_index = 0; seed_index < seed_count; ++seed_index) {
        const uint32_t u = seeds[seed_index].u;
        const uint32_t v = seeds[seed_index].v;
        if (u >= vertex_count || v >= vertex_count) {
            throw std::runtime_error("edge seed vertices must be valid graph vertex IDs");
        }
        if (u == v) {
            continue;
        }
        if (enforce_id_ascending != 0u && !(u < v)) {
            continue;
        }

        const size_t u_start = row_offsets[u];
        const size_t u_end = row_offsets[u + 1];
        const size_t v_start = row_offsets[v];
        const size_t v_end = row_offsets[v + 1];

        for (size_t offset = u_start; offset < u_end; ++offset) {
            neighbor_marks[column_indices[offset]] = stamp;
        }

        std::vector<uint32_t> common_neighbors;
        for (size_t offset = v_start; offset < v_end; ++offset) {
            const uint32_t w = column_indices[offset];
            if (neighbor_marks[w] != stamp) {
                continue;
            }
            if (enforce_id_ascending != 0u && !(v < w)) {
                continue;
            }
            common_neighbors.push_back(w);
        }
        std::sort(common_neighbors.begin(), common_neighbors.end());

        for (uint32_t w : common_neighbors) {
            if (unique != 0u) {
                const bool already_seen = std::any_of(
                    rows.begin(),
                    rows.end(),
                    [&](const RtdlTriangleRow& row) { return row.u == u && row.v == v && row.w == w; });
                if (already_seen) {
                    continue;
                }
            }
            rows.push_back({u, v, w});
        }

        stamp += 1u;
        if (stamp == 0u) {
            std::fill(neighbor_marks.begin(), neighbor_marks.end(), 0u);
            stamp = 1u;
        }
    }

    auto* out = static_cast<RtdlTriangleRow*>(std::malloc(sizeof(RtdlTriangleRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty()) {
        std::memcpy(out, rows.data(), sizeof(RtdlTriangleRow) * rows.size());
    }
    *rows_out = out;
    *row_count_out = rows.size();
}

// ---------- PointNearestSegment (compute) -------------------------------------

static void run_point_nearest_segment_vulkan(
        const RtdlPoint*   points,   size_t point_count,
        const RtdlSegment* segments, size_t segment_count,
        RtdlPointNearestSegmentRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    std::call_once(g_pns_init, [ctx]() {
        g_pns_pipe = new ComputePipeline(build_compute_pipeline(ctx, kPnsComp, "pns.comp", 4));
    });

    std::vector<GpuPoint>   gpu_pts(point_count);
    std::vector<GpuSegment> gpu_segs(segment_count);
    for (size_t i = 0; i < point_count;   ++i)
        gpu_pts[i]  = {(float)points[i].x,  (float)points[i].y,  points[i].id};
    for (size_t i = 0; i < segment_count; ++i)
        gpu_segs[i] = {(float)segments[i].x0,(float)segments[i].y0,
                       (float)segments[i].x1,(float)segments[i].y1, segments[i].id};

    VkDeviceSize pt_sz  = sizeof(GpuPoint)   * point_count;
    VkDeviceSize seg_sz = sizeof(GpuSegment) * segment_count;
    VkDeviceSize out_sz = sizeof(GpuPnsRecord) * point_count;

    BufMem d_pts  = alloc_buffer(ctx, pt_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_segs = alloc_buffer(ctx, seg_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_out  = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_pts,  gpu_pts.data(),  pt_sz);
    upload_to_buf(ctx, d_segs, gpu_segs.data(), seg_sz);

    struct { uint32_t npoints, nsegs; } params{ (uint32_t)point_count, (uint32_t)segment_count };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_pns_pipe->dset_layout, 4, false);
    bind_ssbo(ctx->device, ds.set, d_pts.buffer,  pt_sz,  0);
    bind_ssbo(ctx->device, ds.set, d_segs.buffer, seg_sz, 1);
    bind_ssbo(ctx->device, ds.set, d_out.buffer,  out_sz, 2);
    bind_ubo (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);

    uint32_t groups = ((uint32_t)point_count + 63u) / 64u;
    dispatch_compute(ctx, *g_pns_pipe, ds.set, groups);

    std::vector<GpuPnsRecord> gpu_rows(point_count);
    download_from_buf(ctx, gpu_rows.data(), d_out, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_pts); free_buf(ctx, d_segs); free_buf(ctx, d_out); free_buf(ctx, d_params);

    auto* out = static_cast<RtdlPointNearestSegmentRow*>(
        std::malloc(sizeof(RtdlPointNearestSegmentRow) * point_count));
    if (!out && point_count > 0) throw std::bad_alloc();
    for (size_t i = 0; i < point_count; ++i)
        out[i] = { gpu_rows[i].point_id, gpu_rows[i].segment_id,
                   static_cast<double>(gpu_rows[i].distance) };
    *rows_out      = out;
    *row_count_out = point_count;
}

// ---------- RayHitCount3D (Vulkan GPU - native triangle geometry) -------------

static void run_ray_hitcount_3d_vulkan(
        const RtdlRay3D* rays, size_t ray_count,
        const RtdlTriangle3D* triangles, size_t triangle_count,
        RtdlRayHitCountRow** rows_out, size_t* row_count_out)
{
    // Edge case: no rays -> empty result.
    if (ray_count == 0) {
        *rows_out = nullptr; *row_count_out = 0; return;
    }

    VkContext* ctx = get_context();
    std::call_once(g_rhc3d_init, [ctx]() {
        g_rhc3d_pipe = new RtPipeline(build_rt_pipeline_triangle(
            ctx, kRhc3dRgen, kRhc3dRmiss, kRhc3dRahit,
            "rhc3d.rgen", "rhc3d.rmiss", "rhc3d.rahit", 5));
    });

    // Pack 3D rays as GpuRay3D
    std::vector<GpuRay3D> gpu_rays(ray_count);
    for (size_t i = 0; i < ray_count; ++i) {
        gpu_rays[i] = { (float)rays[i].ox, (float)rays[i].oy, (float)rays[i].oz,
                        (float)rays[i].dx, (float)rays[i].dy, (float)rays[i].dz,
                        (float)rays[i].tmax, rays[i].id };
    }

    // Pack triangle vertices as flat float3 (9 floats per triangle)
    std::vector<float> vert_data(triangle_count * 9u);
    for (size_t i = 0; i < triangle_count; ++i) {
        float* v = &vert_data[i * 9u];
        v[0]=(float)triangles[i].x0; v[1]=(float)triangles[i].y0; v[2]=(float)triangles[i].z0;
        v[3]=(float)triangles[i].x1; v[4]=(float)triangles[i].y1; v[5]=(float)triangles[i].z1;
        v[6]=(float)triangles[i].x2; v[7]=(float)triangles[i].y2; v[8]=(float)triangles[i].z2;
    }

    VkDeviceSize ray_sz = sizeof(GpuRay3D) * ray_count;
    BufMem d_rays = alloc_buffer(ctx, ray_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_rays, gpu_rays.data(), ray_sz);

    // Build BLAS from native 3D triangle geometry + TLAS over it
    AccelResult blas = build_triangle_blas_3d(ctx, vert_data);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    // One GpuRayHitRecord per ray (ray_id + hit_count)
    VkDeviceSize out_sz = sizeof(GpuRayHitRecord) * ray_count;
    BufMem d_output = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_output);

    struct { uint32_t nrays, pad0; } params{ (uint32_t)ray_count, 0u };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    // Binding 2 is unused in the raygen shader but required by the descriptor layout
    BufMem d_dummy = alloc_buffer(ctx, 4u, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_rhc3d_pipe->dset_layout, 5, true);
    bind_tlas  (ctx,         ds.set, tlas.handle,     0);
    bind_ssbo  (ctx->device, ds.set, d_output.buffer, out_sz,       1);
    bind_ssbo  (ctx->device, ds.set, d_dummy.buffer,  4u,           2);
    bind_ubo   (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
    bind_ssbo  (ctx->device, ds.set, d_rays.buffer,   ray_sz,       4);

    dispatch_rt(ctx, *g_rhc3d_pipe, ds.set, (uint32_t)ray_count);

    std::vector<GpuRayHitRecord> gpu_rows(ray_count);
    download_from_buf(ctx, gpu_rows.data(), d_output, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_rays); free_buf(ctx, d_output);
    free_buf(ctx, d_params); free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    auto* out = static_cast<RtdlRayHitCountRow*>(std::malloc(sizeof(RtdlRayHitCountRow) * ray_count));
    if (!out) throw std::bad_alloc();
    for (size_t i = 0; i < ray_count; ++i) {
        uint32_t exact_hit_count = 0;
        for (size_t tri_index = 0; tri_index < triangle_count; ++tri_index) {
            if (exact_ray_hits_triangle_3d(rays[i], triangles[tri_index])) {
                exact_hit_count += 1u;
            }
        }
        out[i] = { gpu_rows[i].ray_id, exact_hit_count };
    }
    *rows_out      = out;
    *row_count_out = ray_count;
}

static void run_ray_anyhit_3d_vulkan(
        const RtdlRay3D* rays, size_t ray_count,
        const RtdlTriangle3D* triangles, size_t triangle_count,
        RtdlRayAnyHitRow** rows_out, size_t* row_count_out)
{
    if (ray_count == 0) {
        *rows_out = nullptr; *row_count_out = 0; return;
    }

    VkContext* ctx = get_context();
    std::call_once(g_rah3d_init, [ctx]() {
        g_rah3d_pipe = new RtPipeline(build_rt_pipeline_triangle(
            ctx, kRah3dRgen, kRah3dRmiss, kRah3dRahit,
            "rah3d.rgen", "rah3d.rmiss", "rah3d.rahit", 5));
    });

    std::vector<GpuRay3D> gpu_rays(ray_count);
    for (size_t i = 0; i < ray_count; ++i) {
        gpu_rays[i] = { (float)rays[i].ox, (float)rays[i].oy, (float)rays[i].oz,
                        (float)rays[i].dx, (float)rays[i].dy, (float)rays[i].dz,
                        (float)rays[i].tmax, rays[i].id };
    }

    std::vector<float> vert_data(triangle_count * 9u);
    for (size_t i = 0; i < triangle_count; ++i) {
        float* v = &vert_data[i * 9u];
        v[0]=(float)triangles[i].x0; v[1]=(float)triangles[i].y0; v[2]=(float)triangles[i].z0;
        v[3]=(float)triangles[i].x1; v[4]=(float)triangles[i].y1; v[5]=(float)triangles[i].z1;
        v[6]=(float)triangles[i].x2; v[7]=(float)triangles[i].y2; v[8]=(float)triangles[i].z2;
    }

    VkDeviceSize ray_sz = sizeof(GpuRay3D) * ray_count;
    BufMem d_rays = alloc_buffer(ctx, ray_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    upload_to_buf(ctx, d_rays, gpu_rays.data(), ray_sz);

    AccelResult blas = build_triangle_blas_3d(ctx, vert_data);
    AccelResult tlas = build_tlas(ctx, blas.handle, blas.device_addr);

    VkDeviceSize out_sz = sizeof(GpuRayHitRecord) * ray_count;
    BufMem d_output = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    zero_buf(ctx, d_output);

    struct { uint32_t nrays, pad0; } params{ (uint32_t)ray_count, 0u };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    BufMem d_dummy = alloc_buffer(ctx, 4u, VK_BUFFER_USAGE_STORAGE_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_rah3d_pipe->dset_layout, 5, true);
    bind_tlas  (ctx,         ds.set, tlas.handle,     0);
    bind_ssbo  (ctx->device, ds.set, d_output.buffer, out_sz,       1);
    bind_ssbo  (ctx->device, ds.set, d_dummy.buffer,  4u,           2);
    bind_ubo   (ctx->device, ds.set, d_params.buffer, sizeof(params), 3);
    bind_ssbo  (ctx->device, ds.set, d_rays.buffer,   ray_sz,       4);

    dispatch_rt(ctx, *g_rah3d_pipe, ds.set, (uint32_t)ray_count);

    std::vector<GpuRayHitRecord> gpu_rows(ray_count);
    download_from_buf(ctx, gpu_rows.data(), d_output, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_rays); free_buf(ctx, d_output);
    free_buf(ctx, d_params); free_buf(ctx, d_dummy);
    destroy_accel(ctx, tlas); destroy_accel(ctx, blas);

    auto* out = static_cast<RtdlRayAnyHitRow*>(std::malloc(sizeof(RtdlRayAnyHitRow) * ray_count));
    if (!out) throw std::bad_alloc();
    for (size_t i = 0; i < ray_count; ++i)
        out[i] = { gpu_rows[i].ray_id, gpu_rows[i].hit_count ? 1u : 0u };
    *rows_out      = out;
    *row_count_out = ray_count;
}

// ---------- FixedRadiusNeighbors (compute brute-force) -----------------------

static void run_fixed_radius_neighbors_vulkan(
        const RtdlPoint* query_points, size_t query_count,
        const RtdlPoint* search_points, size_t search_count,
        double radius,
        size_t k_max,
        RtdlFixedRadiusNeighborRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    constexpr double kFixedRadiusCandidateEps = 1.0e-4;
    constexpr size_t kFixedRadiusSlack = 8;
    std::call_once(g_frn_init, [ctx]() {
        g_frn_pipe = new ComputePipeline(build_compute_pipeline(ctx, kFrnComp, "frn.comp", 4));
    });

    std::vector<GpuPoint> gpu_queries(query_count);
    std::vector<GpuPoint> gpu_search(search_count);
    for (size_t i = 0; i < query_count; ++i)
        gpu_queries[i] = {(float)query_points[i].x, (float)query_points[i].y, query_points[i].id};
    for (size_t i = 0; i < search_count; ++i)
        gpu_search[i]  = {(float)search_points[i].x, (float)search_points[i].y, search_points[i].id};

    const size_t capped_k_max = std::min(k_max, search_count);
    const size_t candidate_slack = std::min(
        kFixedRadiusSlack,
        search_count > capped_k_max ? search_count - capped_k_max : size_t{0});
    const size_t kernel_k_max = capped_k_max + candidate_slack;
    const size_t output_capacity = checked_mul_size_t(
        query_count, kernel_k_max, "fixed_radius_neighbors");
    VkDeviceSize qry_sz  = sizeof(GpuPoint)    * query_count;
    VkDeviceSize srch_sz = sizeof(GpuPoint)    * search_count;
    VkDeviceSize out_sz  = checked_output_bytes(
        output_capacity, sizeof(GpuFrnRecord), "fixed_radius_neighbors");

    BufMem d_queries = alloc_buffer(ctx, qry_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_search  = alloc_buffer(ctx, srch_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_out     = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT |
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    upload_to_buf(ctx, d_queries, gpu_queries.data(), qry_sz);
    upload_to_buf(ctx, d_search,  gpu_search.data(),  srch_sz);

    struct FrnParams { uint32_t nqueries, nsearch; float radius_f; uint32_t k_max_u; };
    FrnParams params{ (uint32_t)query_count, (uint32_t)search_count,
                      (float)(radius + kFixedRadiusCandidateEps), (uint32_t)kernel_k_max };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_frn_pipe->dset_layout, 4, false);
    bind_ssbo(ctx->device, ds.set, d_queries.buffer, qry_sz,  0);
    bind_ssbo(ctx->device, ds.set, d_search.buffer,  srch_sz, 1);
    bind_ssbo(ctx->device, ds.set, d_out.buffer,     out_sz,  2);
    bind_ubo (ctx->device, ds.set, d_params.buffer,  sizeof(params), 3);

    uint32_t groups = ((uint32_t)query_count + 63u) / 64u;
    dispatch_compute(ctx, *g_frn_pipe, ds.set, groups);

    std::vector<GpuFrnRecord> gpu_rows(output_capacity);
    download_from_buf(ctx, gpu_rows.data(), d_out, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_queries); free_buf(ctx, d_search);
    free_buf(ctx, d_out);     free_buf(ctx, d_params);

    std::unordered_map<uint32_t, const RtdlPoint*> query_by_id;
    std::unordered_map<uint32_t, const RtdlPoint*> search_by_id;
    query_by_id.reserve(query_count);
    search_by_id.reserve(search_count);
    for (size_t i = 0; i < query_count; ++i) {
        query_by_id.emplace(query_points[i].id, query_points + i);
    }
    for (size_t i = 0; i < search_count; ++i) {
        search_by_id.emplace(search_points[i].id, search_points + i);
    }

    std::vector<RtdlFixedRadiusNeighborRow> exact_rows;
    exact_rows.reserve(output_capacity);
    for (size_t i = 0; i < output_capacity; ++i) {
        if (gpu_rows[i].neighbor_id == 0xffffffffu) continue;
        auto query_it = query_by_id.find(gpu_rows[i].query_id);
        auto search_it = search_by_id.find(gpu_rows[i].neighbor_id);
        if (query_it == query_by_id.end() || search_it == search_by_id.end()) {
            continue;
        }
        double dx = search_it->second->x - query_it->second->x;
        double dy = search_it->second->y - query_it->second->y;
        double exact_distance = std::sqrt(dx * dx + dy * dy);
        if (exact_distance <= radius) {
            exact_rows.push_back({
                gpu_rows[i].query_id,
                gpu_rows[i].neighbor_id,
                exact_distance,
            });
        }
    }

    std::stable_sort(exact_rows.begin(), exact_rows.end(),
        [](const RtdlFixedRadiusNeighborRow& a, const RtdlFixedRadiusNeighborRow& b) {
            if (a.query_id != b.query_id) {
                return a.query_id < b.query_id;
            }
            if (a.distance < b.distance - 1.0e-12) {
                return true;
            }
            if (b.distance < a.distance - 1.0e-12) {
                return false;
            }
            return a.neighbor_id < b.neighbor_id;
        });

    std::vector<RtdlFixedRadiusNeighborRow> rows;
    rows.reserve(exact_rows.size());
    uint32_t current_query_id = 0;
    size_t current_count = 0;
    bool have_query = false;
    for (const auto& row : exact_rows) {
        if (!have_query || row.query_id != current_query_id) {
            current_query_id = row.query_id;
            current_count = 0;
            have_query = true;
        }
        if (current_count >= k_max) {
            continue;
        }
        rows.push_back(row);
        current_count += 1;
    }

    auto* out = static_cast<RtdlFixedRadiusNeighborRow*>(
        std::malloc(sizeof(RtdlFixedRadiusNeighborRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty())
        std::memcpy(out, rows.data(), sizeof(RtdlFixedRadiusNeighborRow) * rows.size());
    *rows_out      = out;
    *row_count_out = rows.size();
}

static void run_fixed_radius_neighbors_3d_vulkan(
        const RtdlPoint3D* query_points, size_t query_count,
        const RtdlPoint3D* search_points, size_t search_count,
        double radius,
        size_t k_max,
        RtdlFixedRadiusNeighborRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    constexpr double kFixedRadiusCandidateEps = 1.0e-4;
    constexpr size_t kFixedRadiusSlack = 8;
    std::call_once(g_frn3d_init, [ctx]() {
        g_frn3d_pipe = new ComputePipeline(build_compute_pipeline(ctx, kFrn3DComp, "frn3d.comp", 4));
    });

    std::vector<GpuPoint3D> gpu_queries(query_count);
    std::vector<GpuPoint3D> gpu_search(search_count);
    for (size_t i = 0; i < query_count; ++i) {
        gpu_queries[i] = {(float)query_points[i].x, (float)query_points[i].y, (float)query_points[i].z, query_points[i].id};
    }
    for (size_t i = 0; i < search_count; ++i) {
        gpu_search[i] = {(float)search_points[i].x, (float)search_points[i].y, (float)search_points[i].z, search_points[i].id};
    }

    const size_t capped_k_max = std::min(k_max, search_count);
    const size_t candidate_slack = std::min(
        kFixedRadiusSlack,
        search_count > capped_k_max ? search_count - capped_k_max : size_t{0});
    const size_t kernel_k_max = capped_k_max + candidate_slack;
    const size_t output_capacity = checked_mul_size_t(
        query_count, kernel_k_max, "fixed_radius_neighbors_3d");
    VkDeviceSize qry_sz  = sizeof(GpuPoint3D) * query_count;
    VkDeviceSize srch_sz = sizeof(GpuPoint3D) * search_count;
    VkDeviceSize out_sz  = checked_output_bytes(
        output_capacity, sizeof(GpuFrnRecord), "fixed_radius_neighbors_3d");

    BufMem d_queries = alloc_buffer(ctx, qry_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_search  = alloc_buffer(ctx, srch_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_out     = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT |
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    upload_to_buf(ctx, d_queries, gpu_queries.data(), qry_sz);
    upload_to_buf(ctx, d_search, gpu_search.data(), srch_sz);

    struct FrnParams { uint32_t nqueries, nsearch; float radius_f; uint32_t k_max_u; };
    FrnParams params{ (uint32_t)query_count, (uint32_t)search_count,
                      (float)(radius + kFixedRadiusCandidateEps), (uint32_t)kernel_k_max };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_frn3d_pipe->dset_layout, 4, false);
    bind_ssbo(ctx->device, ds.set, d_queries.buffer, qry_sz, 0);
    bind_ssbo(ctx->device, ds.set, d_search.buffer, srch_sz, 1);
    bind_ssbo(ctx->device, ds.set, d_out.buffer, out_sz, 2);
    bind_ubo(ctx->device, ds.set, d_params.buffer, sizeof(params), 3);

    uint32_t groups = ((uint32_t)query_count + 63u) / 64u;
    dispatch_compute(ctx, *g_frn3d_pipe, ds.set, groups);

    std::vector<GpuFrnRecord> gpu_rows(output_capacity);
    download_from_buf(ctx, gpu_rows.data(), d_out, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_queries); free_buf(ctx, d_search);
    free_buf(ctx, d_out);     free_buf(ctx, d_params);

    std::unordered_map<uint32_t, const RtdlPoint3D*> query_by_id;
    std::unordered_map<uint32_t, const RtdlPoint3D*> search_by_id;
    query_by_id.reserve(query_count);
    search_by_id.reserve(search_count);
    for (size_t i = 0; i < query_count; ++i) {
        query_by_id.emplace(query_points[i].id, query_points + i);
    }
    for (size_t i = 0; i < search_count; ++i) {
        search_by_id.emplace(search_points[i].id, search_points + i);
    }

    std::vector<RtdlFixedRadiusNeighborRow> exact_rows;
    exact_rows.reserve(output_capacity);
    for (size_t i = 0; i < output_capacity; ++i) {
        if (gpu_rows[i].neighbor_id == 0xffffffffu) continue;
        auto query_it = query_by_id.find(gpu_rows[i].query_id);
        auto search_it = search_by_id.find(gpu_rows[i].neighbor_id);
        if (query_it == query_by_id.end() || search_it == search_by_id.end()) {
            continue;
        }
        double dx = search_it->second->x - query_it->second->x;
        double dy = search_it->second->y - query_it->second->y;
        double dz = search_it->second->z - query_it->second->z;
        double exact_distance = std::sqrt(dx * dx + dy * dy + dz * dz);
        if (exact_distance <= radius) {
            exact_rows.push_back({
                gpu_rows[i].query_id,
                gpu_rows[i].neighbor_id,
                exact_distance,
            });
        }
    }

    std::stable_sort(exact_rows.begin(), exact_rows.end(),
        [](const RtdlFixedRadiusNeighborRow& a, const RtdlFixedRadiusNeighborRow& b) {
            if (a.query_id != b.query_id) {
                return a.query_id < b.query_id;
            }
            if (a.distance < b.distance - 1.0e-12) {
                return true;
            }
            if (b.distance < a.distance - 1.0e-12) {
                return false;
            }
            return a.neighbor_id < b.neighbor_id;
        });

    std::vector<RtdlFixedRadiusNeighborRow> rows;
    rows.reserve(exact_rows.size());
    uint32_t current_query_id = 0;
    size_t current_count = 0;
    bool have_query = false;
    for (const auto& row : exact_rows) {
        if (!have_query || row.query_id != current_query_id) {
            current_query_id = row.query_id;
            current_count = 0;
            have_query = true;
        }
        if (current_count >= k_max) {
            continue;
        }
        rows.push_back(row);
        current_count += 1;
    }

    auto* out = static_cast<RtdlFixedRadiusNeighborRow*>(
        std::malloc(sizeof(RtdlFixedRadiusNeighborRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty())
        std::memcpy(out, rows.data(), sizeof(RtdlFixedRadiusNeighborRow) * rows.size());
    *rows_out = out;
    *row_count_out = rows.size();
}

// ---------- KNNRows (compute brute-force) ------------------------------------

static void run_k_closest_hits_vulkan(
        const RtdlPoint* query_points, size_t query_count,
        const RtdlPoint* search_points, size_t search_count,
        size_t k,
        RtdlKnnNeighborRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    std::call_once(g_knn_init, [ctx]() {
        g_knn_pipe = new ComputePipeline(build_compute_pipeline(ctx, kKClosestHitsComp, "k_closest_hits.comp", 4));
    });

    std::vector<GpuPoint> gpu_queries(query_count);
    std::vector<GpuPoint> gpu_search(search_count);
    for (size_t i = 0; i < query_count; ++i)
        gpu_queries[i] = {(float)query_points[i].x, (float)query_points[i].y, query_points[i].id};
    for (size_t i = 0; i < search_count; ++i)
        gpu_search[i]  = {(float)search_points[i].x, (float)search_points[i].y, search_points[i].id};

    const size_t output_capacity = checked_mul_size_t(
        query_count, k, "knn_rows");
    VkDeviceSize qry_sz  = sizeof(GpuPoint) * query_count;
    VkDeviceSize srch_sz = sizeof(GpuPoint) * search_count;
    VkDeviceSize out_sz  = checked_output_bytes(
        output_capacity, sizeof(GpuKnnRecord), "knn_rows");

    BufMem d_queries = alloc_buffer(ctx, qry_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_search = alloc_buffer(ctx, srch_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_out = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT |
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    upload_to_buf(ctx, d_queries, gpu_queries.data(), qry_sz);
    upload_to_buf(ctx, d_search, gpu_search.data(), srch_sz);

    struct KnnParams { uint32_t nqueries, nsearch, k_u, pad0; };
    KnnParams params{ (uint32_t)query_count, (uint32_t)search_count, (uint32_t)k, 0u };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_knn_pipe->dset_layout, 4, false);
    bind_ssbo(ctx->device, ds.set, d_queries.buffer, qry_sz, 0);
    bind_ssbo(ctx->device, ds.set, d_search.buffer, srch_sz, 1);
    bind_ssbo(ctx->device, ds.set, d_out.buffer, out_sz, 2);
    bind_ubo(ctx->device, ds.set, d_params.buffer, sizeof(params), 3);

    uint32_t groups = ((uint32_t)query_count + 63u) / 64u;
    dispatch_compute(ctx, *g_knn_pipe, ds.set, groups);

    std::vector<GpuKnnRecord> gpu_rows(output_capacity);
    download_from_buf(ctx, gpu_rows.data(), d_out, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_queries); free_buf(ctx, d_search);
    free_buf(ctx, d_out); free_buf(ctx, d_params);

    std::vector<RtdlKnnNeighborRow> rows;
    rows.reserve(output_capacity);
    for (size_t i = 0; i < output_capacity; ++i) {
        if (gpu_rows[i].neighbor_id == 0xffffffffu) continue;
        rows.push_back({
            gpu_rows[i].query_id,
            gpu_rows[i].neighbor_id,
            static_cast<double>(gpu_rows[i].distance),
            gpu_rows[i].neighbor_rank,
        });
    }

    std::stable_sort(rows.begin(), rows.end(),
        [](const RtdlKnnNeighborRow& a, const RtdlKnnNeighborRow& b) {
            return a.query_id < b.query_id;
        });

    auto* out = static_cast<RtdlKnnNeighborRow*>(
        std::malloc(sizeof(RtdlKnnNeighborRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty())
        std::memcpy(out, rows.data(), sizeof(RtdlKnnNeighborRow) * rows.size());
    *rows_out = out;
    *row_count_out = rows.size();
}

static void run_k_closest_hits_3d_vulkan(
        const RtdlPoint3D* query_points, size_t query_count,
        const RtdlPoint3D* search_points, size_t search_count,
        size_t k,
        RtdlKnnNeighborRow** rows_out, size_t* row_count_out)
{
    VkContext* ctx = get_context();
    constexpr size_t kKClosestHitsCandidateSlack = 8;
    std::call_once(g_knn3d_init, [ctx]() {
        g_knn3d_pipe = new ComputePipeline(build_compute_pipeline(ctx, kKClosestHits3DComp, "k_closest_hits3d.comp", 4));
    });

    std::vector<GpuPoint3D> gpu_queries(query_count);
    std::vector<GpuPoint3D> gpu_search(search_count);
    for (size_t i = 0; i < query_count; ++i) {
        gpu_queries[i] = {(float)query_points[i].x, (float)query_points[i].y, (float)query_points[i].z, query_points[i].id};
    }
    for (size_t i = 0; i < search_count; ++i) {
        gpu_search[i]  = {(float)search_points[i].x, (float)search_points[i].y, (float)search_points[i].z, search_points[i].id};
    }

    const size_t capped_k = std::min(k, search_count);
    const size_t candidate_slack = std::min(
        kKClosestHitsCandidateSlack,
        search_count > capped_k ? search_count - capped_k : size_t{0});
    const size_t kernel_k = capped_k + candidate_slack;
    const size_t output_capacity = checked_mul_size_t(
        query_count, kernel_k, "knn_rows_3d");
    VkDeviceSize qry_sz  = sizeof(GpuPoint3D) * query_count;
    VkDeviceSize srch_sz = sizeof(GpuPoint3D) * search_count;
    VkDeviceSize out_sz  = checked_output_bytes(
        output_capacity, sizeof(GpuKnnRecord), "knn_rows_3d");

    BufMem d_queries = alloc_buffer(ctx, qry_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_search = alloc_buffer(ctx, srch_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
    BufMem d_out = alloc_buffer(ctx, out_sz,
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT |
            VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
        VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);

    upload_to_buf(ctx, d_queries, gpu_queries.data(), qry_sz);
    upload_to_buf(ctx, d_search, gpu_search.data(), srch_sz);

    struct KnnParams { uint32_t nqueries, nsearch, k_u, pad0; };
    KnnParams params{ (uint32_t)query_count, (uint32_t)search_count, (uint32_t)kernel_k, 0u };
    BufMem d_params = alloc_buffer(ctx, sizeof(params), VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
        VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
    void* mp; vkMapMemory(ctx->device, d_params.memory, 0, sizeof(params), 0, &mp);
    std::memcpy(mp, &params, sizeof(params)); vkUnmapMemory(ctx->device, d_params.memory);

    DescriptorSet ds = alloc_descriptor_set(ctx, g_knn3d_pipe->dset_layout, 4, false);
    bind_ssbo(ctx->device, ds.set, d_queries.buffer, qry_sz, 0);
    bind_ssbo(ctx->device, ds.set, d_search.buffer, srch_sz, 1);
    bind_ssbo(ctx->device, ds.set, d_out.buffer, out_sz, 2);
    bind_ubo(ctx->device, ds.set, d_params.buffer, sizeof(params), 3);

    uint32_t groups = ((uint32_t)query_count + 63u) / 64u;
    dispatch_compute(ctx, *g_knn3d_pipe, ds.set, groups);

    std::vector<GpuKnnRecord> gpu_rows(output_capacity);
    download_from_buf(ctx, gpu_rows.data(), d_out, out_sz);

    vkDestroyDescriptorPool(ctx->device, ds.pool, nullptr);
    free_buf(ctx, d_queries); free_buf(ctx, d_search);
    free_buf(ctx, d_out); free_buf(ctx, d_params);

    std::unordered_map<uint32_t, const RtdlPoint3D*> query_by_id;
    std::unordered_map<uint32_t, const RtdlPoint3D*> search_by_id;
    query_by_id.reserve(query_count);
    search_by_id.reserve(search_count);
    for (size_t i = 0; i < query_count; ++i) {
        query_by_id.emplace(query_points[i].id, query_points + i);
    }
    for (size_t i = 0; i < search_count; ++i) {
        search_by_id.emplace(search_points[i].id, search_points + i);
    }

    std::vector<RtdlKnnNeighborRow> exact_rows;
    exact_rows.reserve(output_capacity);
    for (size_t i = 0; i < output_capacity; ++i) {
        if (gpu_rows[i].neighbor_id == 0xffffffffu) continue;
        auto query_it = query_by_id.find(gpu_rows[i].query_id);
        auto search_it = search_by_id.find(gpu_rows[i].neighbor_id);
        if (query_it == query_by_id.end() || search_it == search_by_id.end()) {
            continue;
        }
        double dx = search_it->second->x - query_it->second->x;
        double dy = search_it->second->y - query_it->second->y;
        double dz = search_it->second->z - query_it->second->z;
        exact_rows.push_back({
            gpu_rows[i].query_id,
            gpu_rows[i].neighbor_id,
            std::sqrt(dx * dx + dy * dy + dz * dz),
            0u,
        });
    }

    std::stable_sort(exact_rows.begin(), exact_rows.end(),
        [](const RtdlKnnNeighborRow& a, const RtdlKnnNeighborRow& b) {
            if (a.query_id != b.query_id) {
                return a.query_id < b.query_id;
            }
            if (a.distance < b.distance - 1.0e-12) {
                return true;
            }
            if (b.distance < a.distance - 1.0e-12) {
                return false;
            }
            return a.neighbor_id < b.neighbor_id;
        });

    std::vector<RtdlKnnNeighborRow> rows;
    rows.reserve(checked_mul_size_t(query_count, k, "knn_rows_3d_trimmed"));
    uint32_t current_query_id = 0;
    uint32_t current_rank = 0;
    bool have_query = false;
    for (const auto& row : exact_rows) {
        if (!have_query || row.query_id != current_query_id) {
            current_query_id = row.query_id;
            current_rank = 0;
            have_query = true;
        }
        if (current_rank >= k) {
            continue;
        }
        current_rank += 1u;
        rows.push_back({
            row.query_id,
            row.neighbor_id,
            row.distance,
            current_rank,
        });
    }

    auto* out = static_cast<RtdlKnnNeighborRow*>(
        std::malloc(sizeof(RtdlKnnNeighborRow) * rows.size()));
    if (!out && !rows.empty()) throw std::bad_alloc();
    if (!rows.empty())
        std::memcpy(out, rows.data(), sizeof(RtdlKnnNeighborRow) * rows.size());
    *rows_out = out;
    *row_count_out = rows.size();
}

// Error wrapper -------------------------------------------------------------

template <typename Fn>
static int handle_call(Fn fn, char* error_out, size_t error_size) noexcept {
    try {
        fn();
        return 0;
    } catch (const std::exception& e) {
        set_error(e.what(), error_out, error_size);
        return 1;
    } catch (...) {
        set_erro
